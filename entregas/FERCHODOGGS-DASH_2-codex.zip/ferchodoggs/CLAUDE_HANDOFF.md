# CLAUDE_HANDOFF

## Escenario real
No existe proyecto en el entorno. Esta entrega es independiente y NO está integrada en la tienda. Tampoco se recibieron capturas accesibles ni el skill professional-web-gamecraft. No se ha publicado ni contactado con Claude o hosting alguno.

## Cambios y archivos
- `public/index.html`, `style.css`: cabecera compacta, portada solicitada, botón naranja, tarjeta con botón verde fuera de la zona del asset, menú inmediatamente después. Tokens exactos, una familia de sistema, cuerpo 16 px y brillo morado estático localizado.
- `public/app.js`: diálogo del juego, HUD compacto, controles por teclado, gestos y botones, carga/error/inicio/partida/pausa/resultado, pausa al ocultar pestaña, scroll bloqueado y restauración de foco; adaptador básico de catálogo/carrito/WhatsApp.
- `public/engine.js`: motor determinista versionado compartido con servidor.
- `public/config.js`: única URL de mascota y datos públicos.
- `server.mjs`: servidor Node estático y verificador local; `tests/`, `scripts/`, Dockerfile y `.env.example`.

## Integrar sin perder pedidos
1. Crear rama de revisión desde la versión actual de la tienda; registrar pruebas del carrito existente antes de editar.
2. Llevar estilos con un namespace si hay CSS existente. Sustituir solo cabecera/hero/tarjeta del juego, no el proveedor de carrito, router ni catálogo.
3. Montar el diálogo fuera de contenedores con transform/overflow. Si usa framework, portar el ciclo de vida y limpiar listeners, ResizeObserver y RAF al desmontar.
4. Conservar identificadores, variantes, salsas reales, impuestos, descuentos, enlaces y constructor del mensaje de WhatsApp. Reemplazar el adaptador básico final de app.js por llamadas al carrito existente. No migrar ni sobreescribir almacenamiento del carrito de producción.
5. El ejemplo básico solo calcula precio × cantidad. No usarlo para productos con opciones hasta conectarlo al configurador real. El catálogo vacío evita inventar información comercial.

## Mascota completa
Cambiar SOLO `mascotUrl` en public/config.js a la ruta del original transparente de cuerpo completo, con pies y márgenes razonables. Se usa contain/escala uniforme en los tres contextos. No hay personaje inventado; el marcador DEV ASSET no es arte final. Comprobar visualmente el asset real antes de aprobar. Si es remoto, permitir su origen en CSP si hace falta; preferir servirlo del mismo origen. No recortar a cara/torso ni poner el botón encima.

## Retirar la interacción decorativa de salsa
No existe código anterior que pueda eliminarse aquí. En la tienda buscar el gancho decorativo, textos, controles, gestos y efectos; retirar el componente y sus listeners/estado/assets exclusivos. Buscar referencias antes de borrar funciones compartidas. NO borrar campos de ingredientes/salsas del catálogo, variantes, seleccionadores reales ni el cálculo del pedido. La entrega no incluye el gancho decorativo.

## Competición y motor
No sustituir un validador existente sin conocer su contrato. Para la nueva implementación usar ambos lados de engine.js dash-1.0.0. No mezclar scores de motores distintos. El modo verificado local está desactivado por defecto. El verificador incluido no es una competición pública: no tiene identidad, persistencia ni tabla pública. Antes de habilitar premios completar los requisitos del README y pruebas de concurrencia contra el almacenamiento elegido.

## Pruebas y pendientes
Ver TEST_REPORT.md. Pasaron pruebas de lógica, solicitudes repetidas al manejador y build/lint. No se ejecutó navegador, viewport ni dispositivo. Falta comprobar 320/390/768/1440, poca altura/horizontal, foco, contraste visual, gestos reales, asset original y conservación del carrito de la tienda. El servidor de desarrollo caduca a los 120 s, incluso si se pausa. No se han probado Docker ni despliegue.

## Publicar una versión revisable
1. Ejecutar npm run lint, npm test y npm run build.
2. Revisar localmente con npm start; activar competitionEnabled solo para revisar el verificador de desarrollo.
3. Subir una rama/PR con estos cambios al repositorio real; desplegar un entorno de staging privado con el servidor Node o contenedor y HTTPS. No copiar secrets al frontend.
4. Completar la matriz visual y de carrito con los datos/mascota reales. Obtener revisión de diseño antes de sustituir producción. No se ha desplegado nada desde esta entrega.
