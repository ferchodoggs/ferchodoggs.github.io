# Informe de pruebas reales

Entorno: Node v24.22.1, Linux. Sin paquetes externos.

## Ejecutadas y aprobadas
- `npm run lint`: comprobación sintáctica de todos los JS/MJS y ausencia de debugger; no es un análisis ESLint de estilo.
- `npm test`: dos archivos aprobados. Ejecución directa de ambos archivos confirmó 6 casos individuales aprobados.
- Motor: misma semilla produce mismo estado y reproducción en 100 semillas; todos los patrones de 500 semillas permiten sobrevivir 3600 pasos por el carril libre; colisión al tick de contacto; salto que evita contacto; límites de carriles; rechazo de eventos desordenados/inválidos y duración inválida; estado nuevo independiente tras reinicio.
- Manejador HTTP real invocado con streams en memoria: emisión de sesión, rechazo de tiempo insuficiente, reproducción y puntuación recalculada ignorando score inyectado, rechazo de reenvío, JSON inválido, versión distinta y límite de frecuencia.
- `npm run build`: generó dist/ sin errores.

## Limitación comprobada
El intento inicial de prueba HTTP con puerto falló con `listen EPERM 127.0.0.1`. Se adaptaron las pruebas del manejador sin abrir puertos. Esto valida el manejador, pero NO la conexión de red, proxy, TLS ni un despliegue real.

El entorno gestionado no tiene cua_repl.js ni herramientas de navegador disponibles para QA. Según las instrucciones de Sites no se inició un servidor de preview ni se usó Chromium como alternativa. No se tomaron capturas ni se ejecutaron pruebas de navegador o móvil.

## Composición: revisión de código, pendiente de render
Se separó del motor: CSS con breakpoint móvil a 767 px, adaptación de poca altura a 500 px, dimensiones de diálogo en dvh, safe areas y canvas flexible. Arte con contain/escala uniforme, botón externo al contenedor de mascota, sin emojis usados como assets. Tokens especificados y foco visible. Estas observaciones NO demuestran ausencia de recortes o superposiciones en un navegador.

Matriz pendiente: 320, 390, 768 y 1440 px; 390×600, 667×320 horizontal; safe areas en dispositivo; contraste medido; teclado/lector de pantalla; gestos rápidos/cancelados; pausa, cierre durante carga y reintento repetido; errores de asset en navegador; sonido opcional; WhatsApp real. El código cancela pointercancel y vacía acciones al pausar/cerrar; falta verificarlo con eventos reales.

No hay carrito, catálogo, backend previo ni gancho decorativo de salsa disponible. No es posible certificar conservación ni retirada en la tienda real. El módulo no incorpora ese gancho y su almacenamiento de carrito tiene un namespace propio. Falta validar opciones reales de ingredientes y todos los cálculos comerciales al integrar.

## Sin afirmar
Sin pruebas de tienda original, competición pública, identidad de jugadores, Docker, carga concurrente distribuida ni publicación. No hay premios, ganadores o leaderboard ficticios.
