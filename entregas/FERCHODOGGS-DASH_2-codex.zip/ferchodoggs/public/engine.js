// Shared by browser and server. A rules change MUST create a new version.
export const VERSION='dash-1.0.0';
export const HZ=60, LIMIT=3600;
export function random(seed){let x=seed>>>0;return()=>{x=(Math.imul(x,1664525)+1013904223)>>>0;return x/4294967296;};}
export function patterns(seed){const r=random(seed),out=[];for(let t=150;t<LIMIT;t+=100){const free=Math.floor(r()*3);for(let lane=0;lane<3;lane++)if(lane!==free)out.push({tick:t,lane,type:r()<.5?'barrier':'crate'});}return out;}
export function create(seed){return{seed:seed>>>0,tick:0,lane:1,jump:0,alive:true,score:0,obstacles:patterns(seed)};}
export function step(s,actions=[]){if(!s.alive||s.tick>=LIMIT)return s;for(const a of actions){if(a==='left')s.lane=Math.max(0,s.lane-1);if(a==='right')s.lane=Math.min(2,s.lane+1);if(a==='jump'&&!s.jump)s.jump=48;}s.tick++;if(s.jump)s.jump--;for(const o of s.obstacles)if(o.tick===s.tick&&o.lane===s.lane&&jumpHeight(s)<.65)s.alive=false;s.score=s.tick;return s;}
export function jumpHeight(s){return s.jump?Math.sin(Math.PI*(48-s.jump)/48):0;}
export function replay(seed,events,endTick){if(!Number.isInteger(endTick)||endTick<1||endTick>LIMIT)throw Error('Invalid duration');if(!Array.isArray(events)||events.length>2000)throw Error('Invalid events');let prev=0;for(const e of events){if(!Number.isInteger(e.tick)||e.tick<1||e.tick<prev||e.tick>endTick||!['left','right','jump'].includes(e.action))throw Error('Invalid event');prev=e.tick;}const s=create(seed);let i=0;while(s.tick<endTick&&s.alive){const actions=[];while(events[i]?.tick===s.tick+1)actions.push(events[i++].action);step(s,actions);}if(s.tick!==endTick)throw Error('Replay extends beyond collision');return s;}
