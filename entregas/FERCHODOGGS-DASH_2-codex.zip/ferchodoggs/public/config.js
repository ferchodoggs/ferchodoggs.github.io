export const config={
  // Full transparent original artwork, including feet. One URL for card and track.
  mascotUrl:null,
  competitionEnabled:false,
  whatsappNumber:'',
  // Supply actual catalog; no commercial information is fabricated.
  categories:[], products:[]
};
