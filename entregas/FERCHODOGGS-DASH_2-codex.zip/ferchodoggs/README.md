# FERCHODOGGS DASH — entrega local revisable

**Módulo independiente. Todavía NO está integrado en la tienda. No publicado.**
No se encontraron repositorio, capturas adjuntas, mascota ni skill professional-web-gamecraft. Se implementó con la especificación escrita. No hay acceso a Claude ni al hosting de la tienda.

## Ejecutar

Node 22 o superior. Cero dependencias externas; no requiere instalación de paquetes.

```sh
cd ferchodoggs
npm start
# http://127.0.0.1:3000
npm run lint
npm test
npm run build
```

`dist/` es la salida estática. Servir por HTTP, no file://. Para verificación usar `server.mjs`, que sirve frontend y API del mismo origen. Variables de ejemplo en `.env.example`; exportarlas en el shell antes de ejecutar. `public/config.js` es público y nunca debe contener secretos.

```sh
docker build -t ferchodoggs-review .
docker run --rm -p 3000:3000 ferchodoggs-review
```

## Configuración

En `public/config.js`, configurar `mascotUrl` con PNG/WebP transparente del cuerpo completo. La misma URL alimenta tarjeta, inicio y pista. El marcador punteado ASSET es exclusivo de desarrollo. Para pruebas de carga usar una URL inexistente. No está incluido el arte original.

El catálogo está vacío deliberadamente. `categories: [{id, name}]`, `products: [{id, name, category, price}]`, `currency` y `whatsappNumber` (solo dígitos internacionales) deben proceder de datos reales. El carrito incluido es básico y usa su propia clave; configuradores de ingredientes, variantes y salsas reales deben conservarse desde la tienda, según CLAUDE_HANDOFF.md. No sustituir un carrito real con este adaptador básico.

## Motor y API

`dash-1.0.0`: simulación a 60 pasos/s; render separado por requestAnimationFrame; tres carriles discretos; salto 48 ticks; colisión en el tick de contacto si altura de salto < 0.65; final a 3600 ticks. Puntuación = ticks sobrevividos. Dos obstáculos por fila y siempre un carril libre; separación de 100 ticks. Obstáculos son cajas/barreras del mismo volumen lógico. El cambio de carril es instantáneo, igual en imagen y simulación.

`POST /api/session` emite ID aleatorio, semilla de servidor y versión. `POST /api/submit`: `{id, version, events:[{tick,action}], endTick}`. No acepta score como autoridad: reproduce y calcula. Duración mínima real, vencimiento 120 s, intentos de un solo uso, tamaño de petición y frecuencia limitados. Errores: 400, 409, 413, 429. `competitionEnabled: true` habilita un **intento verificable de desarrollo**, no una competición pública ni tabla de localStorage.

El servidor es verificable localmente, pero usa memoria y límites por proceso/IP. No es un backend de premios listo para producción. Para competición real se requieren autenticación, persistencia, consumo atómico de intentos, límites distribuidos, política de pausas, antiautomatización y auditoría. Reproducir acciones demuestra consistencia, no que las ejecutara una persona. No se anuncian premios ni ganadores.

Nunca cambiar reglas de una competición activa: conservar su versión y validador; publicar nueva versión con namespace separado. No hay contrato previo disponible para integrar.

Ver TEST_REPORT.md y CLAUDE_HANDOFF.md.
