# FERCHODOGGS DASH: contratos del módulo

## Estado y límites

Este módulo es integrable en una tienda existente. No incluye pedidos ni cambia el catálogo. Práctica no necesita cuenta ni base de datos. Competición y premios están desactivados inicialmente; no se han publicado ni se ha verificado un servicio de identidad en producción.

Motor compartido: `ferchodoggs-dash/1.0.0`, 60 ticks/segundo, máximo 36.000 ticks. El servidor importa exactamente el mismo módulo que el cliente. Cada acción se aplica **antes de `step()` en el tick indicado**. Se permite una acción por tick, en orden estrictamente creciente, y un máximo de 5.000 acciones por envío. La puntuación es `floor(tick / 6) + 25 * fichas`; el cliente no puede declarar una puntuación clasificatoria.

## Identidad, acceso y transporte

La implementación de producción espera un proxy de autenticación autorizado que elimine cualquier cabecera `oai-authenticated-user-id` enviada por el visitante y la sustituya por su identidad verificada. En Sites corresponde al borde de la plataforma; **publicar el Worker directamente confiando en una cabecera arbitraria sería inseguro**. El servidor local proporciona un mecanismo exclusivo de desarrollo; no sirve como verificación de identidad real ni habilita premios.

La identidad privada es estable e independiente del alias público. Un alias o @ no prueba propiedad de una red social. `ADMIN_USER_IDS` es una lista privada de identidades autorizadas, separadas por comas; no se expone al navegador. Sin esta configuración, no hay administradores.

Las escrituras requieren `Content-Type: application/json` y una cabecera `Origin` exactamente igual al origen de la API. El cuerpo tiene un máximo de 256 KiB, comprobado durante la lectura. No hay CORS abierto. Para integrar el módulo en otro dominio, colocar API y cliente bajo el mismo origen mediante un proxy seguro; no suprimir el control de origen.

## Rutas

| Método y ruta | Entrada / resultado |
| --- | --- |
| GET `/api/health` | `{ok, engine, practice}`; no genera pedidos ni analítica. |
| GET `/api/status` | Estado independiente de práctica, competición, reglas propuestas/configuradas y analítica. |
| GET `/api/leaderboard` | Semana `[start,end)`, zona, reglas, premio confirmado o `null`, filas `{rank,alias,score,status}`, ganadores aprobados anteriores. Nunca devuelve la identidad privada. |
| GET `/api/me` | Requiere identidad. Alias público y autorización administrativa de la sesión actual. |
| POST `/api/profile` | `{alias}`. Actualiza la misma identidad; no crea otra fila semanal. |
| POST `/api/runs/start` | `{requestId}`. Emite `{run:{id,seed,version,weekId,createdAt,expiresAt,maxRealSeconds,maxPauseSeconds,status},reused}`. Reintentar la misma clave devuelve la misma partida. Otra clave con una partida activa devuelve 409. |
| GET `/api/runs/:id` | Estado y puntuación calculada; solo el propietario. Permite resolver un envío cuya respuesta se perdió. |
| POST `/api/runs/finish` | `{id,version,actions:[{tick,type}],endTick}`. Devuelve `{status,score,duplicate}` calculado mediante reproducción del servidor. `type`: `left`, `right`, `jump`. Un campo `score` provoca 400. |
| POST `/api/runs/abandon` | `{id}`. Solo propietario. Expira una partida activa para liberar su plaza. Reintento idempotente; nunca elimina un resultado ya aceptado. |
| GET `/api/admin` | Configuración privada, semanas, resultados en revisión/invalidación, auditoría y estado real del programador. |
| POST `/api/admin` | Acciones administrativas descritas debajo. |
| POST `/api/events` | Analítica opcional con consentimiento y deduplicación. No acepta `purchase`. |

## Validación, concurrencia y resultados

No se acepta una partida ajena, vencida, con versión distinta, acciones duplicadas/desordenadas, duración imposible o un final que no sea colisión o límite de diez minutos. Se permite hasta dos segundos de tolerancia en la relación entre tiempo real y simulado, cinco minutos acumulados de pausa y quince minutos reales como máximo. Al recibir el resultado fuera de la semana asignada, se rechaza sin moverlo retroactivamente. Los cortes de red o vencimientos no se etiquetan como fraude.

La finalización usa un hash canónico del registro y un lote transaccional: cambia el estado de la partida, inserta un resultado único y actualiza un único mejor resultado por identidad y semana. La repetición del mismo registro devuelve el resultado existente. Un registro diferente para una partida ya finalizada devuelve 409. SQLite/D1 impone unicidad en partida, clave de inicio, partida activa e identidad semanal. Los empates conservan la primera recepción válida por el servidor. Si dos recepciones comparten exactamente el mismo milisegundo, una secuencia única y duradera asignada dentro de la transacción resuelve el empate por orden de aceptación; no se ordena por alias ni identidad. Una nueva partida con el mismo valor no sustituye el primer logro de esa identidad.

La reproducción determinista valida la simulación, no demuestra que una persona jugó ni impide automáticamente todos los bots. Los candidatos a premio requieren revisión humana.

## Administración

`{action:"config",config:{enabled,confirmed,timezone,closeDay,closeHour,prize,eligibility,delivery,claim,rules}}` guarda la configuración. Para activar se necesitan confirmación explícita y todos los textos de la promoción. Los valores iniciales `America/Caracas`, domingo (`closeDay:0`) a las 20:00 son **propuestas configurables**, no preferencias confirmadas del negocio.

Una semana que ya admite partidas conserva su instantánea de reglas y versión. Mientras siga abierta, solo se puede pausar o reanudar con las mismas reglas:

- `{action:"disable",reason}` pausa la competición sin borrar resultados.
- `{action:"config",config}` con la misma instantánea y `enabled:true` la reanuda.
- `{action:"review",runId,reason}` aparta un resultado de la clasificación para revisarlo.
- `{action:"invalidate",runId,reason}` invalida con motivo y recalcula el mejor resultado anterior de esa identidad.
- `{action:"freeze",weekId}` solo puede congelar un periodo ya terminado.
- `{action:"approve",weekId,candidateId,revision,reason}` aprueba al candidato calculado para una semana cerrada.
- `{action:"delivered",weekId,winnerId,revision,reason}` registra la entrega una sola vez después de la aprobación.
- `{action:"report"}` genera y persiste un informe idempotente de la semana natural anterior en `Europe/Madrid` y la precedente.

La revisión debe utilizar `candidate_id`, `winner_id` y `revision` devueltos por la consulta administrativa. Si cambiaron desde que se revisó la pantalla, se rechaza la decisión y hay que recargar. La API usa control de revisión y un identificador de mutación dentro de la transacción para impedir que aprobación, invalidación y entrega se crucen silenciosamente. La entrega no puede registrar un ganador invalidado; una invalidación no puede alterar una entrega ya registrada.

No existe una operación de edición silenciosa de puntuación. Configuración, revisión, invalidación, cierre, aprobación y entrega dejan auditoría. Invalidar un resultado de una semana congelada recalcula candidato y exige nueva aprobación. Una entrega ya registrada bloquea invalidaciones automáticas y requiere revisión aparte.

`maintenance(env)` congela semanas cerradas, selecciona candidato y expira sus partidas activas de forma idempotente. Las lecturas públicas ejecutan recuperación de cierres pendientes; un cierre puntual sin tráfico requiere conectar un programador persistente. El módulo no declara que ese programador esté activo.

## Analítica y privacidad

Entrada: `{id,sessionId,name,consent:true,properties:{...}}`. `id` deduplica un evento; `sessionId` es aleatorio y no identifica una persona verificada. Permitidos: `page_view`, `mascot_interaction`, `game_open`, `game_start`, `game_end`, `game_abandon`, `leaderboard_view`, `product_view`, `buy_click`, `checkout_start`.

Propiedades permitidas: `mode`, `productId`, `orderId`, `path` sin query, `source` (`instagram`, `direct`, `other`, `unknown`), `medium`, `campaign`, `score` local/informativa, `version`, `engineVersion`, `ticks`, `reason`. Se limitan longitud, caracteres y rangos; no se admite correo, IP, tokens ni propiedades arbitrarias. No enviar datos personales dentro de etiquetas. El visitante puede rechazar analítica y seguir jugando. No hay evento `purchase` de cliente: una integración futura debe generarlo exclusivamente después de una confirmación fiable de pedido/pago y deduplicarlo en servidor.

Los informes calculan eventos consentidos, sesiones estimadas y resultados válidos. No inventan visitantes únicos ni compras confirmadas. Las tres propuestas de revisión son guías para analizar métricas; no se presentan como conclusiones de IA basadas en datos inexistentes. Canal de entrega, programación de lunes a las 09:00 en `Europe/Madrid`, logs externos, reintentos de entrega y monitorización externa siguen pendientes de integración y verificación.

## Respuestas de error

Formato: `{error:{code,message}}`. 400/415/413: entrada; 401: falta identidad; 403: origen o permisos; 404: no existe o no pertenece al usuario; 409: conflicto/semana cerrada/competición desactivada; 410: vencimiento; 422: reproducción/tiempo inválidos; 429: demasiados inicios; 503: red o servicio no disponible. Un 503 no indica éxito ni fraude; conservar el registro y consultar la partida o reintentar el mismo envío. Las respuestas no exponen secretos ni trazas internas.

## Migraciones

Aplicar `drizzle/0000_initial.sql`, `drizzle/0001_admin_concurrency.sql` y `drizzle/0002_receipt_order.sql` en orden. La tercera añade la secuencia duradera de recepción; la segunda añade la revisión y el identificador de mutación necesarios para las garantías de concurrencia administrativa. El adaptador local conserva `PRAGMA user_version` y solo aplica archivos nuevos; no borra datos ni reproduce migraciones ya aplicadas. No modificar SQL aplicado: añadir una migración posterior. En producción se necesita el mecanismo de migraciones del proveedor y respaldo antes de publicar.
