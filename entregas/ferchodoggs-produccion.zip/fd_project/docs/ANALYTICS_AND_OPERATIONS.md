# Analítica, informe y monitorización: puntos de integración

## Estado comprobado

- Código cliente con consentimiento opcional y eventos deduplicados en servidor SQLite.
- Evento `ferchodoggs:analytics` para el proveedor del host: usar su `id` como deduplicador; escoger este emisor o la captura automática, no ambos.
- No hay cuenta de proveedor analítico conectada, alertas, envío ni tarea periódica activa.
- El servidor local es un entorno de desarrollo, no una fuente pública de resultados o ventas verificadas.

## Eventos

| Evento | Disparador | Origen y propiedades |
| --- | --- | --- |
| page_view | Primera vista consentida de esta página; no se repite al alternar preferencias | Cliente; source según UTM/referrer, sin URL completa |
| mascot_interaction | Un click nativo sobre el control; teclado activa ese mismo click | Cliente; reason original/temporary |
| game_open | Apertura efectiva del dialog | Cliente; mode |
| game_start | Inicio efectivo de simulación, no continuar tras pausa | Cliente; mode, engineVersion |
| game_end | Colisión o límite, una vez por partida | Cliente; mode, score informativo, ticks, engineVersion |
| game_abandon | Cierre de una partida iniciada y no terminada | Cliente; mode,ticks,reason |
| leaderboard_view | Primera entrada de la sección en pantalla | Cliente; sin identidad privada |
| product_view | Punto reservado para el producto visible en la tienda real | Host; productId |
| buy_click | Click de salida hacia pedido/WhatsApp | Host; productId opcional; nunca equivale a venta |
| checkout_start | Inicio real del checkout del host | Host; sin teléfono/dirección/texto del pedido |
| purchase | Solo confirmación fiable de pedido/pago | Exclusivamente servidor del host, con identificador único; este módulo rechaza el evento de cliente |

`sessionId` aleatorio en sessionStorage estima sesiones consentidas. No hay identificador de persona o visitante único persistente. Rechazar consentimiento no bloquea juego ni compras. No emitir correos, IP, tokens, alias ni texto libre de pedidos. Retención y borrado requieren definir una política antes de recopilar en producción.

Ejemplo de enlace Instagram: `https://TU-TIENDA/?utm_source=instagram&utm_medium=social&utm_campaign=dash`. Tráfico directo no se reclasifica como Instagram. El código actual registra source; si se amplían medium/campaign, pasar solo etiquetas de campaña aprobadas, nunca datos personales.

## Informe semanal

`POST /api/admin` con `{action:'report'}` genera una fila única por fin del periodo. Agrega la semana natural anterior de `Europe/Madrid` y la precedente; días de23/25h no se fuerzan a UTC. Las métricas son consentidas y las compras confirmadas permanecen `null` sin integración fiable.

Programación objetivo: lunes09:00 Europe/Madrid. Pendientes: programador persistente desplegado, acceso de servicio independiente de sesión humana, canal de entrega, worker de outbox, logs y alertas. Esquema `reports` tiene id, estado, intentos, próximo reintento y entrega. No se ha implementado ni declarado activo un envío automático. Un futuro worker deberá reclamar atómicamente la fila pendiente, reintentar con backoff y clave idempotente, y guardar/readback del acuse antes de marcar entregado. Verificar ejecución sin esperar al lunes.

El informe contiene tres guías de revisión explícitas; no son un análisis de IA ya conectado. Una revisión futura puede preparar rama/pruebas. Catálogo, pagos, seguridad y diseño importantes necesitan aprobación antes de publicar cambios.

## Salud y rutas

`GET /api/health` comprueba proceso/motor sin crear eventos, pedidos o pagos. `GET /api/status` distingue práctica, competición y disponibilidad de analítica. `scripts/healthcheck.mjs` valida rutas y assets por HTTP sin producir transacciones reales. Antes de alojar, comprobar que el healthcheck pasa frente a la URL final y que un monitor externo alerta ante fallo. Ningún monitor está conectado por existir este script.

En local, el adaptador aplica migraciones transaccionales ordenadas; producción usa D1/migrador del host. Respaldar antes de cambios y mantener auditoría. Nunca usar el servidor de desarrollo expuesto a Internet.
