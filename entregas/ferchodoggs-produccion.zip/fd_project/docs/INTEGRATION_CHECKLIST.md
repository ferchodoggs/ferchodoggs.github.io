# Comprobaciones pendientes para integrar FERCHODOGGS DASH

Este documento es una lista de aceptación para la integración en la tienda real. **Las comprobaciones de navegador y teléfono que aparecen abajo no se han ejecutado.** El entorno de esta entrega no ofrecía la herramienta de navegador requerida para Sites. Leer HTML/CSS o aprobar una prueba de código no sustituye estas comprobaciones.

## Integración en el proyecto existente

- [ ] Consultar `PROJECT_STATE.md`, las instrucciones del repositorio receptor y su carrito antes de integrar.
- [ ] Integrar el módulo `dist/client/assets/ferchodoggs-dash.js`, no la página de demostración ni su `main.js`.
- [ ] Incluir únicamente la hoja del juego `dash.css`. `styles.css` pertenece a la demostración y contiene estilos globales de `body`, enlaces, botones y tipografía que no deben aplicarse a la tienda.
- [ ] Configurar `CONFIG.apiBase` para el backend real y comprobar que las rutas `/api` no sustituyen rutas existentes.
- [ ] Configurar el archivo **original** en `CONFIG.mascotUrl`; revisar visualmente dibujo, proporciones, mano, hot dog y tres rayas sobre el pulgar. No recortar ni redibujar para adaptar la imagen al lienzo.
- [ ] Mantener identificados los recursos temporales hasta recibir la mascota original. No presentar una ficha neutra como la mascota aprobada.
- [ ] Montar una sola instancia del juego; llamar a `destroy()` cuando se desmonte la vista receptora.
- [ ] Probar apertura mediante API del módulo y mediante un botón real de la tienda; el selector `[data-game-open]` se registra al montar, por lo que los botones añadidos después deben enlazarse explícitamente.

## Compra y aislamiento del módulo

- [ ] Guardar un carrito con cantidades, variantes y extras antes de abrir el juego. Jugar, pausar, reintentar y cerrar; comprobar que el estado y los importes sean idénticos.
- [ ] Repetir con un carrito que se actualice mientras el juego esté cerrado y después de navegar entre rutas de la tienda.
- [ ] Comprobar que ninguna capa de mascota o juego tape productos, carrito, confirmación o botón de pedido.
- [ ] Comparar almacenamiento antes y después: únicamente deben cambiar las claves del espacio `ferchodoggs-dash:v1:` propiedad del módulo.
- [ ] Revisar que no se registren `purchase`, pedidos confirmados o conversiones de venta por jugar, abrir el juego o pulsar WhatsApp.

## Navegador y accesibilidad

- [ ] Revisar a 320, 390, 768 y 1440 píxeles. No debe haber desplazamiento horizontal del documento ni controles cortados.
- [ ] Revisar orientación horizontal, incluidas alturas de pantalla de 320 y 390 píxeles. El botón de comenzar y el de continuar deben seguir accesibles dentro de la superposición.
- [ ] Ampliar el texto al 200 % y usar zoom del navegador al 200 %. Revisar titulares, instrucciones, HUD, reglas, resultados y controles.
- [ ] Recorrer con Tab y Mayús+Tab: botón de abrir, inicio, controles, pausa, sonido y cierre. El foco debe ser visible y permanecer dentro del diálogo abierto.
- [ ] Cerrar con el botón y con Escape; comprobar restauración del foco al control de apertura y restauración exacta del desplazamiento de la tienda.
- [ ] Comprobar flechas, Espacio y P sin desplazar accidentalmente la página ni impedir el uso normal de casillas y botones.
- [ ] Revisar las instrucciones y el estado final con lector de pantalla. El lienzo tiene instrucciones de teclado, pero el juego requiere percepción espacial; no declarar accesibilidad completa solo por tener etiquetas.
- [ ] Activar `prefers-reduced-motion` y confirmar que la reacción de la mascota no se anime. Comprobar que el juego siga ofreciendo pausa y cierre.
- [ ] Confirmar contraste y tamaño táctil de los botones sobre el diseño de la tienda, no solo sobre la demostración.

## Mascota, privacidad y estados reales

- [ ] Mostrar exactamente «👆 TÓCAME, MOR 💚», «Tengo una sorpresa para ti 🎮» y un botón cercano «🎮 JUGAR».
- [ ] Activar la mascota con dedo, ratón, Enter y Espacio: una sola frase y un evento por interacción, sin repetición inmediata.
- [ ] Confirmar que el sonido esté apagado al abrir cada sesión y que nunca se reproduzca automáticamente.
- [ ] Rechazar analítica y confirmar en la pestaña de red que no se envíen eventos opcionales; comprar y practicar deben seguir disponibles.
- [ ] Aceptar, rechazar y volver a aceptar analítica. Comprobar la deduplicación de `page_view` y la ausencia de correos, teléfonos, IP, tokens o contenido del carrito en eventos.
- [ ] Configurar competición desactivada: no debe haber filas, premios ni ganadores ficticios.
- [ ] Solo en un entorno de prueba configurado, activar competición y comprobar que se retiren los textos estáticos que la describían como no disponible.
- [ ] Simular pérdida de red al consultar clasificación y enviar resultados. Mostrar indisponibilidad o envío pendiente; nunca éxito ni resultado verificado sin respuesta válida del servidor.

## Teléfonos y ciclo de vida

- [ ] Probar en teléfonos físicos Android e iOS. Distinguir estos resultados de una emulación de navegador.
- [ ] Comprobar toque, deslizamiento horizontal y botones alternativos sin doble entrada por el mismo gesto.
- [ ] Bloquear pantalla, cambiar de aplicación, ocultar pestaña y volver. La simulación debe estar pausada, sin puntos obtenidos durante la interrupción.
- [ ] Abrir, reintentar y cerrar repetidamente. Revisar que no aumenten listeners, observers, bucles de animación o contextos de audio tras cada ciclo.
- [ ] Revisar coincidencia visual de carril, salto e impactos con grabación a cámara lenta cuando sea posible.
- [ ] Comparar una misma reproducción en pantallas de 60 y 120 Hz; comparar ticks y resultado del motor, sin atribuir una prueba de simulación a un teléfono no utilizado.

## Publicación

- [ ] Ejecutar lint, tipos, pruebas y build sobre el repositorio integrado y conservar sus resultados.
- [ ] Revisar variables, permisos, migraciones y assets del hosting real. No habilitar premios sin reglas, elegibilidad, entrega y reclamación aprobadas.
- [ ] Abrir la URL HTTPS desde una sesión anónima y comprobar rutas directas, assets y metadatos sociales.
- [ ] Comprobar tienda, carrito y recorrido de pedido después del despliegue con datos de prueba; no generar pagos ni pedidos reales como control de salud.
- [ ] Registrar versión desplegada, comprobaciones efectivamente ejecutadas, limitaciones y procedimiento de rollback.
