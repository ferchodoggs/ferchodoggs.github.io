import {describe,it} from 'node:test';
import assert from 'node:assert/strict';
import {createLocalDatabase} from '../src/server/local-db.ts';
import {handleApi,type Env} from '../src/server/api.ts';
import worker from '../src/worker.ts';

const SECRET='x'.repeat(48); const SHOP='https://ferchodoggs.github.io'; const API='https://api.example.test';
function setup(extra:Partial<Env>={}){const local=createLocalDatabase();const env:Env={DB:local.db,SESSION_SECRET:SECRET,ALLOWED_ORIGINS:SHOP,clock:()=>Date.UTC(2026,10,17,12),...extra};return env;}
const call=(env:Env,path:string,{body,token,origin=SHOP,method}:{body?:unknown;token?:string;origin?:string|null;method?:string}={})=>{
  const headers:Record<string,string>={}; if(body!==undefined)headers['content-type']='application/json'; if(token)headers.authorization='Bearer '+token; if(origin)headers.origin=origin;
  return (worker as {fetch:(r:Request,e:Env)=>Promise<Response>}).fetch(new Request(API+path,{method:method??(body===undefined?'GET':'POST'),headers,body:body===undefined?undefined:JSON.stringify(body)}),env);
};

describe('Identidad propia por dispositivo y CORS de la tienda', () => {
  it('emite un token firmado y lo reconoce en /api/me', async () => {
    const env=setup(); const r=await call(env,'/api/session',{body:{}}); assert.equal(r.status,200);
    const s=await r.json() as {id:string;token:string}; assert.match(s.id,/^p_/); assert.ok(s.token.startsWith(s.id+'.'));
    const me=await call(env,'/api/me',{token:s.token}); assert.equal(me.status,200); assert.equal((await me.json() as {authenticated:boolean}).authenticated,true);
  });
  it('rechaza tokens alterados, inventados o de otro secreto', async () => {
    const env=setup(); const s=await (await call(env,'/api/session',{body:{}})).json() as {id:string;token:string};
    const forged='p_00000000-0000-4000-8000-000000000000.'+s.token.split('.')[1];
    for(const t of [s.token.slice(0,-2)+'aa',forged,'cualquiera']) assert.equal((await call(env,'/api/me',{token:t})).status,401);
    const other=setup({SESSION_SECRET:'y'.repeat(48)}); assert.equal((await call(other,'/api/me',{token:s.token})).status,401);
  });
  it('en producción ignora la cabecera de identidad heredada', async () => {
    const env=setup(); const r=await handleApi(new Request(API+'/api/me',{headers:{'oai-authenticated-user-id':'atacante'}}),env); assert.equal(r.status,401);
  });
  it('sin SESSION_SECRET el servidor crea su propia clave una vez, la guarda en la base y la reutiliza', async () => {
    const env=setup({SESSION_SECRET:undefined});
    const a=await (await call(env,'/api/session',{body:{}})).json() as {token:string}; assert.ok(a.token);
    assert.equal((await call(env,'/api/me',{token:a.token})).status,200);
    const row=await env.DB!.prepare("SELECT value FROM app_secrets WHERE id='session'").first<{value:string}>(); assert.equal(row?.value.length,64);
    const b=await (await call(env,'/api/session',{body:{}})).json() as {token:string}; assert.equal((await call(env,'/api/me',{token:b.token})).status,200);
  });
  it('sin base ni clave no emite sesiones (503) y la práctica no depende de ello', async () => {
    const env:Env={ALLOWED_ORIGINS:SHOP}; assert.equal((await call(env,'/api/session',{body:{}})).status,503);
    assert.equal((await call(env,'/api/health')).status,200);
  });
  it('sin ALLOWED_ORIGINS se permite por defecto solo la tienda', async () => {
    const env=setup({ALLOWED_ORIGINS:undefined}); const ok=await call(env,'/api/leaderboard'); assert.equal(ok.headers.get('access-control-allow-origin'),SHOP);
    assert.equal((await call(env,'/api/session',{body:{},origin:'https://otra.example'})).status,403);
  });
  it('CORS solo para la tienda: preflight y cabeceras para ferchodoggs.github.io, nada para otros orígenes', async () => {
    const env=setup();
    const pre=await call(env,'/api/runs/start',{method:'OPTIONS'}); assert.equal(pre.status,204); assert.equal(pre.headers.get('access-control-allow-origin'),SHOP); assert.match(pre.headers.get('access-control-allow-headers')??'',/authorization/);
    const evil=await call(env,'/api/session',{body:{},origin:'https://malo.example'}); assert.equal(evil.status,403); assert.equal(evil.headers.get('access-control-allow-origin'),null);
    const ok=await call(env,'/api/leaderboard'); assert.equal(ok.headers.get('access-control-allow-origin'),SHOP);
  });
  it('clasificación sin premio: con token se juega, el alias es público y la partida queda registrada', async () => {
    const env=setup(); const db=env.DB!;
    await db.prepare('INSERT OR REPLACE INTO settings(id,config_json) VALUES(1,?)').bind(JSON.stringify({enabled:true,confirmed:false,timezone:'America/Caracas',closeDay:0,closeHour:20,prize:'',eligibility:'',delivery:'',claim:'',rules:'Clasificación semanal sin premio.'})).run();
    const s=await (await call(env,'/api/session',{body:{}})).json() as {token:string};
    assert.equal((await call(env,'/api/profile',{body:{alias:'Maria_VE'},token:s.token})).status,200);
    const started=await call(env,'/api/runs/start',{body:{requestId:'req-session-0001'},token:s.token}); assert.equal(started.status,201);
    const st=await started.json() as {run:{id:string;version:string;seed:number}}; assert.ok(st.run.id);
    const board=await (await call(env,'/api/leaderboard')).json() as {enabled:boolean;rules:{prize:string|null}}; assert.equal(board.enabled,true);
    assert.equal((await call(env,'/api/runs/start',{body:{requestId:'req-session-0002'}})).status,401,'sin token no se compite');
  });
});
