import {test} from 'node:test';
import assert from 'node:assert/strict';
import {periodAt, compareResults, naturalReportPeriod, validateWeekConfig} from '../src/server/weekly.ts';

test('weekly 1: Caracas Sunday 20:00 boundary is start-inclusive and end-exclusive', () => {
  const boundary = Date.parse('2026-11-16T00:00:00.000Z');
  const before = periodAt(boundary - 1), at = periodAt(boundary);
  assert.equal(before.end, boundary);
  assert.equal(at.start, boundary);
  assert.notEqual(before.id, at.id);
  assert.equal(at.end - at.start, 7 * 86_400_000);
});

test('weekly 2: consecutive periods have no gap or overlap across year boundaries', () => {
  let week = periodAt(Date.parse('2026-12-30T18:10:00Z'));
  for (let count = 0; count < 55; count++) {
    const next = periodAt(week.end);
    assert.equal(next.start, week.end);
    assert.equal(periodAt(week.end - 1).id, week.id);
    week = next;
  }
});

test('weekly 3: configurable weekday, hour and zone govern closing', () => {
  const config = {timezone: 'Asia/Kolkata', closeDay: 3, closeHour: 9};
  const result = periodAt(Date.parse('2026-11-18T03:30:00Z'), config);
  assert.equal(result.start, Date.parse('2026-11-18T03:30:00Z'));
  assert.equal(result.end, Date.parse('2026-11-25T03:30:00Z'));
  assert.equal(result.timezone, 'Asia/Kolkata');
});

test('weekly 4: Madrid daylight-saving transitions preserve local closing time', () => {
  const config = {timezone: 'Europe/Madrid', closeDay: 0, closeHour: 20};
  const spring = periodAt(Date.parse('2026-03-25T12:00:00Z'), config);
  const autumn = periodAt(Date.parse('2026-10-21T12:00:00Z'), config);
  assert.equal(spring.start, Date.parse('2026-03-22T19:00:00Z'));
  assert.equal(spring.end, Date.parse('2026-03-29T18:00:00Z'));
  assert.equal(autumn.end - autumn.start, 169 * 3_600_000);
  assert.equal(spring.end - spring.start, 167 * 3_600_000);
});

test('weekly 5: score ranks first and equal scores use first valid server receipt', () => {
  const values = [{score: 25, receivedAt: 10}, {score: 30, receivedAt: 20}, {score: 30, receivedAt: 5}];
  assert.deepEqual(values.sort(compareResults), [
    {score: 30, receivedAt: 5}, {score: 30, receivedAt: 20}, {score: 25, receivedAt: 10},
  ]);
});

test('weekly 6: invalid configuration and timestamps fail rather than selecting arbitrary periods', () => {
  assert.throws(() => periodAt(NaN), RangeError);
  assert.throws(() => validateWeekConfig({timezone: 'Mars/Olympus', closeDay: 0, closeHour: 20}), RangeError);
  assert.throws(() => validateWeekConfig({timezone: 'UTC', closeDay: 7, closeHour: 20}), RangeError);
  assert.throws(() => validateWeekConfig({timezone: 'UTC', closeDay: 0, closeHour: 24}), RangeError);
});

test('weekly 7: Monday report covers prior Madrid natural week and preceding comparison across DST', () => {
  const report = naturalReportPeriod(Date.parse('2026-03-30T07:00:00Z'));
  assert.equal(report.start, Date.parse('2026-03-22T23:00:00Z'));
  assert.equal(report.end, Date.parse('2026-03-29T22:00:00Z'));
  assert.equal(report.previous.start, Date.parse('2026-03-15T23:00:00Z'));
  assert.equal(report.previous.end, report.start);
  assert.equal(report.end - report.start, 167 * 3_600_000);
  assert.equal(report.timezone, 'Europe/Madrid');
});
