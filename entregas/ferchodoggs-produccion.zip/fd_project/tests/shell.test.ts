import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

const html = readFileSync(new URL('../public/index.html', import.meta.url), 'utf8');
const css = readFileSync(new URL('../public/styles.css', import.meta.url), 'utf8');

describe('Shell: seven source checks (not browser accessibility or responsive validation)', () => {
  it('declares Spanish and a zoomable device-width viewport', () => {
    assert.match(html, /<html lang="es">/);
    assert.match(html, /name="viewport" content="width=device-width, initial-scale=1"/);
    assert.doesNotMatch(html, /user-scalable\s*=\s*no|maximum-scale/);
    assert.equal((html.match(/<h1\b/g) || []).length, 1);
  });

  it('has unique IDs and every in-page navigation target exists', () => {
    const ids = [...html.matchAll(/\bid="([^"]+)"/g)].map(match => match[1]);
    assert.equal(new Set(ids).size, ids.length);
    for (const match of html.matchAll(/href="#([^"]+)"/g)) {
      assert.ok(ids.includes(match[1]), `Missing anchor ${match[1]}`);
    }
    assert.match(html, /class="skip-link" href="#main"/);
  });

  it('provides explicit button types and accessible visible labels', () => {
    for (const match of html.matchAll(/<button\b([^>]*)>([\s\S]*?)<\/button>/g)) {
      assert.match(match[1], /\btype="button"/);
      assert.ok(match[2].replace(/<[^>]*>/g, '').trim().length > 0);
    }
    assert.ok((html.match(/data-game-open/g) || []).length >= 3);
  });

  it('explains touch, keyboard, alternative controls and both obstacle types', () => {
    assert.match(html, /Desliza a izquierda o derecha/);
    assert.match(html, /<kbd>Espacio<\/kbd>/);
    assert.match(html, /<kbd>←<\/kbd>/);
    assert.match(html, /obstáculos bajos/);
    assert.match(html, /altos se esquivan/);
    assert.match(html, /botones de control en pantalla/);
  });

  it('publishes the fixed scoring formula, duration and local-record scope', () => {
    assert.match(html, /PUNTUACIÓN = ⌊10 × SEGUNDOS SIMULADOS⌋ \+ 25 × FICHAS/);
    assert.match(html, /10<span>MIN/);
    assert.match(html, /récord de práctica se guarda en este navegador/);
  });

  it('does not advertise active prizes, participants or the neutral token as a mascot', () => {
    assert.match(html, /COMPETICIÓN NO ACTIVA/);
    assert.match(html, /reglas estén definidas y aprobadas/);
    assert.match(html, /no representa la mascota original/);
    assert.doesNotMatch(html, /<table|pedido confirmado|compra confirmada|ganador de la semana/i);
  });

  it('defines narrow-screen layouts, keyboard focus and reduced-motion treatment', () => {
    assert.match(css, /@media\(max-width:360px\)/);
    assert.match(css, /@media\(max-width:520px\)/);
    assert.match(css, /@media\(prefers-reduced-motion:reduce\)/);
    assert.match(css, /:focus-visible/);
    assert.match(css, /min-height:44px/);
    assert.doesNotMatch(css, /@import|https?:\/\//);
  });
});
