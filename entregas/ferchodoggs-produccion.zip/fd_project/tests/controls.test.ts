import {describe,it} from 'node:test';
import assert from 'node:assert/strict';
import {FixedClock,InputQueue,keyboardAction,pointerAction} from '../src/game/clock.ts';
import {createGame,step} from '../src/game/engine.ts';
describe('Controls and lifecycle scheduler: seven execution checks',()=>{
  it('30,60,90,120,144Hz produce the same ticks and points',()=>{
    for(const hz of [30,60,90,120,144]){const clock=new FixedClock();let state=createGame(1);clock.resume();for(let n=0;n<=hz*2;n++)clock.advance(n*1000/hz,()=>{state=step(state);return true;});assert.equal(state.tick,120);assert.equal(state.score,20);}
  });
  it('keyboard arrows and space map correctly and autorepeat is ignored',()=>{
    assert.equal(keyboardAction('ArrowLeft'),'left');assert.equal(keyboardAction('ArrowRight'),'right');assert.equal(keyboardAction('ArrowUp'),'jump');assert.equal(keyboardAction(' '),'jump');assert.equal(keyboardAction(' ',true),null);assert.equal(keyboardAction('Tab'),null);
  });
  it('touch taps and deliberate swipes give one action while scrolling does not',()=>{
    assert.equal(pointerAction(0,0,100),'jump');assert.equal(pointerAction(-80,10,150),'left');assert.equal(pointerAction(50,-5,200),'right');assert.equal(pointerAction(2,60,100),null);assert.equal(pointerAction(0,0,900),null);
  });
  it('rapid input is bounded and consumed only once per simulation tick',()=>{
    const queue=new InputQueue();for(let i=0;i<10;i++)queue.push('left');assert.equal(queue.consume(),'left');assert.equal(queue.consume(),'left');assert.equal(queue.consume(),'left');assert.equal(queue.consume(),undefined);queue.push('jump');queue.clear();assert.equal(queue.consume(),undefined);
  });
  it('paused background time grants no catch-up points on resume',()=>{
    const clock=new FixedClock();let ticks=0;const run=()=>{ticks++;return true;};clock.resume();clock.advance(0,run);clock.advance(100,run);assert.equal(ticks,6);clock.pause();clock.advance(100000,run);clock.resume();clock.advance(200000,run);assert.equal(ticks,6);clock.advance(200100,run);assert.equal(ticks,12);
  });
  it('a device interruption over250ms pauses without jumping through obstacles',()=>{
    const clock=new FixedClock();let ticks=0;clock.resume();clock.advance(0,()=>true);assert.equal(clock.advance(1000,()=>{ticks++;return true;}),'paused');assert.equal(ticks,0);assert.equal(clock.paused,true);
  });
  it('terminal simulation stops the scheduler and retry starts a fresh accumulator',()=>{
    const clock=new FixedClock();let ticks=0;clock.resume();clock.advance(0,()=>true);clock.advance(100,()=>{ticks++;return false;});assert.equal(ticks,1);assert.equal(clock.paused,true);clock.resume();clock.advance(1000,()=>true);clock.advance(1017,()=>{ticks++;return true;});assert.equal(ticks,2);
  });
});
