import {describe,it} from 'node:test';
import assert from 'node:assert/strict';
import {personalBest,readValue,writeValue,sanitizeProperties} from '../src/integration.ts';
import {createLocalDatabase} from '../src/server/local-db.ts';
import {assetResponse} from '../src/worker.ts';
import {api,finishRun,NetworkError,ApiFailure,type IssuedRun} from '../src/api-client.ts';
import {ENGINE_VERSION} from '../src/game/engine.ts';
describe('Integration, persistence, analytics and artifact contracts: seven checks',()=>{
  it('blocked browser storage does not prevent practice or personal-record access',()=>{
    const previous=Object.getOwnPropertyDescriptor(globalThis,'localStorage');Object.defineProperty(globalThis,'localStorage',{configurable:true,get(){throw Error('blocked');}});
    try{assert.equal(readValue('best'),null);assert.doesNotThrow(()=>writeValue('best','5'));assert.equal(personalBest(),0);assert.equal(personalBest(50),50);}finally{if(previous)Object.defineProperty(globalThis,'localStorage',previous);else Reflect.deleteProperty(globalThis,'localStorage');}
  });
  it('personal best uses only the module namespace and leaves host cart bytes intact',()=>{
    const store=new Map([['shop-cart','{"quantity":2}']]);const previous=Object.getOwnPropertyDescriptor(globalThis,'localStorage');Object.defineProperty(globalThis,'localStorage',{configurable:true,value:{getItem:(key:string)=>store.get(key)??null,setItem:(key:string,value:string)=>store.set(key,value)}});
    try{assert.equal(personalBest(60),60);assert.equal(personalBest(50),60);assert.equal(store.get('shop-cart'),'{"quantity":2}');store.set('ferchodoggs-dash:v1:best','Infinity');assert.equal(personalBest(),0);}finally{if(previous)Object.defineProperty(globalThis,'localStorage',previous);else Reflect.deleteProperty(globalThis,'localStorage');}
  });
  it('analytics removes personal and undeclared properties',()=>{
    assert.deepEqual(sanitizeProperties({email:'person@example.test',ip:'127.0.0.1',token:'secret',mode:'practice',score:10}),{mode:'practice',score:10});assert.deepEqual(sanitizeProperties({reason:'x'.repeat(500)}),{});
  });
  it('SQLite adapter rolls back the entire D1-style transaction on constraint failure',async()=>{
    const local=createLocalDatabase();try{await assert.rejects(local.db.batch([local.db.prepare('INSERT INTO participants VALUES(?,?,?)').bind('one','Uno',1),local.db.prepare('INSERT INTO participants VALUES(?,?,?)').bind('one','Dos',2)]));assert.equal(await local.db.prepare('SELECT id FROM participants').first(),null);}finally{local.close();}
  });
  it('static assets work without identity and traversal or unknown assets give404',async()=>{
    const assets={'/index.html':btoa('<html lang="es">DASH</html>')};const response=assetResponse('/',assets);assert.equal(response.status,200);assert.match(await response.text(),/DASH/);assert.match(response.headers.get('content-security-policy')??'',/object-src 'none'/);assert.equal(assetResponse('/../.env',assets).status,404);assert.equal(assetResponse('/unknown',assets).status,404);
  });
  it('API client distinguishes network failure from invalid data and never reports success',async()=>{
    const original=globalThis.fetch;try{globalThis.fetch=async()=>{throw Error('offline');};await assert.rejects(api('/status'),NetworkError);globalThis.fetch=async()=>new Response(JSON.stringify({error:{code:'invalid_replay',message:'Invalid'}}),{status:422});await assert.rejects(api('/runs/finish',{}),(error:unknown)=>error instanceof ApiFailure&&error.code==='invalid_replay');}finally{globalThis.fetch=original;}
  });
  it('finish client sends action replay and version but cannot declare a score',async()=>{
    const original=globalThis.fetch;let sent:Record<string,unknown>={};try{globalThis.fetch=async(_url,init)=>{sent=JSON.parse(String(init?.body));return new Response(JSON.stringify({status:'valid',score:12,duplicate:false}));};const run={id:'run-id',version:ENGINE_VERSION} as IssuedRun;const result=await finishRun(run,[{tick:5,type:'jump'}],72);assert.equal(result.score,12);assert.deepEqual(Object.keys(sent).sort(),['actions','endTick','id','version']);assert.equal(sent.version,ENGINE_VERSION);}finally{globalThis.fetch=original;}
  });
});
