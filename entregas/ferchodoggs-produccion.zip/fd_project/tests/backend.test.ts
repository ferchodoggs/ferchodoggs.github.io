import {test, describe} from 'node:test';
import assert from 'node:assert/strict';
import {createLocalDatabase} from '../src/server/local-db.ts';
import {handleApi} from '../src/server/api.ts';
import type {Env} from '../src/server/api.ts';
import {DEFAULT_CONFIG, validateActions, validateTiming} from '../src/server/validation.ts';
import {createGame,step,advanceWorld,jumpHeight,ENGINE_VERSION,TICK_RATE,JUMP_TICKS,MAX_CHUNK_TICKS} from '../src/game/engine.ts';
import type {RecordedAction,Action} from '../src/game/engine.ts';
const MAX_TICKS=36000;
/** Planificador exacto para pruebas: devuelve acciones que sobreviven `ticks` (programación dinámica con retroceso). */
function plan(seed:number,ticks:number):RecordedAction[]{
  const world=createGame(seed);const parents:Int16Array[]=[];const acts:Int8Array[]=[];let alive=new Set<number>([64]);
  const A:(Action|undefined)[]=[undefined,'left','right','jump'];
  for(let t=0;t<ticks;t++){const crossing=advanceWorld(world);world.tick++;const par=new Int16Array(192).fill(-1),act=new Int8Array(192);const next=new Set<number>();
    for(const key of alive){const l0=Math.floor(key/64),j0=key%64;for(let ai=0;ai<4;ai++){const a=A[ai];let l=l0,j=j0;if(a==='left')l=Math.max(0,l-1);if(a==='right')l=Math.min(2,l+1);if(a==='jump'&&j===0)j=JUMP_TICKS;if(j>0)j--;const air=jumpHeight({jumpTicks:j})>=0.45;if(crossing.some(e=>e.lane===l&&(e.type==='high'||(e.type==='low'&&!air))))continue;const k=l*64+j;if(par[k]===-1){par[k]=key;act[k]=ai;next.add(k);}}}
    if(!next.size)throw new Error('sin salida');parents.push(par);acts.push(act);alive=next;}
  let key=[...alive][0]!;const out:RecordedAction[]=[];
  for(let t=ticks-1;t>=0;t--){const ai=acts[t]![key]!;if(ai>0)out.push({tick:t,type:A[ai] as Action});key=parents[t]![key]!;}
  return out.reverse();
}
import {periodAt} from '../src/server/weekly.ts';


/** Semilla fija cuya partida sin entradas termina dentro del primer bloque (pruebas deterministas). */
function quickSeed():number{for(let s=1;s<10000;s++){let g=createGame(s);while(g.status==='running'&&g.tick<MAX_CHUNK_TICKS)g=step(g);if(g.status==='dead')return s;}throw new Error('sin semilla');}
const QUICK=quickSeed();
function setup() {
  const local=createLocalDatabase();
  const db=local.db;
  let now=Date.parse('2026-11-16T12:00:00Z');
  const env:Env={DB:db,ADMIN_USER_IDS:'owner',TRUST_IDENTITY_HEADER:'1',clock:()=>now};
  const config={...DEFAULT_CONFIG,enabled:true,confirmed:true,prize:'Premio de prueba',eligibility:'Solo pruebas',delivery:'Entrega de prueba',claim:'Reclamación de prueba',rules:'Reglas de prueba'};
  async function enable(){await db.prepare('INSERT INTO settings(id,config_json) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET config_json=excluded.config_json').bind(JSON.stringify(config)).run();}
  async function call(path:string,body?:unknown,user:string|null='player',extra:Record<string,string>={}) {
    const headers:Record<string,string>={origin:'https://example.test','content-type':'application/json',...extra};
    if(user)headers['oai-authenticated-user-id']=user;
    const response=await handleApi(new Request(`https://example.test${path}`,{method:body===undefined?'GET':'POST',headers,body:body===undefined?undefined:JSON.stringify(body)}),env);
    return {status:response.status,body:await response.json() as Record<string,any>};
  }
  async function start(key='request_0001',user='player'){return call('/api/runs/start',{requestId:key},user);}
  function chunkBody(run:Record<string,any>,seq:number,from:number,to:number,actions:RecordedAction[],final:boolean){return {id:run.id,version:ENGINE_VERSION,seq,fromTick:from,toTick:to,actions:actions.filter(a=>a.tick>=from&&a.tick<to),final};}
  async function sendChunks(run:Record<string,any>,actions:RecordedAction[],endTick:number,user='player',final=true) {
    let res:{status:number;body:Record<string,any>}={status:0,body:{}};let seq=0;
    for(let from=0;from<endTick;from+=MAX_CHUNK_TICKS){const to=Math.min(endTick,from+MAX_CHUNK_TICKS);res=await call('/api/runs/chunk',chunkBody(run,seq,from,to,actions,final&&to===endTick),user);if(res.status!==200)return res;seq++;}
    return res;
  }
  async function finish(run:Record<string,any>,user='player') {
    let state=createGame(run.seed);
    while(state.status==='running')state=step(state);
    now=run.createdAt+Math.ceil(state.tick/TICK_RATE*1000)+500;
    return {...await sendChunks(run,[],state.tick,user),state};
  }
  return {db,env,enable,call,start,finish,sendChunks,chunkBody,config,setNow:(value:number)=>{now=value;},now:()=>now,close:local.close};
}

describe('Identity, API and persistence — seven cases',()=>{
  test('anonymous competition cannot issue a run and practice health remains anonymous',async()=>{
    const x=setup();try{await x.enable();assert.equal((await x.call('/api/runs/start',{requestId:'anon_0001'},null)).status,401);assert.equal((await x.call('/api/health',undefined,null)).body.practice,true);}finally{x.close();}
  });
  test('competition defaults disabled without inventing a prize',async()=>{
    const x=setup();try{const status=await x.call('/api/status',undefined,null);assert.equal(status.body.competition.enabled,false);assert.equal(status.body.competition.prize,null);assert.equal((await x.start()).body.error.code,'competition_disabled');}finally{x.close();}
  });
  test('admin activation requires all promotion terms and a confirmed decision',async()=>{
    const x=setup();try{const result=await x.call('/api/admin',{action:'config',config:{...DEFAULT_CONFIG,enabled:true}},'owner');assert.equal(result.status,409);assert.equal(result.body.error.code,'rules_required');const prizeNoTerms=await x.call('/api/admin',{action:'config',config:{...DEFAULT_CONFIG,enabled:true,prize:'Combo gratis',rules:'Reglas'}},'owner');assert.equal(prizeNoTerms.status,409);assert.equal(prizeNoTerms.body.error.code,'promotion_incomplete');assert.equal((await x.call('/api/admin',undefined,'player')).status,403);await x.enable();await x.start();assert.equal((await x.call('/api/admin',{action:'config',config:{...x.config,prize:'Cambio durante la semana'}},'owner')).body.error.code,'active_week_immutable');assert.equal((await x.call('/api/admin',{action:'disable',reason:'Pausa técnica'},'owner')).status,200);assert.equal((await x.call('/api/admin',{action:'config',config:x.config},'owner')).status,200);}finally{x.close();}
  });
  test('start is idempotent; one active run is enforced; an owned idempotent abandon releases the slot',async()=>{
    const x=setup();try{await x.enable();const [a,b]=await Promise.all([x.start(),x.start()]);assert.equal(a.status,201);assert.equal(b.body.run.id,a.body.run.id);assert.equal(b.body.run.seed,a.body.run.seed);assert.equal((await x.start('request_0002')).status,409);assert.equal((await x.db.prepare('SELECT COUNT(*) AS n FROM runs').first<{n:number}>())?.n,1);assert.equal((await x.call('/api/runs/abandon',{id:a.body.run.id},'other')).status,404);assert.equal((await x.call('/api/runs/abandon',{id:a.body.run.id})).body.status,'expired');assert.equal((await x.call('/api/runs/abandon',{id:a.body.run.id})).body.duplicate,true);assert.equal((await x.start('request_0002')).status,201);}finally{x.close();}
  });
  test('server replay matches the engine and simultaneous finishes stay atomic and idempotent',async()=>{
    const x=setup();try{await x.enable();const run=(await x.start()).body.run;await x.db.prepare('UPDATE runs SET seed=? WHERE id=?').bind(QUICK,run.id).run();run.seed=QUICK;let state=createGame(run.seed);while(state.status==='running')state=step(state);x.setNow(run.createdAt+Math.ceil(state.tick/TICK_RATE*1000)+500);const payload=x.chunkBody(run,0,0,state.tick,[],true);const [first,raced]=await Promise.all([x.call('/api/runs/chunk',payload),x.call('/api/runs/chunk',payload)]);assert.equal(first.status,200);assert.equal(raced.status,200);assert.equal(first.body.score,state.score);assert.equal(raced.body.score,state.score);const conflict=await x.call('/api/runs/chunk',{...payload,actions:[{tick:0,type:'jump'}]});assert.equal(conflict.status,409);const again=await x.call('/api/runs/chunk',payload);assert.equal(again.body.duplicate,true);assert.equal((await x.db.prepare('SELECT COUNT(*) AS n FROM results').first<{n:number}>())?.n,1);assert.equal((await x.db.prepare('SELECT COUNT(*) AS n FROM leaderboard').first<{n:number}>())?.n,1);}finally{x.close();}
  });
  test('changing an alias changes one public row without leaking the stable identity',async()=>{
    const x=setup();try{await x.enable();await x.call('/api/profile',{alias:'@MorUno'});await x.finish((await x.start()).body.run);await x.call('/api/profile',{alias:'@MorDos'});const board=await x.call('/api/leaderboard',undefined,null);assert.equal(board.body.rows.length,1);assert.equal(board.body.rows[0].alias,'@MorDos');assert.equal(JSON.stringify(board.body).includes('participant_id'),false);assert.equal((await x.db.prepare('SELECT COUNT(*) AS n FROM participants').first<{n:number}>())?.n,1);}finally{x.close();}
  });
  test('invalidating a result removes it from rank and records a mandatory audit reason',async()=>{
    const x=setup();try{await x.enable();const run=(await x.start()).body.run;await x.finish(run);const bad=await x.call('/api/admin',{action:'invalidate',runId:run.id,reason:'Revisión manual de prueba'},'owner');assert.equal(bad.status,200);assert.equal((await x.call('/api/leaderboard')).body.rows.length,0);const audit=await x.db.prepare("SELECT reason FROM audit WHERE action='invalidate'").first<{reason:string}>();assert.equal(audit?.reason,'Revisión manual de prueba');}finally{x.close();}
  });
});

async function closedFixture(tie = false) {
  const x=setup();await x.enable();
  const now=Date.parse('2026-11-16T12:00:00Z');
  const week=periodAt(now-86400000);
  await x.db.prepare('INSERT INTO weeks(id,starts_at,ends_at,timezone,config_json,engine_version) VALUES(?,?,?,?,?,?)').bind(week.id,week.start,week.end,week.timezone,JSON.stringify(x.config),ENGINE_VERSION).run();
  for(const [participant,score] of [['player',100],['other',tie?100:90]] as const) {
    const id=`fixture_run_${participant}`;
    await x.db.batch([
      x.db.prepare('INSERT INTO participants(id,alias,created_at) VALUES(?,?,?)').bind(participant,participant,week.start),
      x.db.prepare("INSERT INTO runs(id,participant_id,request_id,seed,engine_version,week_id,created_at,expires_at,status,score) VALUES(?,?,?,?,?,?,?,?,'valid',?)").bind(id,participant,id,42,ENGINE_VERSION,week.id,week.start,week.end,score),
      x.db.prepare('INSERT INTO results(run_id,participant_id,week_id,score,received_at) VALUES(?,?,?,?,?)').bind(id,participant,week.id,score,week.end-1000),
      x.db.prepare('INSERT INTO receipts(run_id) VALUES(?)').bind(id),
      x.db.prepare('INSERT INTO leaderboard(week_id,participant_id,score,received_at,run_id,receipt_sequence) SELECT ?,?,?,?,?,sequence FROM receipts WHERE run_id=?').bind(week.id,participant,score,week.end-1000,id,id)
    ]);
  }
  const getWeek=()=>x.db.prepare('SELECT * FROM weeks WHERE id=?').bind(week.id).first<Record<string,any>>();
  return {...x,week,getWeek};
}

describe('Contest administration and concurrency — seven regression cases',()=>{
  test('freeze is idempotent, exact-receipt ties use acceptance order, and active runs expire',async()=>{
    const x=await closedFixture(true);try{
      await x.db.prepare("INSERT INTO runs(id,participant_id,request_id,seed,engine_version,week_id,created_at,expires_at) VALUES('active_fixture','player','active_fixture',42,?,?,?,?)").bind(ENGINE_VERSION,x.week.id,x.week.start,x.week.end).run();
      await Promise.all([x.call('/api/status'),x.call('/api/status')]);
      const frozen=await x.getWeek();assert.equal(frozen?.status,'frozen');assert.equal(frozen?.candidate_id,'player');assert.equal(frozen?.winner_id,null);
      assert.equal((await x.db.prepare("SELECT status FROM runs WHERE id='active_fixture'").first<{status:string}>())?.status,'expired');
      assert.equal((await x.db.prepare("SELECT COUNT(*) AS n FROM audit WHERE action='freeze_week'").first<{n:number}>())?.n,1);
    }finally{x.close();}
  });
  test('a stale review cannot approve the replacement after its original candidate is invalidated',async()=>{
    const x=await closedFixture();try{
      await x.call('/api/status');const reviewed=await x.getWeek();
      assert.equal((await x.call('/api/admin',{action:'invalidate',runId:'fixture_run_player',reason:'Revisión con evidencia'},'owner')).status,200);
      const approval=await x.call('/api/admin',{action:'approve',weekId:x.week.id,candidateId:reviewed?.candidate_id,revision:reviewed?.revision,reason:'Revisé al candidato original'},'owner');
      assert.equal(approval.status,409);assert.equal(approval.body.error.code,'stale_review');
      const final=await x.getWeek();assert.equal(final?.candidate_id,'other');assert.equal(final?.winner_id,null);
    }finally{x.close();}
  });
  test('delivery and invalidation racing in either order cannot invalidate a delivered prize',async()=>{
    for(const deliveryFirst of [true,false]) {
      const x=await closedFixture();try{
        await x.call('/api/status');const candidate=await x.getWeek();
        await x.call('/api/admin',{action:'approve',weekId:x.week.id,candidateId:candidate?.candidate_id,revision:candidate?.revision,reason:'Ganador revisado con evidencia'},'owner');
        const reviewed=await x.getWeek();
        const deliver=()=>x.call('/api/admin',{action:'delivered',weekId:x.week.id,winnerId:reviewed?.winner_id,revision:reviewed?.revision,reason:'Entrega documentada'},'owner');
        const invalidate=()=>x.call('/api/admin',{action:'invalidate',runId:'fixture_run_player',reason:'Incidencia investigada'},'owner');
        await Promise.all(deliveryFirst?[deliver(),invalidate()]:[invalidate(),deliver()]);
        const final=await x.getWeek();const result=await x.db.prepare("SELECT status FROM results WHERE run_id='fixture_run_player'").first<{status:string}>();
        if(final?.delivered_at) {
          assert.equal(final.winner_id,'player');assert.equal(result?.status,'valid');
          assert.equal((await deliver()).body.duplicate,true);
          assert.equal((await x.db.prepare("SELECT COUNT(*) AS n FROM audit WHERE action='prize_delivered'").first<{n:number}>())?.n,1);
        } else {assert.equal(final?.winner_id,null);assert.equal(result?.status,'invalid');}
      }finally{x.close();}
    }
  });
  test('approval racing invalidation never approves an unreviewed replacement candidate',async()=>{
    const x=await closedFixture();try{
      await x.call('/api/status');const reviewed=await x.getWeek();
      await Promise.all([
        x.call('/api/admin',{action:'approve',weekId:x.week.id,candidateId:reviewed?.candidate_id,revision:reviewed?.revision,reason:'Revisión original'},'owner'),
        x.call('/api/admin',{action:'invalidate',runId:'fixture_run_player',reason:'Incidencia comprobada'},'owner')
      ]);
      const final=await x.getWeek();assert.notEqual(final?.winner_id,'other');
      if(final?.winner_id)assert.equal(final.winner_id,final.candidate_id);
    }finally{x.close();}
  });
  test('a configuration change racing a start cannot produce active weeks under different rules',async()=>{
    const x=setup();try{
      await x.enable();const changed={...x.config,timezone:'Europe/Madrid',closeHour:21};
      await Promise.all([x.start(),x.call('/api/admin',{action:'config',config:changed},'owner')]);
      const current=(await x.db.prepare('SELECT config_json FROM settings WHERE id=1').first<{config_json:string}>())!;
      const weeks=await x.db.prepare("SELECT config_json FROM weeks WHERE status='open'").all<{config_json:string}>();
      for(const week of weeks.results)assert.deepEqual(JSON.parse(week.config_json),JSON.parse(current.config_json));
      assert(weeks.results.length<=1);
    }finally{x.close();}
  });
  test('a result received at the exclusive close is not admitted to a closed week',async()=>{
    const x=setup();try{
      await x.enable();const run=(await x.start()).body.run;await x.db.prepare('UPDATE runs SET seed=? WHERE id=?').bind(QUICK,run.id).run();run.seed=QUICK;let state=createGame(run.seed);while(state.status==='running')state=step(state);
      const week=(await x.db.prepare('SELECT ends_at FROM weeks WHERE id=?').bind(run.weekId).first<{ends_at:number}>())!;
      x.setNow(week.ends_at);
      const response=await x.call('/api/runs/chunk',x.chunkBody(run,0,0,state.tick,[],true));
      assert.equal(response.status,409);assert.equal(response.body.error.code,'week_closed');assert.equal((await x.db.prepare('SELECT COUNT(*) AS n FROM results').first<{n:number}>())?.n,0);
    }finally{x.close();}
  });
  test('report retries persist one Madrid natural-week report and do not invent confirmed purchases',async()=>{
    const x=setup();try{
      const first=await x.call('/api/admin',{action:'report'},'owner');const second=await x.call('/api/admin',{action:'report'},'owner');
      assert.equal(first.status,200);assert.deepEqual(first.body.report.period,second.body.report.period);assert.equal(first.body.report.period.timezone,'Europe/Madrid');assert.equal(first.body.report.current.confirmedPurchases,null);
      assert.equal((await x.db.prepare('SELECT COUNT(*) AS n FROM reports').first<{n:number}>())?.n,1);
      assert.equal((await x.call('/api/admin',undefined,'owner')).body.scheduler.active,false);
    }finally{x.close();}
  });
});

test('the same identity repeating an equal score at the same receipt millisecond keeps its first achievement',async()=>{
  const x=setup();try{
    await x.enable();
    const first=(await x.start('same_score_first')).body.run;
    // Fixed fixture seed and deliberately identical clock values isolate the tie invariant.
    await x.db.prepare('UPDATE runs SET seed=42 WHERE id=?').bind(first.id).run();first.seed=42;
    const firstResult=await x.finish(first);assert.equal(firstResult.status,200);
    x.setNow(first.createdAt);
    const second=(await x.start('same_score_second')).body.run;
    await x.db.prepare('UPDATE runs SET seed=42 WHERE id=?').bind(second.id).run();second.seed=42;
    const secondResult=await x.finish(second);assert.equal(secondResult.status,200);
    assert.equal(firstResult.body.score,secondResult.body.score);
    const entry=await x.db.prepare('SELECT run_id FROM leaderboard WHERE participant_id=?').bind('player').first<{run_id:string}>();
    assert.equal(entry?.run_id,first.id);
    assert.equal((await x.db.prepare('SELECT COUNT(*) AS n FROM receipts').first<{n:number}>())?.n,2);
  }finally{x.close();}
});

describe('Security and validation — seven cases',()=>{
  test('a user cannot inspect or finish somebody else’s run',async()=>{
    const x=setup();try{await x.enable();const run=(await x.start()).body.run;assert.equal((await x.call(`/api/runs/${run.id}`,undefined,'other')).status,404);assert.equal((await x.finish(run,'other')).status,404);assert.equal((await x.db.prepare('SELECT status FROM runs WHERE id=?').bind(run.id).first<{status:string}>())?.status,'active');}finally{x.close();}
  });
  test('a declared or altered score is rejected instead of accepted',async()=>{
    const x=setup();try{await x.enable();const run=(await x.start()).body.run;const result=await x.call('/api/runs/chunk',{...x.chunkBody(run,0,0,1,[],true),score:999999});assert.equal(result.status,400);assert.equal(result.body.error.code,'unknown_property');assert.equal((await x.db.prepare('SELECT COUNT(*) AS n FROM results').first<{n:number}>())?.n,0);}finally{x.close();}
  });
  test('action logs reject duplicate ticks, out-of-order ticks, oversized logs and actions after the end',()=>{
    assert.throws(()=>validateActions([{tick:2,type:'left'},{tick:2,type:'right'}],10,MAX_TICKS));
    assert.throws(()=>validateActions([{tick:3,type:'left'},{tick:2,type:'right'}],10,MAX_TICKS));
    assert.throws(()=>validateActions(Array.from({length:5001},(_,tick)=>({tick,type:'left'})),6000,MAX_TICKS));
    assert.throws(()=>validateActions([{tick:10,type:'jump'}],10,MAX_TICKS));
  });
  test('engine version changes and unfinished runs cannot create ranked scores',async()=>{
    const x=setup();try{await x.enable();const run=(await x.start()).body.run;const bad=await x.call('/api/runs/chunk',{...x.chunkBody(run,0,0,1,[],false),version:'other'});assert.equal(bad.body.error.code,'engine_version_mismatch');x.setNow(run.createdAt+200);const partial=await x.call('/api/runs/chunk',x.chunkBody(run,0,0,1,[],false));assert.equal(partial.status,200);assert.equal(partial.body.provisional,true);assert.equal((await x.db.prepare('SELECT COUNT(*) AS n FROM results').first<{n:number}>())?.n,0,'un bloque provisional no crea puntuación clasificada');}finally{x.close();}
  });
  test('real-time, maximum pause, expiry and exact exclusive week end are enforced separately',()=>{
    const created=100000,expires=created+900000,end=created+1000000;
    assert.throws(()=>validateTiming(created+1,created,expires,end,600,60),/tiempo real/);
    assert.throws(()=>validateTiming(created+400000,created,expires,end,60,60),/pausas/);
    assert.throws(()=>validateTiming(expires+1,created,expires,end,600,60),/vencido/);
    assert.throws(()=>validateTiming(end,created,expires,end,600,60),/cerrado/);
    assert.doesNotThrow(()=>validateTiming(created+11000,created,expires,end,600,60));
  });
  test('cross-origin writes, wrong content type and overlarge bodies are rejected safely',async()=>{
    const x=setup();try{assert.equal((await x.call('/api/profile',{alias:'Mor'},'player',{origin:'https://attacker.test'})).status,403);assert.equal((await x.call('/api/profile',{alias:'Mor'},'player',{'content-type':'text/plain'})).status,415);const response=await x.call('/api/profile',{alias:'x'.repeat(270000)});assert.equal(response.status,413);assert.equal(JSON.stringify(response.body).includes('ADMIN_USER_IDS'),false);}finally{x.close();}
  });
  test('analytics needs consent, rejects client purchases and PII, and deduplicates an accepted event',async()=>{
    const x=setup();try{const event={id:'event_0001',sessionId:'session_0001',name:'game_open',consent:true,properties:{mode:'practice'}};assert.equal((await x.call('/api/events',{...event,consent:false})).status,400);assert.equal((await x.call('/api/events',{...event,name:'purchase'})).status,400);assert.equal((await x.call('/api/events',{...event,properties:{email:'person@example.test'}})).status,400);assert.equal((await x.call('/api/events',event)).status,202);assert.equal((await x.call('/api/events',event)).status,202);assert.equal((await x.db.prepare('SELECT COUNT(*) AS n FROM events').first<{n:number}>())?.n,1);}finally{x.close();}
  });
});

describe('Motor v2: partidas sin límite validadas por bloques',()=>{
  test('el endpoint antiguo de cierre completo ya no existe',async()=>{
    const x=setup();try{await x.enable();const run=(await x.start()).body.run;assert.equal(run.unlimited,true);assert.equal(run.maxChunkTicks,MAX_CHUNK_TICKS);const r=await x.call('/api/runs/finish',{id:run.id,version:ENGINE_VERSION,actions:[],endTick:1});assert.equal(r.status,410);}finally{x.close();}
  });
  test('una carrera de 40.000 ticks (11 min, más que el antiguo límite) se valida por bloques y el servidor calcula la puntuación',async()=>{
    const x=setup();try{await x.enable();const run=(await x.start()).body.run;await x.db.prepare('UPDATE runs SET seed=777 WHERE id=?').bind(run.id).run();run.seed=777;
      const actions=plan(777,40000);let state=createGame(777);let i=0;while(state.tick<40000){const a=actions[i]?.tick===state.tick?actions[i++]!.type:undefined;state=step(state,a);}assert.equal(state.status,'running');
      let seq=0;for(let from=0;from<40000;from+=MAX_CHUNK_TICKS){const to=Math.min(40000,from+MAX_CHUNK_TICKS);x.setNow(run.createdAt+Math.ceil(to/TICK_RATE*1000)+100);const r=await x.call('/api/runs/chunk',x.chunkBody(run,seq++,from,to,actions,to===40000));assert.equal(r.status,200,JSON.stringify(r.body));if(to===40000){assert.equal(r.body.score,state.score);assert.equal(r.body.personalBest,state.score);}}
      const stored=await x.db.prepare('SELECT status,end_tick,length(checkpoint_json) AS size FROM runs WHERE id=?').bind(run.id).first<{status:string;end_tick:number;size:number}>();
      assert.equal(stored?.status,'valid');assert.equal(stored?.end_tick,40000);assert.ok((stored?.size??0)<5000,'el servidor guarda un punto de control pequeño, no el registro entero');
      assert.equal((await x.db.prepare('SELECT COUNT(*) AS n FROM run_chunks WHERE run_id=?').bind(run.id).first<{n:number}>())?.n,Math.ceil(40000/MAX_CHUNK_TICKS));
    }finally{x.close();}
  });
  test('bloques repetidos son idempotentes; perdidos, desordenados o discontinuos se rechazan',async()=>{
    const x=setup();try{await x.enable();const run=(await x.start()).body.run;x.setNow(run.createdAt+60000);
      const c0=x.chunkBody(run,0,0,60,[],false);const a=await x.call('/api/runs/chunk',c0);const b=await x.call('/api/runs/chunk',c0);
      assert.equal(a.status,200);assert.equal(b.status,200);assert.equal(b.body.duplicate,true);
      assert.equal((await x.db.prepare('SELECT next_seq FROM runs WHERE id=?').bind(run.id).first<{next_seq:number}>())?.next_seq,1,'el duplicado no avanza la secuencia');
      const skipped=await x.call('/api/runs/chunk',x.chunkBody(run,2,60,120,[],false));assert.equal(skipped.status,409);assert.equal(skipped.body.error.code,'chunk_out_of_order');
      const gap=await x.call('/api/runs/chunk',x.chunkBody(run,1,70,120,[],false));assert.equal(gap.status,409);assert.equal(gap.body.error.code,'chunk_gap');
      const changed=await x.call('/api/runs/chunk',{...c0,actions:[{tick:5,type:'left'}]});assert.equal(changed.status,409);assert.equal(changed.body.error.code,'chunk_conflict');
      const tooLong=await x.call('/api/runs/chunk',x.chunkBody(run,1,60,60+MAX_CHUNK_TICKS+1,[],false));assert.equal(tooLong.status,400);
      const foreign=await x.call('/api/runs/chunk',x.chunkBody(run,1,60,120,[],false),'other');assert.equal(foreign.status,404,'nadie puede enviar bloques de otra persona');
      const ok=await x.call('/api/runs/chunk',x.chunkBody(run,1,60,120,[],false));assert.equal(ok.status,200);
    }finally{x.close();}
  });
  test('no se puede simular más rápido que el tiempo real ni seguir tras la inactividad',async()=>{
    const x=setup();try{await x.enable();const run=(await x.start()).body.run;x.setNow(run.createdAt+500);
      const fast=await x.call('/api/runs/chunk',x.chunkBody(run,0,0,600,[],false));assert.equal(fast.body.error.code,'impossible_time');
      x.setNow(run.createdAt+run.inactivitySeconds*1000+1000);const late=await x.call('/api/runs/chunk',x.chunkBody(run,0,0,60,[],false));assert.equal(late.status,410);assert.equal(late.body.error.code,'run_expired');
    }finally{x.close();}
  });
  test('una carrera que cruza el cierre semanal no suma a ninguna semana y se avisa al empezar cerca del cierre',async()=>{
    const x=setup();try{await x.enable();const probe=(await x.start('probe_week_0001')).body.run;const week=(await x.db.prepare('SELECT ends_at FROM weeks WHERE id=?').bind(probe.weekId).first<{ends_at:number}>())!;
      await x.call('/api/runs/abandon',{id:probe.id});
      x.setNow(week.ends_at-5*60000);const started=await x.start('near_close_0001');assert.equal(started.status,201);assert.ok(String(started.body.warning).includes('práctica'));
      const run=started.body.run;await x.db.prepare('UPDATE runs SET seed=777 WHERE id=?').bind(run.id).run();run.seed=777;const acts=plan(777,700);x.setNow(week.ends_at-60000);assert.equal((await x.call('/api/runs/chunk',x.chunkBody(run,0,0,600,acts,false))).status,200);
      x.setNow(week.ends_at+1000);const after=await x.call('/api/runs/chunk',x.chunkBody(run,1,600,620,acts,true));assert.equal(after.status,409,JSON.stringify(after.body));assert.ok(['week_closed','run_closed'].includes(after.body.error.code));
      assert.equal((await x.db.prepare('SELECT COUNT(*) AS n FROM leaderboard').first<{n:number}>())?.n,0);
    }finally{x.close();}
  });
  test('el récord histórico se conserva aparte de la mejor marca semanal y la tabla tiene una fila por persona',async()=>{
    const x=setup();try{await x.enable();
      const r1=(await x.start('pb_first_0001')).body.run;await x.db.prepare('UPDATE runs SET seed=777 WHERE id=?').bind(r1.id).run();r1.seed=777;
      const acts=plan(777,3000);let s=createGame(777);let i=0;while(s.tick<3000){const a=acts[i]?.tick===s.tick?acts[i++]!.type:undefined;s=step(s,a);}while(s.status==='running')s=step(s);
      x.setNow(r1.createdAt+Math.ceil(s.tick/TICK_RATE*1000)+200);const good=await x.sendChunks(r1,acts,s.tick);assert.equal(good.status,200);const high=good.body.score;
      const r2=(await x.start('pb_second_001')).body.run;const low=await x.finish(r2);assert.equal(low.status,200);assert.ok(low.body.score<high);
      assert.equal(low.body.personalBest,high,'el récord histórico no baja');
      const rows=await x.db.prepare('SELECT COUNT(*) AS n,MAX(score) AS best FROM leaderboard WHERE participant_id=?').bind('player').first<{n:number;best:number}>();assert.equal(rows?.n,1);assert.equal(rows?.best,high);
    }finally{x.close();}
  });
});
