# FERCHODOGGS DASH

Módulo independiente de juego, preparado para integrar en la tienda de FERCHODOGGS que desarrolla Claude. **No es una reconstrucción de la tienda.** No incluye productos, pedidos ni precios ficticios.

## Ejecutar en local

Requiere **Node.js 24 o posterior** (incluye `node:sqlite`) y npm.

```sh
npm ci
npm run dev
```

Abre **http://127.0.0.1:4173**. El servidor escucha solo en loopback. `Ctrl+C` lo detiene.

El primer arranque compila los assets y crea `work/dash.sqlite` con migraciones transaccionales. El servidor local inyecta una **identidad de desarrollo**, nunca una identidad pública verificada. La competición está desactivada inicialmente. No uses este servidor como hosting de producción.

```sh
npm run check       # ESLint + TypeScript + pruebas + build
npm test            # pruebas reales Node/SQLite
npm run build       # dist/client y dist/server/index.js
node scripts/healthcheck.mjs http://127.0.0.1:4173
```

Si npm no puede escribir su caché, configura `npm_config_cache` a un directorio local escribible. `PORT=4174 npm run dev` cambia el puerto. La ejecución no requiere claves de pago ni servicios de terceros.

## Jugar

- **Móvil:** toca la pista para saltar, desliza horizontalmente para cambiar de carril. Hay tres botones alternativos.
- **Ordenador:** ← / → para carriles; ↑ o espacio para saltar; P para pausa. Esc cierra.
- Obstáculos bajos: saltar. Altos: esquivar. Fichas: +25 puntos.
- 10 puntos por segundo **simulado**, máximo diez minutos. El refresco de pantalla no modifica los puntos.
- Ocultar la pestaña o una interrupción superior a 250 ms pausa la simulación.
- Récord local por navegador. Sonido opcional apagado al abrir.

El juego es visual y depende de reflejos; los controles accesibles no equivalen a una alternativa completa para personas que no pueden percibir el Canvas. Esta limitación está pendiente de una experiencia alternativa.

## Mascota original

**No se ha recibido el archivo original.** La ficha geométrica con F está identificada como temporal y no representa la mascota.

Único punto de configuración: **`src/config.ts` → `CONFIG.mascotUrl`**. Copia el original sin modificar en `public/assets/mascota-original.png` y usa `/assets/mascota-original.png`. Admite archivo del mismo origen. Reconstruye con `npm run build` o reinicia `npm run dev`. Se conserva la proporción de la imagen; no se redibuja, no se añaden dientes ni accesorios.

## Integrar en la tienda

Usa `src/module.ts` o `dist/client/assets/ferchodoggs-dash.js` y **solo `public/dash.css`**. No importes la portada ni `styles.css` de la demo en la tienda. La integración completa y los límites están en [CLAUDE_HANDOFF.md](CLAUDE_HANDOFF.md).

```ts
import { createFerchoDoggsDash } from './src/module.ts';
// Importa/copía dash.css como asset del host.
const dash = createFerchoDoggsDash();
// En el botón del host: dash.open();
// Al desmontar la ruta/componente:
dash.destroy();
```

El módulo solo utiliza claves `ferchodoggs-dash:v1:*`. No borra ni escribe el carrito. Cerrar cancela su animación, restaura scroll y foco. `destroy()` cancela listeners y observer. El host debe mantener su componente/proveedor del carrito montado y comprobar su conservación con su implementación real.

## Backend y competición

Motor único: `src/game/engine.ts`, versión `ferchodoggs-dash/1.0.0`. Cada acción se aplica **antes de `step()` en su tick**.

El servidor emite semilla e ID y reproduce las acciones. Rechaza un `score` declarado por cliente. SQLite/D1 impone una partida activa por identidad, inicios/finales idempotentes y un mejor resultado semanal por identidad. El alias público no se usa como identidad ni acredita un @ social.

Configuración **propuesta**, no aprobada: `America/Caracas`, domingo 20:00, periodos consecutivos `[inicio, final)`. Empate: primera recepción válida por servidor. Los cierres pendientes se recuperan al consultar la API. Un cierre puntual sin tráfico requiere programador persistente.

La competición solo puede habilitarla un administrador con premio, reglas, elegibilidad, entrega y reclamación definidos y confirmados. **No hay promoción ni premio activo.** Las partidas que terminan fuera de su semana no se incorporan retroactivamente. Ganadores requieren revisión; la reproducción no prueba que jugó una persona.

Contratos, administración, errores y permisos: [docs/API.md](docs/API.md). La administración está disponible por API protegida; no se ha implementado un panel gráfico.

## Servicios preparados y pendientes

| Parte | Estado real |
| --- | --- |
| Práctica y récord personal | Código funcional local |
| Clasificación / validación | API y base SQLite probadas localmente; no clasificación pública |
| Identidad | Simulada en local; producción debe usar proxy verificado del host |
| Analítica | Opt-in, eventos deduplicados en DB y evento de integración; sin proveedor externo |
| Compras | No se emite `purchase` desde este módulo |
| Informe semanal | Generación persistente e idempotente y ventanas Madrid implementadas; sin envío ni programación activa |
| Monitorización | Healthcheck manual; sin monitor externo ni alertas activas |
| Publicación | Demo privada de práctica y descarga; backend competitivo sin desplegar. Ver DEPLOYMENT.md |

No se ha modificado la tienda existente, el agente de Instagram ni su cola. La referencia de la foto que debe bloquearse sigue pendiente para su futura integración.

Demo privada de distribución: https://ferchodoggs.olivemerit2.chatgpt.site (requiere acceso del propietario). Código: /downloads/ferchodoggs-dash.zip. Descárgalo y adjúntalo a Claude; no presupongas que Claude puede entrar en un enlace privado.
