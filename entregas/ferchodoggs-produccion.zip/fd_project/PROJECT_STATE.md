# FERCHODOGGS — Estado del proyecto

Última actualización: 16/11/2026 (Europe/Madrid)

## Resumen

**En línea (v4, aprobada por el dueño el 16/11):** https://claude.ai/artifact/EUoxXUMnpopsrxwJ8XpPK6 (versión 7). La ve cualquiera con el enlace, con el diseño nuevo y el juego v2 (carrera infinita). El enlace de revisión https://claude.ai/artifact/KpiiquviSkjxMpgf28HUZd queda como copia privada. La competición, los premios, la analítica, el informe de los lunes y la monitorización siguen desactivados o pendientes de servicios externos.

## Decisiones

| Fecha | Decisión |
|---|---|
| 15/11 | Los pedidos van al WhatsApp 0412-1482458 (`584121482458`), por indicación del dueño. |
| 15/11 | La comanda pide «confirmen disponibilidad y el monto». No se paga en la web ni se piden capturas, y el pago móvil se confirma por chat. |
| 15/11 | Las opciones de quitar se escriben «Sin cebolla / Sin papas / Sin ensalada / Sin salsas». |
| 16/11 | v4: se retiran del todo el gancho de la salsa, «Presióname», «Limpiar», los bocadillos y las franjas en movimiento. |
| 16/11 | v4: la mascota ya no flota sobre los productos ni sobre el carrito, y la ayuda para avanzar es solo texto. |
| 16/11 | Juego v2: carrera infinita y motor `ferchodoggs-dash/2.0.0`. Los récords v1 y v2 no se mezclan (prefijo `ferchodoggs-dash:v2:`). |
| 16/11 | La competición queda desactivada (`FERCHO_COMPETITION` en false) hasta tener servidor, identidad y reglas. |
| 16/11 | El dueño aprueba la v4 («créalo tú solo… quiero mi página lista con el juego») y sustituye a la v3 en el mismo enlace público. |
| 16/11 | Cierre semanal **propuesto**: domingo 20:00, hora de Venezuela. No es definitivo. |

## Diseño v4

**Orden de la página:**
1. Cabecera compacta con logo, estado y carrito con contador.
2. «Tu próximo antojo empieza aquí.» y el botón naranja «Ver menú y pedir».
3. Ubicación y horario.
4. Tarjeta del juego, con la mascota de cuerpo completo en su propia zona.
5. «🏆 TOP 3 DE LA SEMANA», que muestra «Puesto libre» y ningún nombre inventado, con el enlace «Ver clasificación».
6. Categorías, productos, carrito y comanda, sin cambios funcionales.

**Paleta:**

| Uso | Colores |
|---|---|
| Fondos | #09090D, #14121B, #1C1728 |
| Morado | #8B5CF6 |
| Naranja | #FF8528 |
| Verde | #C7F43A |
| Texto | #F7F5FA, #BDB7C9 |

**Tipografía y medidas:** Bricolage Grotesque para los títulos (34px en móvil) e Inter para el texto (16px). Las áreas táctiles miden al menos 44px.

**Juego:** pantalla completa en móvil. La pantalla inicial tiene:
- el título;
- una sola instrucción;
- la mascota completa;
- el botón «Jugar» fuera de su silueta;
- el enlace «Cómo jugar».

## Juego v2

**Carrera y puntuación**
- Carrera infinita a 60 ticks/s.
- Puntos: `floor(tick/6) + 25 × fichas`, es decir, 10 por segundo y 25 por ficha.

**Dificultad**
- La velocidad va de 8 a 18 por escalones cada vez más espaciados y se queda en el techo.
- Los primeros 30 s ponen un solo obstáculo por fila.
- Desde los 2 min aparecen combinaciones (fila que obliga a saltar y ritmo doble).
- Siempre hay una salida. Se comprobó con programación dinámica en 40 semillas × 30.000 ticks y en 3 semillas × 60.000.

**Animación**
- Usa las 5 poses originales de la mascota, sin redibujar.
- El fotograma depende de la distancia recorrida. Hay preparación, vuelo y aterrizaje con polvo, y una sombra de contacto.
- La calle llega hasta el borde inferior.

**Récord y final**
- Récord personal local, solo informativo, con el aviso «¡Nuevo récord!» en el cielo; no tapa ni el marcador ni la pista.
- Pantalla final con la comparación con la marca anterior, «Otra carrera» y «Volver a la tienda».

**Servidor (preparado, no desplegado)**
- Validación por bloques de hasta 600 ticks, con secuencia e idempotencia por hash, sin límite de duración.
- Tras 5 min sin bloques, la carrera caduca.
- Respeta la frontera semanal y avisa cuando quedan menos de 10 min para el cierre.
- El récord histórico se guarda aparte de la fila semanal.

## Pruebas

| Suite | Resultado | Nota |
|---|---|---|
| Motor v2 (carrera infinita, dificultad, salida, memoria, bloques) | 14/14 | Node 22 |
| Servidor (Codex más 6 pruebas nuevas de bloques) | 28/28 | `node:sqlite` local; no es D1 real |
| Controles, semana y estructura | 7/7 en cada suite | |
| TypeScript de cliente y servidor | OK | `tsconfig.check.json` |
| Interfaz DOM e integración de Codex (2 archivos) | **BLOQUEADAS** | Falta `jsdom` y no hay red. Las cubre la batería en navegador real. |
| **v4 en Chromium real (Playwright)** | **34/34** | Emulación en navegador, no teléfonos físicos |

**Qué cubre la batería en navegador (v4):**
- Ya no quedan el gancho de la salsa, Presióname, Limpiar ni las franjas.
- Los textos, las fuentes y las medidas son las indicadas.
- La mascota se ve entera y sin tapar en la tarjeta y en el juego.
- El podio muestra «Puesto libre» y «premio por anunciar», y el diálogo de clasificación sale con sus reglas y el historial vacío.
- El contador del carrito en la cabecera funciona.
- La ayuda para avanzar es solo texto.
- El juego ocupa la pantalla completa con los controles visibles.
- La pausa funciona con P y al ocultar la pestaña.
- Salen el aviso de récord, la pantalla final, «Otra carrera» y «Volver a la tienda».
- Al cerrar el juego se conservan el carrito, el nombre y la dirección, y se restauran el foco y el scroll.
- Escape cierra el juego y el diálogo no se duplica.
- La comanda llega a `wa.me/584121482458` con sus opciones y extras.
- No hay llamadas de red ni errores de JavaScript.
- Funciona sin scroll lateral a 320×568, 390×844, 390×600, 768×1024, 1440×900 y 844×390, y con movimiento reducido.

**Pendiente de probar:** Safari en iPhone, Chrome en Android, el navegador interno de Instagram, lector de pantalla y texto al 200 %.

## Estado

| Área | IMPLEMENTADO | PROBADO | PUBLICADO | PENDIENTE |
|---|---|---|---|---|
| Tienda y pedidos por WhatsApp | Sí | Sí (Chromium) | Sí, v4 en el enlace público | Dominio propio |
| Diseño v4 | Sí | Sí, 34/34 | Sí | Teléfonos físicos |
| DASH v2 (práctica, infinito) | Sí | Sí (motor y navegador) | Sí | Teléfonos físicos |
| Top 3 y clasificación | Interfaz sin datos ficticios y servidor por bloques | Servidor 28/28 | No | Alojamiento, base de datos e identidad verificada |
| Premio | No | — | No | Premio, reglas y elegibilidad |
| Analítica | Eventos con consentimiento (desactivados) | — | No | Proveedor y consentimiento visible |
| Informe de los lunes, 09:00 Europe/Madrid | Generador de Codex | Prueba de ventana DST | No | Fuente de datos y canal |
| Monitorización | Script de salud | — | No | Alojamiento |
| Foto «mi leño» | — | — | — | Referencia exacta de la foto |

## Bloqueos concretos

1. Cuenta de alojamiento (Cloudflare: Pages, Workers y D1) para el dominio propio y para el servidor.
2. Identidad verificada para competir.
3. Premio y reglas, y confirmar el cierre semanal propuesto (domingo 20:00, hora de Venezuela).
4. Canal del informe semanal.
5. Referencia exacta de la foto «mi leño».
6. Confirmar el precio de los extras (el menú pone 4,5 por unidad).

## Archivos

- `fercho-pedidos-v4-revision.html`: tienda v4 en un solo archivo.
- `ferchodoggs-dash-v2-proyecto.zip`: código del juego, servidor y pruebas (git con historial).
- `capturas-v4/`: capturas del antes y después, del juego y de cada ancho.
- `ferchodoggs-tienda-publicable.zip`: la v4 lista para un dominio propio (`index.html` con su carpeta `assets/`). Se probó servida en local: sin errores 404 y el juego arranca.

## Actualización 16/11 (tarde)

- **Acceso desde Venezuela:** claude.ai está bloqueado en Venezuela, así que el enlace del artifact no sirve para los clientes de allí. La tienda irá a GitHub Pages (gratis, sin caducidad). El repositorio está listo en `scratchpad/site_repo`. **PENDIENTE:** que Fernando conecte GitHub en Claude. Hay una revisión automática programada que lo publica en cuanto se conecte.
- **Fotos:** se cambiaron los fotogramas de vídeo por fotos reales del dueño, elegidas entre 6 candidatas de hamburguesa simuladas en la tienda y varias opciones por categoría.
  - Hamburguesa: 739dbdcc (doble con tocineta sobre madera).
  - Perros: 500819ca.
  - Shawarmas: da851e8e.
  - Papas: recorte de 22a9e489.
  - La foto de categoría pasa a 4:3 para que se vea el producto entero.
  - No se usan fotos de Pinterest ni de otras tiendas: el cliente pediría algo que no es la comida de Fercho, y además son imágenes con derechos de autor.
- **Versión ligera para el despliegue:** HTML de 99 KB, con las imágenes en `assets/i/` cargadas de forma diferida.
- **AGENTE CARLOS IG:** sus reglas están en `AGENTE_CARLOS_IG.md` (no repetir contenido ni fotos, no publicar el menú en foto, archivar los posts de menú sin borrarlos). En la cuenta de Claude no funciona ningún agente de Instagram. El conector Windsor.ai está instalado, pero la conexión quedó a medias.
- Pruebas en navegador: 34/34 con las fotos nuevas. Publicado en el artifact, versión 8.

## PUBLICADO para Venezuela — 16/11/2026, 11:30 (Madrid)

- **URL pública definitiva:** https://aquino160703-cmyk.github.io/ferchodoggs/. Está en GitHub Pages y el cliente la abre sin cuenta ni descarga.
- **Repositorio:** github.com/aquino160703-cmyk/ferchodoggs (público, rama main, raíz).
  - Se publica con `git push` desde `scratchpad/site_repo`.
  - `site_repo` es una copia de `deploy/`, que se genera con `deploy_build.py`.
- **App de Claude en GitHub:** instalada solo en este repositorio. La conexión se hizo desde el Chrome de Fernando, a petición suya.
- **Comprobado en Chrome sobre la URL:**
  - título y portada;
  - 50 productos;
  - las 4 fotos de categoría (960 px), sin errores;
  - el juego arranca y puntúa.
- **Pendiente:**
  - confirmar que abre desde un móvil en Venezuela (su hermana);
  - poner la URL en la bio de Instagram;
  - dominio propio, opcional (CNAME).
- El artifact de claude.ai queda como copia de trabajo para España. El enlace para los clientes es el de GitHub Pages.

## Enlace bonito — 16/11/2026, 11:40 (Madrid)

- **URL definitiva:** https://ferchodoggs.github.io. Organización gratuita de GitHub `ferchodoggs`, repositorio `ferchodoggs/ferchodoggs.github.io`, rama main.
- Publicar: `git push tienda main` desde `scratchpad/site_repo`.
- El enlace anterior (aquino160703-cmyk.github.io/ferchodoggs) redirige al nuevo.
- La app de Claude solo tiene acceso a esos dos repositorios.
- Instagram solo deja editar el enlace de la bio desde la app del móvil. **Pendiente** de que lo haga Fernando.
- **Servidor del juego:** pendiente. Hace falta cuenta de Cloudflare (Workers + D1, gratis) y cambiar `identity()`, que hoy depende de la cabecera de ChatGPT Sites, por una identidad propia: dispositivo + alias, con verificación del ganador por WhatsApp y su recibo.

## SERVIDOR DEL JUEGO CONECTADO — 16/11/2026, 12:20 (Madrid)

**PUBLICADO**
- **Servidor:** Cloudflare Worker `ferchodash` (https://ferchodash.aquino160703.workers.dev) con la base D1 `ferchodash` (id 1cae4c58-0a4a-458d-948c-9e301e10fb66). Plan gratuito.
  - La cuenta de Cloudflare se creó con Google (aquino160703@gmail.com) a petición de Fernando.
- **Despliegue automático:** Cloudflare Workers Builds está conectado a `ferchodoggs/ferchodoggs.github.io`, carpeta `/server`. Cada push a main despliega solo.
  - `server/worker.js` se genera en fd_project con `esbuild src/worker.ts --bundle --format=esm --define:__ASSETS__={}`.
- **Tienda:** ferchodoggs.github.io tiene la competición activada (`FERCHO_COMPETITION=true`, `FERCHO_API_BASE` = Worker).

**Qué hace**
- **Identidad propia:** token por dispositivo firmado con HMAC.
  - La clave la genera el servidor y la guarda en la tabla `app_secrets`. No se pegó ninguna clave en el panel.
  - El apodo es público y no prueba identidad.
- **CORS:** solo para https://ferchodoggs.github.io (por defecto y también en `vars`).
- **Clasificación semanal sin premio:** la configuración está en `settings` con `prize` vacío y las reglas publicadas.
  - Con premio, el código exige premio, elegibilidad, entrega, reclamación y reglas confirmadas (`promotion_incomplete`).
- **Cierre:** domingo a las 20:00 (America/Caracas). La tabla se reinicia cada semana.

**PROBADO**
- 71 pruebas de motor y servidor, entre ellas 9 nuevas de sesión, CORS y clave propia.
- Prueba de punta a punta en navegador contra el Worker real con SQLite local: 10/10 (apodo, partida, verificación en servidor, top 3 del juego y de la tienda, recordar apodo).
- Regresión de la tienda en modo práctica: 34/34.
- **En producción:** `/api/status` responde con competición activa; desde ferchodoggs.github.io se emiten sesiones (CORS correcto) y la clasificación está vacía.
- No se jugó ninguna partida real, para no meter nombres de prueba en la tabla pública.

**PENDIENTE**
- Premio y reglas, si Fernando quiere premio.
- Administración: añadir el id de dispositivo de Fernando a `ADMIN_USER_IDS`.
- Informe de los lunes (canal).
- Probar en móviles reales en Venezuela.
- Enlace en la bio de Instagram (solo desde la app).
