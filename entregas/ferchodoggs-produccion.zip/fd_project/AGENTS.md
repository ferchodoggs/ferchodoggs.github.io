# FERCHODOGGS

Read PROJECT_STATE.md before continuing. Preserve real catalog, pricing and original mascot.
No invented products, prices, WhatsApp number, prizes or confirmed sales.
Use integer cents. Opening WhatsApp is buy_click, never purchase or confirmed order.
Competition is off until all rules and prize terms are configured and approved.
Engine is shared by browser and server. Action at tick t is applied BEFORE step at tick t.
Run npm run check. Never edit applied SQL migrations; append a new migration.
Never change active competition scoring/rules. Do not expose identity headers, secrets or private data.
