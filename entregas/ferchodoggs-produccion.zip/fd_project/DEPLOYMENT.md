# Ejecución, despliegue y recuperación

## Estado

**Demo privada de práctica y descarga publicada** en https://ferchodoggs.olivemerit2.chatgpt.site. La plataforma confirmó el primer despliegue; requiere acceso del propietario y no es una URL pública anónima. No se ha desplegado el backend competitivo, no se ha tocado la tienda y no se han contratado servicios.

Se registró un contenedor Sites durante el arranque anterior al ajuste de alcance. Su identidad está en `.openai/hosting.json`; **se utiliza solo para distribuir la demo y el ZIP**, con acceso privado y assets estáticos. No hay identidad competitiva ni DB alojada conectada. El alcance vigente es entregar este módulo para integración futura. No copies ese manifiesto encima del proyecto real de la tienda.

## Local

Node24+, `npm ci`, `npm run dev`. `scripts/dev.mjs` escucha en 127.0.0.1, aplica migraciones ordenadas a `work/dash.sqlite` e inyecta la identidad `development-only-player`. Descarta cabeceras `oai-*` recibidas del cliente. Rechaza hosts no locales y cuerpos >256KiB. Nunca exponerlo a Internet ni usar la identidad de desarrollo para premios.

Para probar administración local: copia `.env.example` a `.env` y establece `LOCAL_DEV_ADMIN=1`. Reinicia. Solo en ese proceso local el usuario de desarrollo recibe permiso de administrador. No se habilitan premios automáticamente. Los tests usan fixtures explícitos, aislados en memoria, y no activan la demo.

## Producción integrada

1. Integrar el módulo en una rama de la tienda. Mantener carrito/catalogo/checkout existentes.
2. Conectar la mascota original en `src/config.ts` y verificar assets y proporciones.
3. Servir frontend y `/api/*` bajo el mismo origen HTTPS; no abrir CORS para eludir controles.
4. Conectar identidad verificada del host. Si se adapta a otra autenticación, cambiar **solo** `identity()` y `requireAdmin()` por la sesión verificada del servidor. Eliminar cabeceras de identidad aportadas por el visitante. El Worker de ejemplo confía en las cabeceras inyectadas por el borde autorizado de Sites; no desplegarlo directamente con cabeceras arbitrarias.
5. Provisionar SQLite/D1 compatible con la interfaz `Database`. Aplicar migraciones de `drizzle/` en orden mediante un ejecutor persistente, con revisión y backup. No crear tablas durante solicitudes.
6. Configurar `ADMIN_USER_IDS` exclusivamente en servidor. No existen administradores por defecto. El archivo `.env.example` solo enumera nombres; el hosting no carga automáticamente el `.env` local.
7. Ejecutar `npm run check`, healthchecks, pruebas de navegador y pruebas del carrito del host.
8. Publicar primero práctica con competición desactivada. Verificar HTTPS, acceso anónimo, rutas, imágenes, foco, scroll, móvil y carrito.
9. Antes de competición: identidad real, premio y términos aprobados, límites, privacidad/retención, rate limiting del borde, auditoría/revisión de ganadores, cierre programado, monitorización y carga concurrente verificados. No cambiar reglas/versiones de una semana activa.

`npm run build` produce `dist/client/`, el bundle integrable `dist/client/assets/ferchodoggs-dash.js` y un Worker ES module en `dist/server/index.js`. La demo incluye assets embebidos en el Worker. `dist/server/wrangler.json` es un **ejemplo** con ID de DB `provided-by-host`; no constituye conexión real ni debe desplegarse sin completar configuración. La forma exacta de bindings/migraciones debe adaptarse al hosting elegido. No se ha verificado D1 alojado.

## Informe y monitorización

`maintenance(env)` cierra periodos pendientes. La acción admin `report` genera el informe persistente e idempotente. Se conserva zona `Europe/Madrid` separada del concurso. Programar lunes09:00 con programador que respete DST, no con una hora UTC fija. El canal de entrega aún no está definido. Tabla `reports` reserva intentos, próximo reintento y entrega; no hay worker de envío activo. Evitar declarar actividad solo por crear cron/variables.

Ver `docs/ANALYTICS_AND_OPERATIONS.md` para integración, salud y reintentos.

## Rollback

- Conservar el commit y artefacto anterior de la tienda; desplegar en una rama/version aislada.
- Desactivar competición antes de retirar endpoints; práctica puede seguir disponible.
- Volver a la versión de frontend/servidor compatible. Mantener el motor asignado a partidas activas; no reinterpretar registros con otra versión.
- Las migraciones aplicadas son inmutables. Restaurar datos solo con backup revisado y autorización; preferir migración correctiva hacia delante.
- No borrar la base, resultados, auditoría, carrito o archivos originales.

## Pendientes de comprobación

No se verificó navegador, móviles reales, D1 alojado, proxy de identidad real, HTTPS público, despliegue, proveedor analítico, programador externo ni envío de informes. Las pruebas locales no sustituyen estas comprobaciones.
