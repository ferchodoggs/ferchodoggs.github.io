# Entrega: módulo FERCHODOGGS DASH

## Alcance final

El usuario corrigió el encargo: construir el módulo independiente e integrable, no reconstruir ni simular su tienda. Se crearon archivos reales, repositorio Git, juego, API y pruebas. No se accedió a la tienda de Claude ni se modificó su carrito, catálogo, mascota o agente de Instagram.

## Implementado

- Runner Canvas2D de tres carriles, perspectiva2.5D, toque/swipe/teclado/botones, salto, obstáculos bajos/altos, fichas, velocidad limitada, pausa, reintento, récord local y sonido opt-in.
- Motor puro compartido, semilla xorshift32, ticks fijos, colisiones barridas, patrones con escape y fórmula de puntuación centralizada.
- Dialog con restauración de foco/scroll; cancelación de RAF; listeners y ResizeObserver liberados al desmontar. Registro por tick antes de step.
- Mascota con aviso y frases no repetidas inmediatamente. Ficha neutral expresamente temporal. Única configuración del original en src/config.ts. No hay recurso original recibido.
- API de identidad privada/alias público, emisión/reproducción de partidas, validación del tiempo/log/versión/propietario, abandonos e idempotencia.
- Clasificación por mejor resultado de identidad/semana; cierre inclusivo/exclusivo, zonas configurables, desempate con secuencia persistente incluso en el mismo milisegundo.
- Revisión/invalidación/aprobación/entrega por API con auditoría y control de revisión para carreras administrativas. Sin edición silenciosa de score ni panel gráfico.
- SQLite persistente local; interfaz compatible con D1 y tres migraciones revisadas. No hay D1 alojado conectado.
- Consentimiento de analítica y eventos de integración; no se cuentan clicks como ventas. Informe persistente e idempotente; monitorización manual preparada.

## Siete pasadas de revisión

1. Motor/puntuación: determinismo, terminal, colisiones, escape, velocidad, independencia de refresco.
2. Controles/ciclo: entradas únicas, interrupciones, foco/scroll, destruir/remontar y cerrar durante solicitudes.
3. Interfaz/accesibilidad: estructura y estilos adaptativos, labels, zoom permitido, foco y reduced-motion; emulación DOM, sin afirmar revisión visual real.
4. API/persistencia: transacciones SQLite, identidad/alias, comienzo/finalización y abandono idempotentes.
5. Semana/concurrencia: límites de periodo, DST Madrid, secuencia de recepción, freeze y carreras al invalidar/aprobar/entregar/configurar.
6. Seguridad/analítica: permisos, origen, tamaños, versión, datos personales, score alterado y consentimiento.
7. Integración/entrega: build, aislamiento CSS/bundle, namespace de almacenamiento, migraciones ordenadas y comprobación del archivo ZIP.

No se repitió una misma prueba77veces para aparentar cobertura. TEST_REPORT.md conserva cantidad y resultados reales.

## Correcciones relevantes

- Ajustada la elevación visual del salto para corresponder con el umbral real de colisión en todas las relaciones de aspecto.
- Protegidas respuestas asíncronas antiguas mediante generación de ciclo; no reabren ni modifican una partida nueva.
- Clave idempotente conservada tras perder respuesta de inicio; resultado pendiente recuperable tras fallo de envío.
- Respetado estado oculto al terminar una solicitud asíncrona de inicio.
- Impedido doble salto por teclado más click nativo del botón.
- Reglas de semana activa inmutables; pausa/reanudación con la misma instantánea.
- Protegidas carreras de revisión/entrega y desempates del mismo milisegundo mediante SQLite y revisiones persistentes.

## Límites

Sin navegador real ni móviles reales comprobados, sin original de mascota, sin identidad de producción, sin backend competitivo alojado, sin proveedor analítico externo, sin programación/envío de informes ni alertas. La ficha local y la identidad de desarrollo no validan premios. La reproducción no prueba intervención humana. El Canvas no ofrece una modalidad equivalente para lector de pantalla. La entrega incluye checklist concreto de integración.

La distribución del código/demo, si se aloja por separado, no es la tienda ni activa competición. El estado verificado de alojamiento se informa por separado al entregar.
