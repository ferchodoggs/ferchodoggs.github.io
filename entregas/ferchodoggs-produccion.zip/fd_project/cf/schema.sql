CREATE TABLE settings (id INTEGER PRIMARY KEY CHECK (id=1), config_json TEXT NOT NULL);
CREATE TABLE participants (id TEXT PRIMARY KEY, alias TEXT NOT NULL, created_at INTEGER NOT NULL);
CREATE TABLE weeks (id TEXT PRIMARY KEY, starts_at INTEGER NOT NULL, ends_at INTEGER NOT NULL, timezone TEXT NOT NULL, config_json TEXT NOT NULL, engine_version TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','frozen')), frozen_at INTEGER, candidate_id TEXT, winner_id TEXT, delivered_at INTEGER, CHECK(starts_at<ends_at));
CREATE TABLE runs (id TEXT PRIMARY KEY, participant_id TEXT NOT NULL REFERENCES participants(id), request_id TEXT NOT NULL, seed INTEGER NOT NULL, engine_version TEXT NOT NULL, week_id TEXT NOT NULL REFERENCES weeks(id), created_at INTEGER NOT NULL, expires_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','valid','invalid','expired')), finished_at INTEGER, finish_hash TEXT, score INTEGER, end_tick INTEGER, UNIQUE(participant_id,request_id));
CREATE UNIQUE INDEX one_active_run ON runs(participant_id) WHERE status='active';
CREATE TABLE results (run_id TEXT PRIMARY KEY REFERENCES runs(id), participant_id TEXT NOT NULL REFERENCES participants(id), week_id TEXT NOT NULL REFERENCES weeks(id), score INTEGER NOT NULL CHECK(score>=0), received_at INTEGER NOT NULL, status TEXT NOT NULL DEFAULT 'valid' CHECK(status IN ('valid','invalid','review')), reason TEXT);
CREATE TABLE leaderboard (week_id TEXT NOT NULL REFERENCES weeks(id), participant_id TEXT NOT NULL REFERENCES participants(id), score INTEGER NOT NULL, received_at INTEGER NOT NULL, run_id TEXT NOT NULL REFERENCES results(run_id), PRIMARY KEY(week_id,participant_id));
CREATE INDEX leaderboard_rank ON leaderboard(week_id,score DESC,received_at ASC);
CREATE TABLE audit (id TEXT PRIMARY KEY, actor_id TEXT NOT NULL, action TEXT NOT NULL, target_id TEXT, reason TEXT, created_at INTEGER NOT NULL);
CREATE TABLE events (id TEXT PRIMARY KEY, session_id TEXT NOT NULL, name TEXT NOT NULL, properties_json TEXT NOT NULL, received_at INTEGER NOT NULL);
CREATE INDEX events_period ON events(received_at,name);
CREATE TABLE reports (id TEXT PRIMARY KEY, starts_at INTEGER NOT NULL, ends_at INTEGER NOT NULL, timezone TEXT NOT NULL, payload_json TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'generated', attempts INTEGER NOT NULL DEFAULT 0, next_attempt_at INTEGER, delivered_at INTEGER);
ALTER TABLE weeks ADD COLUMN revision INTEGER NOT NULL DEFAULT 0;
ALTER TABLE weeks ADD COLUMN mutation_id TEXT;
CREATE TABLE receipts (sequence INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT NOT NULL UNIQUE REFERENCES runs(id));
ALTER TABLE leaderboard ADD COLUMN receipt_sequence INTEGER NOT NULL DEFAULT 0;
-- Motor v2 (carrera infinita): validación incremental por bloques, sin límite total de duración.
ALTER TABLE runs ADD COLUMN checkpoint_json TEXT;
ALTER TABLE runs ADD COLUMN next_seq INTEGER NOT NULL DEFAULT 0;
ALTER TABLE runs ADD COLUMN last_seen_at INTEGER;
CREATE TABLE run_chunks (run_id TEXT NOT NULL REFERENCES runs(id), seq INTEGER NOT NULL CHECK(seq>=0), hash TEXT NOT NULL, to_tick INTEGER NOT NULL, status_after TEXT NOT NULL, score_after INTEGER NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY(run_id,seq));
-- Récord personal histórico verificado, separado de la mejor marca semanal (leaderboard).
CREATE TABLE personal_bests (participant_id TEXT PRIMARY KEY REFERENCES participants(id), score INTEGER NOT NULL CHECK(score>=0), run_id TEXT NOT NULL REFERENCES runs(id), updated_at INTEGER NOT NULL);
INSERT OR REPLACE INTO settings(id,config_json) VALUES(1,'{"enabled":true,"confirmed":false,"timezone":"America/Caracas","closeDay":0,"closeHour":20,"prize":"","eligibility":"","delivery":"","claim":"","rules":"Clasificación semanal de FERCHODOGGS DASH, sin premio por ahora. Cada jugador entra con un apodo público y cuenta su mejor puntuación de la semana, calculada por el servidor al reproducir la partida (10 puntos por segundo y 25 por ficha). La semana cierra el domingo a las 20:00, hora de Venezuela. Si se anuncia un premio, sus condiciones se publicarán antes de la semana en que aplique."}');
