import { DatabaseSync } from 'node:sqlite'; import fs from 'node:fs';
const raw = new DatabaseSync(':memory:'); raw.exec(fs.readFileSync(new URL('./schema.sql', import.meta.url), 'utf8'));
console.log('settings:', raw.prepare("SELECT json_extract(config_json,'$.enabled') AS e FROM settings").get());
