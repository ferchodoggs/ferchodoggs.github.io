import {build} from 'esbuild';
import {mkdir,readFile,cp,readdir,writeFile,rm} from 'node:fs/promises';
import path from 'node:path';
await rm('dist',{recursive:true,force:true});
await mkdir('dist/client/assets',{recursive:true});await mkdir('dist/server',{recursive:true});
await cp('public','dist/client',{recursive:true});
await build({entryPoints:['src/main.ts'],bundle:true,format:'esm',target:'es2022',outfile:'dist/client/assets/main.js',minify:true});
await build({entryPoints:['src/module.ts'],bundle:true,format:'esm',target:'es2022',outfile:'dist/client/assets/ferchodoggs-dash.js',minify:true});
const assets={};
async function collect(dir){for(const entry of await readdir(dir,{withFileTypes:true})){const full=path.join(dir,entry.name);if(entry.isDirectory())await collect(full);else assets['/'+path.relative('dist/client',full).split(path.sep).join('/')]=(await readFile(full)).toString('base64');}}
await collect('dist/client');
await build({entryPoints:['src/worker.ts'],bundle:true,format:'esm',target:'es2022',platform:'neutral',outfile:'dist/server/index.js',minify:true,define:{__ASSETS__:JSON.stringify(assets)}});
await writeFile('dist/server/wrangler.json',JSON.stringify({name:'ferchodoggs-dash',main:'index.js',compatibility_date:'2026-01-01',d1_databases:[{binding:'DB',database_name:'ferchodoggs-dash',database_id:'provided-by-host',migrations_dir:'../../drizzle'}]},null,2));
console.log('Built standalone browser module, demo and Worker. No deployment performed.');
