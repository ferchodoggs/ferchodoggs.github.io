import {createServer} from 'node:http';
import {readFile,mkdir} from 'node:fs/promises';
import {resolve} from 'node:path';
import {handleApi} from '../src/server/api.ts';
import {createLocalDatabase} from '../src/server/local-db.ts';
await import('./build.mjs');
await mkdir('work',{recursive:true});
const local=createLocalDatabase('work/dash.sqlite');
const port=Number(process.env.PORT||4173),host='127.0.0.1';
const env={DB:local.db,ADMIN_USER_IDS:process.env.LOCAL_DEV_ADMIN==='1'?'development-only-player':''};
const mime={html:'text/html; charset=utf-8',css:'text/css; charset=utf-8',js:'text/javascript; charset=utf-8',json:'application/json',png:'image/png',webp:'image/webp',svg:'image/svg+xml'};
const server=createServer(async(req,res)=>{
  try {
    // Loopback only. The demo identity is injected by this server, never accepted from a browser.
    if(![`127.0.0.1:${port}`,`localhost:${port}`].includes(req.headers.host)){res.writeHead(403).end('Host rejected');return;}
    const url=new URL(req.url,`http://127.0.0.1:${port}`);
    if(url.pathname.startsWith('/api/')){
      const headers=new Headers();for(const [key,value] of Object.entries(req.headers))if(value&&!key.startsWith('oai-'))headers.set(key,Array.isArray(value)?value.join(','):value);
      headers.set('oai-authenticated-user-id','development-only-player');
      let body; if(!['GET','HEAD'].includes(req.method)) {const chunks=[];let count=0;for await(const chunk of req){count+=chunk.length;if(count>262144){res.writeHead(413).end('Body too large');return;}chunks.push(chunk);}body=Buffer.concat(chunks);}
      const result=await handleApi(new Request(url,{method:req.method,headers,body}),env);res.writeHead(result.status,Object.fromEntries(result.headers));res.end(Buffer.from(await result.arrayBuffer()));return;
    }
    if(!['GET','HEAD'].includes(req.method)){res.writeHead(405).end();return;}
    const path=resolve('dist/client','.'+(url.pathname==='/'?'/index.html':decodeURIComponent(url.pathname)));
    if(!path.startsWith(resolve('dist/client')+'/')){res.writeHead(404).end();return;}
    try{const file=await readFile(path);res.writeHead(200,{'Content-Type':mime[path.split('.').pop()]??'application/octet-stream','X-Content-Type-Options':'nosniff'});res.end(req.method==='HEAD'?undefined:file);}catch{res.writeHead(404).end('Not found');}
  }catch(error){console.error(error);res.writeHead(500).end('Development server error');}
});
server.listen(port,host,()=>console.log(`FERCHODOGGS DASH: http://${host}:${port}\nLOCAL DEVELOPMENT IDENTITY ONLY. Competition disabled. Ctrl+C to stop.`));
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>server.close(()=>{local.close();process.exit(0);}));
