const base=process.argv[2]??'http://127.0.0.1:4173';
let failed=false;
for(const route of ['/','/styles.css','/assets/main.js','/api/status']){
  try {const response=await fetch(new URL(route,base),{signal:AbortSignal.timeout(10000)});const body=await response.text();if(!response.ok||!body.length)throw Error(`HTTP${response.status}`);console.log(`PASS ${route} (${response.status}, ${body.length} characters)`);}catch(error){failed=true;console.error(`FAIL ${route}: ${error.message}`);}
}
if(failed)process.exitCode=1;
