-- Motor v2 (carrera infinita): validación incremental por bloques, sin límite total de duración.
ALTER TABLE runs ADD COLUMN checkpoint_json TEXT;
ALTER TABLE runs ADD COLUMN next_seq INTEGER NOT NULL DEFAULT 0;
ALTER TABLE runs ADD COLUMN last_seen_at INTEGER;
CREATE TABLE run_chunks (run_id TEXT NOT NULL REFERENCES runs(id), seq INTEGER NOT NULL CHECK(seq>=0), hash TEXT NOT NULL, to_tick INTEGER NOT NULL, status_after TEXT NOT NULL, score_after INTEGER NOT NULL, created_at INTEGER NOT NULL, PRIMARY KEY(run_id,seq));
-- Récord personal histórico verificado, separado de la mejor marca semanal (leaderboard).
CREATE TABLE personal_bests (participant_id TEXT PRIMARY KEY REFERENCES participants(id), score INTEGER NOT NULL CHECK(score>=0), run_id TEXT NOT NULL REFERENCES runs(id), updated_at INTEGER NOT NULL);
