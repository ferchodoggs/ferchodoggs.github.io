import { CONFIG } from './config.ts';
import type { RecordedAction } from './game/engine.ts';
export type IssuedRun = {id:string;seed:number;version:string;weekId:string;createdAt:number;expiresAt:number;weekEndsAt:number|null;nextSeq:number;maxChunkTicks:number;inactivitySeconds:number;unlimited:boolean;status:string};
export type ChunkResult = {accepted:boolean;duplicate:boolean;seq:number;tick:number;status:string;score:number;nextSeq?:number;provisional?:boolean;personalBest?:number};
export type BoardRow = {rank:number;alias:string;score:number;status:string};
export type Board = {enabled:boolean;week:{id:string;start:number;end:number;timezone:string;status:string};rules:{prize:string|null;confirmed:boolean};rows:BoardRow[];previousWinners:{id:string;ends_at:number;alias:string}[]};
export class NetworkError extends Error {readonly retryable=true;}
export class ApiFailure extends Error {readonly code:string;readonly status:number;constructor(message:string,code:string,status:number){super(message);this.code=code;this.status=status;}}
const TOKEN_KEY = CONFIG.storagePrefix + 'session';
const readToken = () => { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } };
const writeToken = (value: string | null) => { try { if (value) localStorage.setItem(TOKEN_KEY, value); else localStorage.removeItem(TOKEN_KEY); } catch { /* sin almacenamiento: sesión solo en memoria */ } };
let memoryToken: string | null = null;
async function raw<T>(path:string, body:unknown, token:string|null):Promise<T> {
  let response:Response;
  const headers:Record<string,string> = {}; if (body!==undefined) headers['Content-Type']='application/json'; if (token) headers.Authorization='Bearer '+token;
  try {response=await fetch(CONFIG.apiBase+path,{method:body===undefined?'GET':'POST',headers,body:body===undefined?undefined:JSON.stringify(body)});} catch {throw new NetworkError('Sin conexión con el servidor. El resultado no está confirmado.');}
  let result: {error?:{message:string;code:string}} & T;
  try {result=await response.json() as typeof result;}catch{throw new NetworkError('El servidor no devolvió una respuesta válida. El resultado no está confirmado.');}
  if(!response.ok){if(response.status>=500)throw new NetworkError(result.error?.message??'Servicio no disponible. Reintenta sin crear otra partida.');throw new ApiFailure(result.error?.message??'Solicitud rechazada.',result.error?.code??'unknown',response.status);}
  return result;
}
/** Sesión por dispositivo: el servidor firma un identificador aleatorio. Perder el almacenamiento crea un jugador nuevo. */
async function session(): Promise<string> {
  const known = memoryToken ?? readToken(); if (known) return memoryToken = known;
  const issued = await raw<{token:string}>('/session', {}, null); writeToken(issued.token); return memoryToken = issued.token;
}
export async function api<T>(path:string, body?:unknown, auth = true):Promise<T> {
  if (!auth) return raw<T>(path, body, null);
  try { return await raw<T>(path, body, await session()); }
  catch (error) { if (error instanceof ApiFailure && error.code==='invalid_session') { memoryToken = null; writeToken(null); return raw<T>(path, body, await session()); } throw error; }
}
export function setAlias(alias:string) {return api<{alias:string}>('/profile',{alias});}
export function getMe() {return api<{authenticated:boolean;alias:string|null}>('/me');}
export function startRun(requestId:string) {return api<{run:IssuedRun;reused:boolean;warning?:string|null}>('/runs/start',{requestId});}
/** Bloque ordenado e idempotente: reenviar el mismo bloque nunca duplica resultados. */
export function sendChunk(run:IssuedRun,seq:number,fromTick:number,toTick:number,actions:RecordedAction[],final:boolean) {return api<ChunkResult>('/runs/chunk',{id:run.id,version:run.version,seq,fromTick,toTick,actions,final});}
export function getLeaderboard() {return api<Board>('/leaderboard',undefined,false);}
export function abandonRun(run:IssuedRun) {return api('/runs/abandon',{id:run.id});}
