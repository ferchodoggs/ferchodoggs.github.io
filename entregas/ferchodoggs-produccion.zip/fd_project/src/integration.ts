import { CONFIG } from './config.ts';
export const EVENT_NAMES = ['page_view','mascot_interaction','game_open','game_start','game_end','game_abandon','leaderboard_view','product_view','buy_click','checkout_start','purchase'] as const;
export type EventName = typeof EVENT_NAMES[number];
export type Track = (name: EventName, properties?: Record<string, string|number|boolean>) => void;
const allowed = new Set(['mode','engineVersion','score','ticks','reason','source','medium','campaign','productId','orderId']);
let consent = false;
let pageViewSent = false;
let sessionId: string | null = null;
function session() {
  if(sessionId)return sessionId;
  try {sessionId=sessionStorage.getItem(CONFIG.storagePrefix+'session');}catch{}
  sessionId??=crypto.randomUUID();
  try {sessionStorage.setItem(CONFIG.storagePrefix+'session',sessionId);}catch{}
  return sessionId;
}
export function readValue(key: string): string | null { try { return localStorage.getItem(CONFIG.storagePrefix+key); } catch { return null; } }
export function writeValue(key: string, value: string) { try { localStorage.setItem(CONFIG.storagePrefix+key,value); } catch { /* private browsing/full storage never prevents play */ } }
export function setConsent(value: boolean) { consent=value; writeValue('analytics',String(value)); }
export function hasConsent() { return consent; }
export function sanitizeProperties(input: Record<string, string|number|boolean>) {
  return Object.fromEntries(Object.entries(input).filter(([key,value]) => allowed.has(key) && (typeof value !== 'string' || value.length <= 100)));
}
export const track: Track = (name, properties={}) => {
  // Only a trusted server-confirmed order may emit purchase. This module has no sales provider.
  if (!consent || name === 'purchase' || (name==='page_view' && pageViewSent)) return;
  if(name==='page_view')pageViewSent=true;
  const event = { id: crypto.randomUUID(), sessionId:session(), name, consent:true, properties:sanitizeProperties(properties) };
  window.dispatchEvent(new CustomEvent('ferchodoggs:analytics',{detail:event}));
  void fetch(CONFIG.apiBase+'/events',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(event),keepalive:true}).catch(()=>{});
};
export function initConsent() {
  consent = readValue('analytics') === 'true';
  const box = document.querySelector<HTMLInputElement>('#analytics-consent');
  if(box) { box.checked=consent; box.addEventListener('change',()=>{setConsent(box.checked);if(box.checked)track('page_view',{source:'unknown'});}); }
  const url=new URL(location.href);
  const source=url.searchParams.get('utm_source');
  track('page_view',{source:source?.toLowerCase()==='instagram'?'instagram':source?'other':document.referrer?'other':'direct'});
}
export function personalBest(score?: number): number {
  const current=Number(readValue('best'));
  const valid=Number.isSafeInteger(current)&&current>=0&&current<=1000000?current:0;
  if(score!==undefined && Number.isSafeInteger(score) && score>valid) {writeValue('best',String(score));return score;}
  return valid;
}
