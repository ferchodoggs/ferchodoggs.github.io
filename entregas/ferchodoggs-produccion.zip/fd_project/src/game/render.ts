import { jumpHeight, JUMP_TICKS, VIEW_DISTANCE, type GameState } from './engine.ts';

/** Arte original de FerchoDoggs: una imagen estática y, si existen, los 5 fotogramas originales de carrera.
 * Nunca se redibuja ni se deforma: solo se traslada, rota levemente y se escala de forma uniforme. */
let mascot: HTMLImageElement | null = null;
let frames: HTMLImageElement[] = [];

function acceptable(url: string): string | null {
  if (!url) return null;
  const parsed = new URL(url, document.baseURI);
  const sameOrigin = parsed.origin === location.origin && ['http:', 'https:'].includes(parsed.protocol);
  // La tienda puede incrustar el arte original como data:image (mismo documento, sin CORS ni red).
  const embedded = parsed.protocol === 'data:' && /^data:image\/(png|webp|jpeg);base64,/.test(url);
  return sameOrigin || embedded ? (embedded ? url : parsed.href) : null;
}
export function loadMascot(url: string, runFrames: readonly string[] = []) {
  const ok = acceptable(url);
  if (ok) { const image = new Image(); image.onload = () => { mascot = image; }; image.src = ok; }
  const list = runFrames.map(acceptable).filter((u): u is string => !!u);
  if (list.length >= 2) {
    const loaded: HTMLImageElement[] = new Array(list.length);
    let count = 0;
    list.forEach((src, index) => { const image = new Image(); image.onload = () => { loaded[index] = image; if (++count === list.length) frames = loaded; }; image.src = src; });
  }
}
export function hasRunFrames() { return frames.length >= 2; }

export function resizeCanvas(canvas: HTMLCanvasElement) {
  const rect = canvas.getBoundingClientRect();
  const ratio = Math.min(devicePixelRatio || 1, 2);
  canvas.width = Math.max(1, Math.min(1440, Math.round(rect.width * ratio)));
  canvas.height = Math.max(1, Math.min(1800, Math.round(rect.height * ratio)));
}

/** Efectos solo visuales; no influyen en reglas ni puntuación. */
export type Fx = { now: number; crashAt: number | null; recordAt: number | null; coinAt: number | null; landAt: number | null; reduced: boolean; lite: boolean };
export function createFx(): Fx { return { now: 0, crashAt: null, recordAt: null, coinAt: null, landAt: null, reduced: false, lite: false }; }

const C = { night: '#09090D', sky: '#14121B', haze: '#2A1B45', purple: '#8B5CF6', purpleDeep: '#4C2A85', orange: '#FF8528', lime: '#C7F43A', cream: '#F7F5FA', ink: '#09090D' };

export function render(canvas: HTMLCanvasElement, state: GameState, fx: Fx = createFx()) {
  const c = canvas.getContext('2d'); if (!c) return;
  const w = canvas.width, h = canvas.height;
  const horizon = h * .3, bottom = h * .9, run = state.distance;
  const vpX = w * .6; // punto de fuga desplazado: la mascota de perfil corre «hacia dentro» de la calle
  // Temblor breve al chocar (sin destellos; desactivado con movimiento reducido)
  let shakeX = 0;
  if (fx.crashAt !== null && !fx.reduced) { const t = (fx.now - fx.crashAt) / 320; if (t < 1) shakeX = Math.sin(t * 40) * w * .012 * (1 - t); }
  c.save(); c.translate(shakeX, 0);
  // Cielo nocturno con luz morada ambiental
  const sky = c.createLinearGradient(0, 0, 0, horizon); sky.addColorStop(0, C.night); sky.addColorStop(1, C.haze);
  c.fillStyle = sky; c.fillRect(-w * .05, 0, w * 1.1, horizon + 1);
  const glow = c.createRadialGradient(vpX, horizon, 0, vpX, horizon, w * .7); glow.addColorStop(0, 'rgba(139,92,246,.35)'); glow.addColorStop(1, 'rgba(139,92,246,0)');
  c.fillStyle = glow; c.fillRect(-w * .05, 0, w * 1.1, h);
  // Ciudad en dos capas con parallax moderado
  const layers = [{ k: .015, col: '#1C1728', hMin: .06, step: 0 }, { k: .03, col: '#241C38', hMin: .1, step: 3 }];
  for (const layer of layers) {
    const off = (run * layer.k) % (w * .12);
    for (let i = -1; i < 11; i++) {
      const bw = w * .11, bx = i * w * .12 - off, idx = (i + layer.step + Math.floor(run * layer.k / (w * .12))) & 7;
      const bh = (layer.hMin + ((idx * 5) % 7) * .012) * h;
      c.fillStyle = layer.col; c.fillRect(bx, horizon - bh, bw, bh);
      if (!fx.lite && layer.step) { c.fillStyle = 'rgba(199,244,58,.35)'; for (let r = 0; r < 3; r++) if ((idx + r) % 3 === 0) c.fillRect(bx + bw * .3, horizon - bh + bh * (.2 + r * .25), bw * .14, bh * .07); }
    }
  }
  const project = (lane: number, z: number) => {
    const p = Math.max(0, Math.min(1.5, 1 - z / VIEW_DISTANCE)); const d = p * p; // z<0 prolonga la calle bajo la mascota hasta el borde
    const scale = .13 + .87 * d;
    const center = vpX + (w * .5 - vpX) * d;
    return { x: center + (lane - 1) * w * .27 * scale, y: horizon + (bottom - horizon) * d, s: scale };
  };
  // Asfalto
  c.fillStyle = '#0E0C14'; c.fillRect(-w * .05, horizon, w * 1.1, h - horizon);
  const L0 = project(-.8, VIEW_DISTANCE), R0 = project(2.8, VIEW_DISTANCE), L1 = project(-.8, -VIEW_DISTANCE * .25), R1 = project(2.8, -VIEW_DISTANCE * .25);
  const road = c.createLinearGradient(0, horizon, 0, h); road.addColorStop(0, '#1C1728'); road.addColorStop(1, '#14121B');
  c.fillStyle = road; c.beginPath(); c.moveTo(L0.x, L0.y); c.lineTo(R0.x, R0.y); c.lineTo(R1.x, R1.y); c.lineTo(L1.x, L1.y); c.closePath(); c.fill();
  // Bordillos que avanzan (anclados al suelo, misma proyección)
  for (const side of [-.8, 2.8]) for (let k = 0; k < 16; k++) {
    const z1 = ((k * 130 - run) % 2080 + 2080) % 2080 - 200, z2 = z1 + 65; if (z1 > VIEW_DISTANCE) continue;
    const a = project(side, Math.max(-200, z1)), b = project(side, Math.min(VIEW_DISTANCE, z2));
    c.strokeStyle = k % 2 ? C.orange : C.cream; c.lineWidth = Math.max(2, w * .016 * a.s); c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); c.stroke();
  }
  for (const boundary of [.5, 1.5]) for (let k = 0; k < 14; k++) {
    const z1 = ((k * 150 - run) % 2100 + 2100) % 2100 - 200, z2 = z1 + 70; if (z1 > VIEW_DISTANCE) continue;
    const a = project(boundary, Math.max(-200, z1)), b = project(boundary, Math.min(VIEW_DISTANCE, z2));
    c.strokeStyle = 'rgba(247,245,250,.4)'; c.lineWidth = Math.max(1, w * .006 * a.s); c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); c.stroke();
  }
  // Objetos de lejos a cerca (oclusión correcta); la mascota se dibuja en su profundidad (z=0)
  const objects = state.entities.filter(e => e.z >= -60 && e.z <= VIEW_DISTANCE).sort((a, b) => b.z - a.z);
  const drawEntity = (e: typeof objects[number]) => {
    const p = project(e.lane, e.z); const size = w * .15 * p.s;
    c.fillStyle = 'rgba(0,0,0,.35)'; c.beginPath(); c.ellipse(p.x, p.y, size * .55, size * .12, 0, 0, Math.PI * 2); c.fill(); // sombra de contacto
    if (e.type === 'coin') {
      const bob = fx.reduced ? 0 : Math.sin((state.tick + e.id * 9) * .12) * size * .05, y = p.y - size * .55 + bob;
      c.fillStyle = 'rgba(199,244,58,.22)'; c.beginPath(); c.arc(p.x, y, size * .32, 0, Math.PI * 2); c.fill();
      c.fillStyle = C.lime; c.strokeStyle = C.ink; c.lineWidth = Math.max(1, size * .04); c.beginPath(); c.arc(p.x, y, size * .21, 0, Math.PI * 2); c.fill(); c.stroke();
      c.fillStyle = C.ink; c.font = `800 ${size * .24}px Inter, system-ui, sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('F', p.x, y + size * .01); c.textBaseline = 'alphabetic';
    } else if (e.type === 'low') {
      const eh = size * .48, x = p.x - size / 2, y = p.y - eh;
      c.fillStyle = C.ink; c.fillRect(x + size * .08, p.y - eh * .3, size * .07, eh * .3); c.fillRect(x + size * .85, p.y - eh * .3, size * .07, eh * .3);
      c.save(); c.beginPath(); c.rect(x, y, size, eh * .72); c.clip(); c.fillStyle = C.orange; c.fillRect(x, y, size, eh * .72);
      c.fillStyle = C.cream; for (let s = -1; s < 6; s++) { c.beginPath(); c.moveTo(x + s * size * .22, y + eh * .72); c.lineTo(x + s * size * .22 + size * .1, y + eh * .72); c.lineTo(x + s * size * .22 + size * .1 + eh * .72, y); c.lineTo(x + s * size * .22 + eh * .72, y); c.closePath(); c.fill(); }
      c.restore(); c.strokeStyle = C.ink; c.lineWidth = Math.max(1, size * .03); c.strokeRect(x, y, size, eh * .72);
    } else {
      const eh = size * 1.75, x = p.x - size / 2, y = p.y - eh;
      const g = c.createLinearGradient(x, 0, x + size, 0); g.addColorStop(0, '#6D3FD6'); g.addColorStop(1, '#4C2A85');
      c.fillStyle = g; c.fillRect(x, y, size, eh); c.strokeStyle = C.ink; c.lineWidth = Math.max(1, size * .03); c.strokeRect(x, y, size, eh);
      c.fillStyle = C.lime; c.fillRect(x, y, size, eh * .07);
      c.fillStyle = 'rgba(247,245,250,.14)'; c.fillRect(x + size * .14, y + eh * .15, size * .12, eh * .72);
      c.fillStyle = C.cream; c.font = `800 ${size * .32}px Inter, system-ui, sans-serif`; c.textAlign = 'center'; c.fillText('⇆', p.x, y + eh * .55);
    }
  };
  for (const e of objects) if (e.z > 0) drawEntity(e);
  drawRunner(c, state, fx, project, w);
  for (const e of objects) if (e.z <= 0) drawEntity(e);
  c.restore();
}

function drawRunner(c: CanvasRenderingContext2D, state: GameState, fx: Fx, project: (l: number, z: number) => { x: number; y: number; s: number }, w: number) {
  const p = project(state.lane, 0), size = w * .13;
  const lift = jumpHeight(state) * size * 1.35;
  const elapsed = JUMP_TICKS - state.jumpTicks; // ticks desde que empezó el salto
  const dead = state.status === 'dead';
  // Sombra de contacto ligada a la altura
  const shrink = 1 - Math.min(.55, lift / (size * 2.2));
  c.fillStyle = 'rgba(0,0,0,.45)'; c.beginPath(); c.ellipse(p.x, p.y + size * .04, size * .5 * shrink, size * .13 * shrink, 0, 0, Math.PI * 2); c.fill();
  // Polvo al aterrizar
  if (fx.landAt !== null && !fx.lite) { const t = (fx.now - fx.landAt) / 260; if (t < 1) { c.fillStyle = `rgba(247,245,250,${.35 * (1 - t)})`; for (const s of [-1, 1]) { c.beginPath(); c.ellipse(p.x + s * size * (.35 + t * .35), p.y, size * .14 * (1 + t), size * .06, 0, 0, Math.PI * 2); c.fill(); } } }
  // Destello de ficha recogida
  if (fx.coinAt !== null && !fx.reduced) { const t = (fx.now - fx.coinAt) / 300; if (t < 1) { c.strokeStyle = `rgba(199,244,58,${1 - t})`; c.lineWidth = size * .05; c.beginPath(); c.arc(p.x + size * .1, p.y - size * 1.2 - lift, size * (.25 + t * .45), 0, Math.PI * 2); c.stroke(); } }
  let image: HTMLImageElement | null = mascot, rot = 0, dy = 0, dx = 0;
  if (frames.length >= 2) {
    const n = frames.length;
    if (dead) { image = frames[2 % n]!; }
    else if (state.jumpTicks > 0 && elapsed <= 5) { image = frames[3 % n]!; dy = size * .05 * (elapsed / 5); } // preparación: se agacha (traslación, sin estirar)
    else if (state.jumpTicks > 0) { image = frames[1 % n]!; rot = -.08; } // vuelo: zancada extendida
    else if (fx.landAt !== null && fx.now - fx.landAt < 120) { image = frames[2 % n]!; dy = size * .04; } // aterrizaje
    else { image = frames[Math.floor(state.distance / 42) % n]!; dy = fx.reduced ? 0 : -Math.abs(Math.sin(state.distance / 42 * Math.PI / 2.5)) * size * .03; }
  } else if (!dead && !fx.reduced && state.jumpTicks === 0) {
    dy = -Math.abs(Math.sin(state.tick * .3)) * size * .04; // solo hay imagen estática: traslación discreta, sin fingir piernas
  }
  if (dead && fx.crashAt !== null) { const t = Math.min(1, (fx.now - fx.crashAt) / 300); rot = .35 * t; dx = -size * .2 * t; }
  // Celebración de récord: pequeño salto visual y chispas, sin tapar la pista
  let cheer = 0;
  if (fx.recordAt !== null && !dead) { const t = (fx.now - fx.recordAt) / 700; if (t < 1) { cheer = fx.reduced ? 0 : Math.sin(t * Math.PI) * size * .18; if (!fx.lite) { c.fillStyle = `rgba(199,244,58,${1 - t})`; for (let i = 0; i < 6; i++) { const a = i / 6 * Math.PI * 2; c.beginPath(); c.arc(p.x + Math.cos(a) * size * (.6 + t * .5), p.y - size * 1.1 - lift + Math.sin(a) * size * (.5 + t * .4), size * .04, 0, Math.PI * 2); c.fill(); } } } }
  if (image) {
    // Escala uniforme común a todos los fotogramas (la altura de referencia es la del fotograma más alto): sin saltos de tamaño.
    const refH = frames.length >= 2 ? Math.max(...frames.map(f => f.naturalHeight)) : image.naturalHeight;
    const k = size * 1.8 / refH; const ih = image.naturalHeight * k, iw = image.naturalWidth * k;
    const footPad = (frames.length >= 2 ? 12 / 380 : 0) * (frames.length >= 2 ? Math.max(...frames.map(f => f.naturalHeight)) : 0) * k; // margen transparente bajo los zapatos
    c.save(); c.translate(p.x + dx, p.y - lift - cheer + dy + footPad); c.rotate(rot); c.drawImage(image, -iw / 2, -ih, iw, ih); c.restore();
  } else {
    c.fillStyle = '#C7F43A'; c.strokeStyle = '#09090D'; c.lineWidth = size * .06; c.fillRect(p.x - size * .45, p.y - size - lift, size * .9, size); c.strokeRect(p.x - size * .45, p.y - size - lift, size * .9, size);
    c.fillStyle = '#09090D'; c.font = `800 ${size * .3}px system-ui`; c.textAlign = 'center'; c.fillText('ASSET', p.x, p.y - size * .4 - lift);
  }
}
