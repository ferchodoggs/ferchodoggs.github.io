import { createGame, step, ENGINE_VERSION, TICK_RATE, MAX_CHUNK_TICKS, type GameState, type RecordedAction } from './engine.ts';
import { FixedClock, InputQueue, keyboardAction, pointerAction, type Input } from './clock.ts';
import { render, resizeCanvas, loadMascot, createFx } from './render.ts';
import { startRun, sendChunk, abandonRun, getLeaderboard, setAlias, NetworkError, type IssuedRun, type Board } from '../api-client.ts';
import { CONFIG } from '../config.ts';
import { personalBest, track, readValue, writeValue } from '../integration.ts';

const ALIAS_RE = /^@?[\p{L}\p{N}_.-]{2,24}$/u;

const fmt = (n: number) => n.toLocaleString('es-VE');
const esc = (s: string) => s.replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]!));

/** Podio semanal. Nunca rellena puestos con nombres ficticios: si no hay datos verificados, muestra puestos libres. */
export function top3Markup(board: Board | null): string {
  const medals = ['🥇', '🥈', '🥉'];
  const rows = board?.rows ?? [];
  const items = medals.map((m, i) => { const r = rows[i]; return `<li><span class="m" aria-hidden="true">${m}</span><span class="who">${r ? esc(r.alias) : 'Puesto libre'}</span><b>${r ? fmt(r.score) : '—'}</b></li>`; }).join('');
  const prize = board?.rules?.prize && board.rules.confirmed ? `Premio de esta semana: ${esc(board.rules.prize)}` : 'Clasificación semanal · premio por anunciar';
  return `<div class="fd-top3"><div class="fd-top3-head"><b>🏆 TOP 3 DE LA SEMANA</b><span>${prize}</span></div><ol>${items}</ol>${board ? '' : '<p class="fd-top3-note">La tabla verificada se activa al conectar el servidor. Ahora el juego es de práctica.</p>'}</div>`;
}
/** Lee la clasificación solo cuando la competición está activada; si no, no hace peticiones. */
export async function loadBoard(): Promise<Board | null> {
  if (!CONFIG.competitionEnabled) return null;
  try { const board = await getLeaderboard(); return board.enabled ? board : null; } catch { return null; }
}

type Pending = { run: IssuedRun; seq: number; from: number; to: number; actions: RecordedAction[]; final: boolean };

/** Monta solo un diálogo con alcance propio. destroy() libera todo y restaura foco y scroll de la tienda. */
export function mountGame() {
  loadMascot(CONFIG.mascotUrl, CONFIG.runFrames);
  const heroSrc = CONFIG.runFrames[0] ?? CONFIG.mascotUrl;
  const dialog = document.createElement('dialog'); dialog.className = 'dash-dialog'; dialog.setAttribute('aria-labelledby', 'dash-title');
  dialog.innerHTML = `<header class="dash-top"><div class="dash-name"><h2 id="dash-title">FERCHODOGGS DASH</h2><span class="dash-tag" id="dash-mode">Práctica</span></div>
      <button class="icon-btn" id="dash-sound" aria-pressed="false" aria-label="Activar sonido">🔇</button>
      <button class="icon-btn" id="dash-pause" aria-label="Pausar" disabled>Ⅱ</button>
      <button class="icon-btn" id="dash-close" aria-label="Cerrar juego y volver a la tienda">✕</button></header>
    <div class="dash-hud" aria-live="off"><div><small>Puntos</small><strong id="dash-score">0</strong></div><div><small>Récord</small><strong id="dash-best">0</strong></div><div><small>Fichas</small><strong id="dash-coins">0</strong></div></div>
    <div class="dash-board"><span id="dash-toast" class="dash-toast" role="status" hidden>¡Nuevo récord!</span><canvas id="dash-canvas" tabindex="0" aria-label="Pista de tres carriles. Flechas izquierda y derecha para cambiar de carril; espacio o flecha arriba para saltar; P para pausar."></canvas>
      <div id="dash-overlay" class="dash-overlay"><div class="dash-panel">
        ${heroSrc ? `<img class="dash-hero" id="dash-hero" src="${heroSrc}" alt="Mascota original de FerchoDoggs">` : ''}
        <h3 id="dash-message">FERCHODOGGS DASH</h3>
        <p id="dash-help">Desliza para esquivar. Toca para saltar.</p>
        <p id="dash-result" class="dash-result" hidden></p>
        <div id="dash-alias-box" class="dash-alias" hidden><label for="dash-alias">Tu apodo en el top 3</label><input id="dash-alias" maxlength="24" autocomplete="nickname" autocapitalize="off" spellcheck="false" placeholder="Ej: Maria_VE" enterkeyhint="go"><small>Se verá en la clasificación pública. Letras, números, punto o guion.</small></div>
        <button class="btn btn-lime" id="dash-start">Jugar</button>
        <button class="text-btn" id="dash-shop" hidden>Volver a la tienda</button>
        <button class="text-btn" id="dash-howto" aria-expanded="false" aria-controls="dash-rules">Cómo jugar</button>
        <div id="dash-rules" class="dash-rules" hidden><p>Corre sin fin: la velocidad sube poco a poco hasta un tope y luego llegan combinaciones más exigentes.</p><p>Salta las vallas naranjas. Esquiva los muros morados cambiando de carril. Cada ficha F suma 25 puntos y cada segundo, 10.</p><p>Teclado: ← → para cambiar de carril, espacio o ↑ para saltar, P para pausar, Esc para salir.</p><p id="dash-week"></p></div>
        <div id="dash-board-top3"></div>
      </div></div></div>
    <div class="dash-controls"><button class="control" data-input="left" aria-label="Carril izquierdo">←</button><button class="control jump" data-input="jump">↑ Saltar</button><button class="control" data-input="right" aria-label="Carril derecho">→</button></div>
    <p id="dash-status" class="dash-status" role="status" aria-live="polite"></p>`;
  document.body.append(dialog);
  const $ = <T extends HTMLElement>(id: string) => dialog.querySelector<T>('#' + id)!;
  const canvas = $<HTMLCanvasElement>('dash-canvas'), overlay = $('dash-overlay'), start = $<HTMLButtonElement>('dash-start'), pauseButton = $<HTMLButtonElement>('dash-pause');
  const clock = new FixedClock(TICK_RATE), queue = new InputQueue(), fx = createFx();
  fx.reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
  let state: GameState = createGame(1), frame = 0, open = false, started = false, ended = false, previousFocus: HTMLElement | null = null, previousOverflow = '', lastHud = -1;
  let audio: AudioContext | null = null, soundOn = false, generation = 0, destroyed = false, bestAtStart = 0, celebrated = false, endTimer = 0, toastTimer = 0;
  let mode: 'practice' | 'competition' = 'practice', remoteRun: IssuedRun | null = null, chunkFrom = 0, seq = 0, recent: RecordedAction[] = [];
  const outbox: Pending[] = []; let sending = false, verified: number | null = null, verifyNote = '';
  let slowFrames = 0, frameCount = 0, lastFrame = 0;
  $('dash-week').textContent = `Cierre semanal propuesto: ${CONFIG.week.closeLabel}.`;

  function beep(freq = 660, dur = .07) {
    if (!soundOn) return;
    try { audio ??= new AudioContext(); void audio.resume(); const o = audio.createOscillator(), g = audio.createGain(); g.gain.value = .03; o.frequency.value = freq; o.connect(g); g.connect(audio.destination); o.start(); o.stop(audio.currentTime + dur); } catch { /* el audio opcional no interrumpe */ }
  }
  function hud(force = false) {
    if (!force && state.tick - lastHud < 6) return; lastHud = state.tick;
    $('dash-score').textContent = fmt(state.score); $('dash-coins').textContent = fmt(state.coins); $('dash-best').textContent = fmt(Math.max(personalBest(), started ? state.score : 0));
  }
  function setBoard(board: Board | null) { $('dash-board-top3').innerHTML = top3Markup(board); }
  function status(text: string) { $('dash-status').textContent = text; }
  function current(token: number) { return open && !destroyed && token === generation; }

  /* ---- Competición: envío ordenado por bloques; nunca muestra como confirmado lo pendiente ---- */
  function queueChunk(to: number, final: boolean) {
    if (mode !== 'competition' || !remoteRun || to <= chunkFrom) return;
    const from = chunkFrom; outbox.push({ run: remoteRun, seq: seq++, from, to, actions: recent.filter(a => a.tick >= from && a.tick < to), final });
    recent = recent.filter(a => a.tick >= to); chunkFrom = to; void flush();
  }
  async function flush() {
    if (sending) return; sending = true;
    try {
      while (outbox.length) {
        const next = outbox[0]!;
        try {
          const result = await sendChunk(next.run, next.seq, next.from, next.to, next.actions, next.final);
          outbox.shift();
          if (next.final) { verified = result.score; verifyNote = result.status === 'valid' ? `Verificada en servidor: ${fmt(result.score)} puntos. Ya cuenta para el top 3.` : 'Recibida, pendiente de revisión.'; status(verifyNote); $('dash-mode').textContent = 'Verificada'; }
        } catch (error) {
          if (error instanceof NetworkError) { status('Sin conexión: la puntuación sigue pendiente de verificación. Reintentando…'); await new Promise(r => setTimeout(r, 3000)); if (!open && !next.final) break; continue; }
          outbox.length = 0; remoteRun = null; mode = 'practice'; $('dash-mode').textContent = 'Práctica';
          status(error instanceof Error ? `${error.message} La carrera continúa como práctica.` : 'La carrera continúa como práctica.');
        }
      }
    } finally { sending = false; }
  }

  function showOverlay(kind: 'ready' | 'paused' | 'ended') {
    overlay.hidden = false; overlay.dataset.kind = kind;
    const message = $('dash-message'), help = $('dash-help'), result = $('dash-result'), shop = $('dash-shop'), how = $('dash-howto');
    result.hidden = kind !== 'ended'; shop.hidden = kind === 'ready'; how.hidden = kind === 'paused'; $('dash-board-top3').hidden = kind === 'paused';
    $('dash-rules').hidden = true; how.setAttribute('aria-expanded', 'false');
    $('dash-alias-box').hidden = !(CONFIG.competitionEnabled && mode === 'competition') || kind === 'paused';
    if (kind === 'ready') { message.textContent = 'FERCHODOGGS DASH'; help.hidden = false; help.textContent = 'Desliza para esquivar. Toca para saltar.'; start.textContent = 'Jugar'; }
    if (kind === 'paused') { message.textContent = 'En pausa'; help.hidden = false; start.textContent = 'Continuar'; }
    if (kind === 'ended') {
      const best = personalBest(); const record = state.score > bestAtStart && state.score > 0;
      message.textContent = record ? '¡Nuevo récord!' : 'Choque';
      help.hidden = true;
      result.innerHTML = `<b>${fmt(state.score)}</b> puntos · ${fmt(state.coins)} fichas<br>${record ? (bestAtStart ? `Superaste tu marca anterior de ${fmt(bestAtStart)}.` : 'Tu primera marca.') : `Tu récord: ${fmt(best)} · te faltaron ${fmt(best - state.score + 1)}.`}`;
      start.textContent = 'Otra carrera';
    }
  }
  function end() {
    if (ended) return; ended = true; clock.pause(); queue.clear(); fx.crashAt = performance.now(); beep(180, .2);
    personalBest(state.score); hud(true); pauseButton.disabled = true;
    track('game_end', { mode, score: state.score, ticks: state.tick, engineVersion: ENGINE_VERSION });
    if (mode === 'competition') { status('Validando en el servidor…'); queueChunk(state.tick, true); }
    const token = generation;
    endTimer = window.setTimeout(() => { if (!current(token)) return; showOverlay('ended'); start.focus(); void loadBoard().then(b => { if (current(token)) setBoard(b); }); }, fx.reduced ? 0 : 650);
  }
  function pause(reason = 'manual') {
    if (!started || ended || clock.paused) return; clock.pause(); queue.clear(); showOverlay('paused');
    $('dash-help').textContent = reason === 'hidden' ? 'Pausamos al salir de la pestaña.' : reason === 'interruption' ? 'Pausamos tras una interrupción del dispositivo.' : 'La calle te espera.';
    pauseButton.textContent = '▶'; pauseButton.setAttribute('aria-label', 'Continuar'); start.focus();
  }
  async function begin() {
    if (!open) return;
    if (!started || ended) {
      let seed = crypto.getRandomValues(new Uint32Array(1))[0]!;
      if (CONFIG.competitionEnabled && mode === 'competition') {
        const input = $<HTMLInputElement>('dash-alias'); const alias = input.value.trim();
        if (!ALIAS_RE.test(alias)) { status('Escribe tu apodo (2 a 24 letras o números) para entrar al top 3.'); input.focus(); return; }
        const token = generation; start.disabled = true;
        try {
          if (readValue('alias-synced') !== alias) { await setAlias(alias); writeValue('alias', alias); writeValue('alias-synced', alias); }
          const result = await startRun(crypto.randomUUID());
          if (!current(token)) { void abandonRun(result.run).catch(() => {}); return; }
          if (result.run.version !== ENGINE_VERSION) { status('El servidor usa otra versión del juego. Juega en práctica.'); mode = 'practice'; }
          else { remoteRun = result.run; seed = result.run.seed; if (result.warning) status(result.warning); }
        } catch (error) { status(error instanceof Error ? `${error.message} Juegas en práctica.` : 'Juegas en práctica.'); mode = 'practice'; }
        finally { start.disabled = false; }
      }
      clearTimeout(endTimer);
      state = createGame(seed); started = true; ended = false; lastHud = -1; celebrated = false; bestAtStart = personalBest();
      fx.crashAt = fx.recordAt = fx.coinAt = fx.landAt = null; chunkFrom = 0; seq = 0; recent = []; verified = null;
      $('dash-mode').textContent = mode === 'competition' && remoteRun ? 'Competición' : 'Práctica';
      track('game_start', { mode, engineVersion: ENGINE_VERSION });
    }
    overlay.hidden = true; clock.resume(); queue.clear(); pauseButton.disabled = false; pauseButton.textContent = 'Ⅱ'; pauseButton.setAttribute('aria-label', 'Pausar');
    if (!(mode === 'competition' && remoteRun)) status('');
    hud(true); canvas.focus({ preventScroll: true });
    if (document.hidden) pause('hidden');
  }
  function toast() {
    const t = $('dash-toast'); t.hidden = false; clearTimeout(toastTimer); toastTimer = window.setTimeout(() => { t.hidden = true; }, 1600);
  }
  function loop(now: number) {
    if (!open) return;
    fx.now = now;
    if (lastFrame) { const dt = now - lastFrame; frameCount++; if (dt > 24) slowFrames++; if (frameCount === 120) { fx.lite = slowFrames > 60; frameCount = slowFrames = 0; } }
    lastFrame = now;
    const wasRunning = !clock.paused;
    const result = clock.advance(now, () => {
      const input = queue.consume(); if (input) recent.push({ tick: state.tick, type: input });
      const before = state, beforeJump = state.jumpTicks;
      state = step(state, input);
      if (state.coins > before.coins) { fx.coinAt = now; beep(880, .05); }
      if (beforeJump > 0 && state.jumpTicks === 0) fx.landAt = now;
      if (!celebrated && bestAtStart > 0 && state.score > bestAtStart) { celebrated = true; fx.recordAt = now; toast(); beep(990, .12); }
      if (mode === 'competition' && remoteRun && state.tick - chunkFrom >= MAX_CHUNK_TICKS) queueChunk(state.tick, false);
      if (state.status !== 'running') { end(); return false; }
      return true;
    });
    if (wasRunning && result === 'paused' && !ended) { clock.resume(); pause('interruption'); }
    render(canvas, state, fx); hud(); frame = requestAnimationFrame(loop);
  }
  function show(selectedMode: 'practice' | 'competition' = 'practice') {
    if (open || destroyed) return;
    generation++; mode = CONFIG.competitionEnabled ? selectedMode : 'practice'; remoteRun = null;
    previousFocus = document.activeElement instanceof HTMLElement ? document.activeElement : null; previousOverflow = document.body.style.overflow; document.body.style.overflow = 'hidden';
    open = true; started = false; ended = false; state = createGame(1); queue.clear(); clock.pause(); status('');
    $('dash-mode').textContent = mode === 'competition' ? 'Competición' : 'Práctica';
    soundOn = false; $('dash-sound').textContent = '🔇'; $('dash-sound').setAttribute('aria-pressed', 'false'); $('dash-sound').setAttribute('aria-label', 'Activar sonido');
    $<HTMLInputElement>('dash-alias').value = readValue('alias') ?? '';
    pauseButton.disabled = true; showOverlay('ready'); setBoard(null);
    dialog.showModal(); resizeCanvas(canvas); hud(true); lastFrame = 0; frame = requestAnimationFrame(loop); track('game_open', { mode }); start.focus();
    const token = generation; void loadBoard().then(b => { if (current(token)) setBoard(b); });
  }
  function close() {
    if (!open) return;
    if (started && !ended) { track('game_abandon', { mode, ticks: state.tick, reason: 'close' }); if (mode === 'competition' && remoteRun) queueChunk(state.tick, true); }
    generation++; open = false; clock.pause(); queue.clear(); cancelAnimationFrame(frame); clearTimeout(endTimer); clearTimeout(toastTimer);
    void audio?.close().catch(() => {}); audio = null;
    document.body.style.overflow = previousOverflow; if (dialog.open) dialog.close(); previousFocus?.focus({ preventScroll: true });
    window.dispatchEvent(new CustomEvent(CONFIG.integration.closeEvent));
  }
  const controller = new AbortController(), options = { signal: controller.signal };
  document.querySelectorAll<HTMLElement>('[data-game-open]').forEach(button => button.addEventListener('click', () => show(CONFIG.competitionEnabled ? 'competition' : 'practice'), options));
  $('dash-close').addEventListener('click', close, options); $('dash-shop').addEventListener('click', close, options);
  dialog.addEventListener('cancel', event => { event.preventDefault(); close(); }, options);
  start.addEventListener('click', () => { void begin(); }, options);
  $('dash-alias').addEventListener('keydown', event => { if (event.key === 'Enter') { event.preventDefault(); void begin(); } event.stopPropagation(); }, options);
  $('dash-howto').addEventListener('click', () => { const r = $('dash-rules'); r.hidden = !r.hidden; $('dash-howto').setAttribute('aria-expanded', String(!r.hidden)); }, options);
  $('dash-sound').addEventListener('click', () => { soundOn = !soundOn; $('dash-sound').textContent = soundOn ? '🔊' : '🔇'; $('dash-sound').setAttribute('aria-pressed', String(soundOn)); $('dash-sound').setAttribute('aria-label', soundOn ? 'Silenciar' : 'Activar sonido'); if (soundOn) beep(); }, options);
  pauseButton.addEventListener('click', () => { if (clock.paused) void begin(); else pause(); }, options);
  function input(action: Input) { if (open && started && !ended && !clock.paused) queue.push(action); }
  dialog.querySelectorAll<HTMLElement>('[data-input]').forEach(button => button.addEventListener('click', () => input(button.dataset.input as Input), options));
  dialog.addEventListener('keydown', event => {
    const target = event.target as HTMLElement;
    if (event.key.toLowerCase() === 'p' && !event.repeat) { event.preventDefault(); if (clock.paused) { if (started && !ended) void begin(); } else pause(); return; }
    if (target.tagName === 'BUTTON' && (event.key === ' ' || event.key === 'Enter')) return;
    const action = keyboardAction(event.key, event.repeat); if (action && started && !ended && !clock.paused) { event.preventDefault(); input(action); }
  }, options);
  let pointer: { id: number; x: number; y: number; time: number } | null = null;
  canvas.addEventListener('pointerdown', event => { if (!event.isPrimary) return; pointer = { id: event.pointerId, x: event.clientX, y: event.clientY, time: performance.now() }; canvas.setPointerCapture(event.pointerId); }, options);
  canvas.addEventListener('pointerup', event => { if (!pointer || event.pointerId !== pointer.id) return; const action = pointerAction(event.clientX - pointer.x, event.clientY - pointer.y, performance.now() - pointer.time); pointer = null; if (action) input(action); }, options);
  canvas.addEventListener('pointercancel', () => { pointer = null; }, options);
  document.addEventListener('visibilitychange', () => { if (document.hidden) pause('hidden'); }, options);
  const observer = new ResizeObserver(() => { if (open) { resizeCanvas(canvas); render(canvas, state, fx); } }); observer.observe(canvas);
  return {
    open: () => show('practice'), openCompetition: () => show('competition'), close,
    destroy() { close(); destroyed = true; controller.abort(); observer.disconnect(); dialog.remove(); },
    getState: () => ({ tick: state.tick, score: state.score, status: state.status, verified }),
  };
}
