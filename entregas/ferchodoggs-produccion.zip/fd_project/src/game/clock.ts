import { TICK_RATE, MAX_FRAME_MS } from './engine.ts';
/** Rendering frequency never influences simulation scoring. Long interruptions pause, not catch up. */
export class FixedClock {
  readonly stepMs: number;
  private previous: number | null = null;
  private accumulator = 0;
  paused = true;
  constructor(hz = TICK_RATE) { this.stepMs = 1000 / hz; }
  resume() { this.previous = null; this.accumulator = 0; this.paused = false; }
  pause() { this.paused = true; this.previous = null; this.accumulator = 0; }
  advance(now: number, step: () => boolean): 'paused' | 'stepped' {
    if (this.paused) return 'paused';
    if (this.previous === null) { this.previous = now; return 'stepped'; }
    const elapsed = now - this.previous; this.previous = now;
    if (elapsed < 0 || elapsed > MAX_FRAME_MS) { this.pause(); return 'paused'; }
    this.accumulator += elapsed;
    while (this.accumulator + 1e-7 >= this.stepMs) {
      this.accumulator -= this.stepMs;
      if (!step()) { this.pause(); break; }
    }
    return 'stepped';
  }
}
export type Input = 'left' | 'right' | 'jump';
export function keyboardAction(key: string, repeat = false): Input | null {
  if (repeat) return null;
  return ({ArrowLeft:'left', ArrowRight:'right', ArrowUp:'jump', ' ':'jump'} as Record<string,Input>)[key] ?? null;
}
export function pointerAction(dx: number, dy: number, duration: number): Input | null {
  if (duration > 700) return null;
  if (Math.abs(dx) >= 30 && Math.abs(dx) > Math.abs(dy) * 1.2) return dx < 0 ? 'left' : 'right';
  return Math.abs(dx) < 15 && Math.abs(dy) < 15 ? 'jump' : null;
}
export class InputQueue {
  private pending: Input[] = [];
  push(action: Input) { if (this.pending.length < 3) this.pending.push(action); }
  consume(): Input | undefined { return this.pending.shift(); }
  clear() { this.pending = []; }
}
