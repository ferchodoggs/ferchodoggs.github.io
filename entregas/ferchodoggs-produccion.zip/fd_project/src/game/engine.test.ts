import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import {
  createGame, step, replay, applyChunk, advanceWorld, speedAt, jumpHeight,
  MAX_SPEED, START_SPEED, SPEED_STEPS, VIEW_DISTANCE, JUMP_TICKS, MIN_WAVE_GAP, MAX_CHUNK_TICKS, COMBO_FROM_TICK, ENGINE_VERSION,
} from './engine.ts';
import type { GameState, RecordedAction, Action } from './engine.ts';

const NO_SPAWN = Number.MAX_SAFE_INTEGER;
function emptyGame(): GameState {
  return { ...createGame(42), nextSpawnTick: NO_SPAWN };
}

/** Programa dinámica exacta sobre (carril, jumpTicks): ¿existe alguna secuencia de entradas que sobreviva hasta `ticks`?
 * Reproduce el orden de step(): acción → descuento de salto → altura → cruce del mundo. */
function survivable(seed: number, ticks: number): { ok: boolean; failedAt: number; jumpWalls: number; quick: number } {
  const world = createGame(seed);
  let states = new Set<number>([1 * 64 + 0]); // lane*64 + jumpTicks
  let jumpWalls = 0, quick = 0, lastWall = world.lastJumpWallTick;
  for (let t = 0; t < ticks; t++) {
    const wasQuick = world.lastWaveQuick;
    const crossing = advanceWorld(world); world.tick += 1;
    if (world.lastJumpWallTick !== lastWall) { jumpWalls++; lastWall = world.lastJumpWallTick; }
    if (world.lastWaveQuick && !wasQuick) quick++;
    const next = new Set<number>();
    for (const key of states) {
      const lane0 = Math.floor(key / 64), jump0 = key % 64;
      for (const action of [undefined, 'left', 'right', 'jump'] as (Action | undefined)[]) {
        let lane = lane0, jump = jump0;
        if (action === 'left') lane = Math.max(0, lane - 1);
        if (action === 'right') lane = Math.min(2, lane + 1);
        if (action === 'jump' && jump === 0) jump = JUMP_TICKS;
        if (jump > 0) jump -= 1;
        const airborne = jumpHeight({ jumpTicks: jump }) >= 0.45;
        const dead = crossing.some(e => e.lane === lane && (e.type === 'high' || (e.type === 'low' && !airborne)));
        if (!dead) next.add(lane * 64 + jump);
      }
    }
    if (next.size === 0) return { ok: false, failedAt: t, jumpWalls, quick };
    states = next;
  }
  return { ok: true, failedAt: -1, jumpWalls, quick };
}

describe('1. Motor v2: carrera infinita, puntuación y colisiones', () => {
  it('versión nueva del motor por cambio de reglas', () => {
    assert.equal(ENGINE_VERSION, 'ferchodoggs-dash/2.0.0');
  });
  it('misma semilla y acciones producen exactamente el mismo resultado', () => {
    const actions: RecordedAction[] = [{ tick: 40, type: 'left' }, { tick: 90, type: 'right' }, { tick: 190, type: 'jump' }];
    assert.deepEqual(replay(73, actions, 210), replay(73, actions, 210));
    assert.notDeepEqual(replay(74, actions, 210).entities, replay(73, actions, 210).entities);
  });
  it('ya no existe final por diez minutos: sigue corriendo pasados 36.000 ticks', () => {
    let state = emptyGame();
    for (let tick = 0; tick < 40000; tick++) state = step(state);
    assert.equal(state.status, 'running');
    assert.equal(state.tick, 40000);
    assert.equal(state.score, Math.floor(40000 / 6), '10 puntos por segundo, sin tope');
  });
  it('diez segundos simulados otorgan cien puntos y una ficha veinticinco', () => {
    let state = emptyGame();
    for (let tick = 0; tick < 600; tick++) state = step(state);
    assert.equal(state.score, 100);
    let c: GameState = { ...emptyGame(), entities: [{ id: 1, lane: 1, z: 3, type: 'coin' }] };
    for (let tick = 0; tick < 6; tick++) c = step(c);
    assert.equal(c.coins, 1); assert.equal(c.score, 26);
  });
  it('colisión barrida, salto sobre bajos y no sobre altos, step no muta la entrada', () => {
    const state: GameState = { ...emptyGame(), tick: 18000, entities: [{ id: 1, lane: 1, z: 5, type: 'low' }] };
    assert.equal(step(state).status, 'dead');
    assert.equal(state.entities[0]?.z, 5);
    const air: GameState = { ...emptyGame(), jumpTicks: JUMP_TICKS / 2, entities: [{ id: 1, lane: 1, z: 2, type: 'low' }] };
    assert.ok(jumpHeight(air) > 0.9);
    assert.equal(step(air).status, 'running');
    assert.equal(step({ ...air, entities: [{ ...air.entities[0]!, type: 'high' }] }).status, 'dead');
    assert.equal(step({ ...air, jumpTicks: 0 }, 'jump').status, 'dead', 'un salto tardío no teletransporta');
  });
});

describe('2. Dificultad progresiva con techo', () => {
  it('la velocidad nunca baja, sube con incrementos cada vez más espaciados y se detiene en el máximo', () => {
    let prev = speedAt(0);
    assert.equal(prev, START_SPEED);
    for (let t = 0; t < 200000; t += 30) { const s = speedAt(t); assert.ok(s >= prev && s <= MAX_SPEED); prev = s; }
    assert.equal(speedAt(SPEED_STEPS[SPEED_STEPS.length - 1]!), MAX_SPEED);
    assert.equal(speedAt(10_000_000), MAX_SPEED);
    for (let i = 2; i < SPEED_STEPS.length; i++) {
      assert.ok(SPEED_STEPS[i]! - SPEED_STEPS[i - 1]! > SPEED_STEPS[i - 1]! - SPEED_STEPS[i - 2]!, 'cada subida tarda más');
    }
    assert.ok(VIEW_DISTANCE / MAX_SPEED >= 100, 'a velocidad máxima hay al menos 100 ticks (1,67 s) de pista visible');
  });
  it('inicio accesible: los primeros 30 s solo ponen un obstáculo por fila', () => {
    const world = createGame(7);
    for (let t = 0; t < 1800; t++) {
      const before = world.nextEntityId; advanceWorld(world); world.tick++;
      const wave = world.entities.filter(e => e.id >= before && e.type !== 'coin');
      assert.ok(wave.length <= 1);
    }
  });
  it('después de 2 min aparecen combinaciones (filas que exigen saltar y ritmo doble)', () => {
    const r = survivable(11, COMBO_FROM_TICK + 12000);
    assert.ok(r.jumpWalls > 0 && r.quick > 0, `combinaciones: saltos ${r.jumpWalls}, ritmo doble ${r.quick}`);
  });
});

describe('3. Toda secuencia tiene salida', () => {
  it('40 semillas × 30.000 ticks (8,3 min, cubre combinaciones y velocidad máxima): siempre existe una trayectoria', () => {
    for (let seed = 1; seed <= 40; seed++) {
      const r = survivable(seed * 2654435761 >>> 0, 30000);
      assert.ok(r.ok, `semilla ${seed} sin salida en tick ${r.failedAt}`);
    }
  });
  it('partidas muy largas (60.000 ticks, ~17 min) siguen teniendo salida', () => {
    for (const seed of [0, 123, 0xffffffff]) assert.ok(survivable(seed, 60000).ok);
  });
  it('la separación entre filas nunca baja del mínimo salvo el ritmo doble, que siempre deja carril libre', () => {
    const world = createGame(99);
    let lastWave = -1000;
    for (let t = 0; t < 40000; t++) {
      const before = world.nextEntityId; advanceWorld(world);
      const wave = world.entities.filter(e => e.id >= before);
      if (wave.length) {
        const blocked = wave.filter(e => e.type !== 'coin');
        const highs = blocked.filter(e => e.type === 'high').length;
        assert.ok(highs <= 2, 'nunca tres muros altos');
        if (blocked.length === 3) assert.equal(blocked.filter(e => e.type === 'low').length, 1, 'fila completa: exactamente una valla baja para saltar');
        assert.ok(world.tick - lastWave >= 48);
        if (world.tick - lastWave < MIN_WAVE_GAP) assert.ok(blocked.length <= 2, 'ritmo doble sin filas completas');
        lastWave = world.tick;
      }
      world.tick++;
    }
  });
});

describe('4. Memoria acotada y validación por bloques', () => {
  it('300.000 ticks de mundo mantienen pocas entidades y un estado pequeño', () => {
    const world = createGame(5);
    let maxEntities = 0;
    for (let t = 0; t < 300000; t++) { advanceWorld(world); world.tick++; maxEntities = Math.max(maxEntities, world.entities.length); }
    assert.ok(maxEntities <= 24, `máximo ${maxEntities}`);
    assert.ok(JSON.stringify(world).length < 4000);
  });
  it('aplicar bloques encadenados equivale a la reproducción completa', () => {
    const actions: RecordedAction[] = [];
    for (let t = 30; t < 3000; t += 37) actions.push({ tick: t, type: (['left', 'right', 'jump'] as const)[t % 3]! });
    const full = (() => { let s = createGame(321); for (let t = 0; t < 2400; t++) { const a = actions.find(x => x.tick === t); s = step(s, a?.type); if (s.status !== 'running') break; } return s; })();
    const end = full.tick;
    let chunked = createGame(321);
    for (let from = 0; from < end; from += MAX_CHUNK_TICKS) {
      const to = Math.min(end, from + MAX_CHUNK_TICKS);
      chunked = applyChunk(chunked, actions.filter(a => a.tick >= from && a.tick < to), to);
    }
    assert.deepEqual(chunked, full);
  });
  it('rechaza bloques demasiado largos, acciones desordenadas o fuera del bloque', () => {
    const s = createGame(1);
    assert.throws(() => applyChunk(s, [], MAX_CHUNK_TICKS + 1));
    assert.throws(() => applyChunk(s, [{ tick: 5, type: 'left' }, { tick: 5, type: 'right' }], 10));
    assert.throws(() => applyChunk(s, [{ tick: 10, type: 'left' }], 10));
    assert.throws(() => applyChunk(s, [{ tick: 2, type: 'fly' as Action }], 10));
  });
});
