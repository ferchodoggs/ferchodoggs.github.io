/** Shared browser/server rules. Every input applies BEFORE movement at state.tick.
 * v2.0.0 (FerchoDoggs): carrera infinita. Sin final por tiempo; la partida termina al chocar o al salir.
 * Cambiar cualquier regla exige una versión nueva: nunca durante una semana competitiva activa. */
export const ENGINE_VERSION = 'ferchodoggs-dash/2.0.0';
export const TICK_RATE = 60;
export const VIEW_DISTANCE = 1800;
export const JUMP_TICKS = 48;
export const START_SPEED = 8;
export const MAX_SPEED = 18;
/** Umbrales de velocidad en ticks: cada subida tarda más que la anterior (20 s, 45 s, 75 s… 425 s) y se detiene en MAX_SPEED. */
export const SPEED_STEPS = [0, 1200, 2700, 4500, 6600, 9000, 11700, 14700, 18000, 21600, 25500] as const;
/** Separación mínima entre filas: 1,2 s de reacción con la pista visible (VIEW_DISTANCE/MAX_SPEED = 100 ticks). */
export const MIN_WAVE_GAP = 72;
export const COMBO_FROM_TICK = 7200;     // a partir de 2 min: combinaciones de salto y carril
export const WARMUP_TICKS = 1800;        // primeros 30 s: un solo obstáculo por fila
export const JUMP_WALL_SPACING = 150;    // separación mínima entre filas que exigen saltar
export const QUICK_GAP = 48;             // ritmo doble: segunda fila más cercana, siempre con carril libre
export const MAX_CHUNK_TICKS = 600;      // bloques de acciones de hasta 10 s simulados
export const MAX_FRAME_MS = 250;

export type Action = 'left' | 'right' | 'jump';
export type RecordedAction = { tick: number; type: Action };
export type Entity = { id: number; lane: number; z: number; type: 'low' | 'high' | 'coin' };
export type GameState = {
  seed: number;
  rng: number;
  tick: number;
  lane: 0 | 1 | 2;
  jumpTicks: number;
  status: 'running' | 'dead';
  score: number;
  coins: number;
  distance: number;
  speed: number;
  entities: Entity[];
  nextEntityId: number;
  nextSpawnTick: number;
  lastJumpWallTick: number;
  lastWaveQuick: boolean;
};

export function createGame(seed: number): GameState {
  if (!Number.isInteger(seed) || seed < 0 || seed > 0xffffffff) throw new Error('Invalid seed');
  return {
    seed, rng: seed || 0x6d2b79f5, tick: 0, lane: 1, jumpTicks: 0,
    status: 'running', score: 0, coins: 0, distance: 0, speed: START_SPEED,
    entities: [], nextEntityId: 1, nextSpawnTick: 120, lastJumpWallTick: -100000, lastWaveQuick: false,
  };
}

/** Integer xorshift32: identical in the Worker and browser, including seed zero. */
function nextRandom(value: number): number {
  let x = value | 0;
  x ^= x << 13;
  x ^= x >>> 17;
  x ^= x << 5;
  return x >>> 0;
}

/** Normalized parabola, intentionally shared with the renderer's jump position. */
export function jumpHeight(state: Pick<GameState, 'jumpTicks'>): number {
  if (state.jumpTicks <= 0) return 0;
  const progress = (JUMP_TICKS - state.jumpTicks) / JUMP_TICKS;
  return 4 * progress * (1 - progress);
}

/** Velocidad entera según el tiempo sobrevivido: incrementos cada vez más espaciados y con techo. */
export function speedAt(tick: number): number {
  let level = 0;
  while (level + 1 < SPEED_STEPS.length && tick >= SPEED_STEPS[level + 1]) level++;
  return Math.min(MAX_SPEED, START_SPEED + level);
}

/** Avanza solo el mundo (aparición y movimiento) y devuelve lo que cruza la línea del jugador en este tick.
 * No depende de las acciones del jugador: lo usan step() y las pruebas de alcanzabilidad. */
export function advanceWorld(state: GameState): Entity[] {
  state.speed = speedAt(state.tick);
  if (state.tick >= state.nextSpawnTick) {
    const baseGap = Math.max(MIN_WAVE_GAP, 150 - Math.floor(state.tick / 600));
    state.rng = nextRandom(state.rng);
    const safeLane = state.rng % 3;
    state.rng = nextRandom(state.rng);
    const roll = state.rng % 8;
    const combos = state.tick >= COMBO_FROM_TICK;
    const jumpWall = combos && !state.lastWaveQuick && roll < 2 && state.tick - state.lastJumpWallTick >= JUMP_WALL_SPACING;
    if (jumpWall) {
      // Fila completa: dos muros altos y una valla baja. Única salida: el carril de la valla, saltando.
      for (let lane = 0; lane < 3; lane++) {
        state.entities.push({ id: state.nextEntityId++, lane, z: VIEW_DISTANCE, type: lane === safeLane ? 'low' : 'high' });
      }
      state.entities.push({ id: state.nextEntityId++, lane: safeLane, z: VIEW_DISTANCE, type: 'coin' });
      state.lastJumpWallTick = state.tick;
      state.lastWaveQuick = false;
      state.nextSpawnTick = state.tick + Math.max(baseGap, 90);
    } else {
      state.rng = nextRandom(state.rng);
      const twoObstacles = state.tick >= WARMUP_TICKS && (state.rng & 1) === 1;
      for (let offset = 1; offset <= (twoObstacles ? 2 : 1); offset++) {
        state.rng = nextRandom(state.rng);
        state.entities.push({
          id: state.nextEntityId++, lane: (safeLane + offset) % 3,
          z: VIEW_DISTANCE, type: (state.rng & 1) === 0 ? 'low' : 'high',
        });
      }
      state.entities.push({ id: state.nextEntityId++, lane: safeLane, z: VIEW_DISTANCE, type: 'coin' });
      const quick = combos && !state.lastWaveQuick && (roll === 2 || roll === 3);
      state.lastWaveQuick = quick;
      state.nextSpawnTick = state.tick + (quick ? QUICK_GAP : baseGap);
    }
  }
  const crossing: Entity[] = [];
  for (const entity of state.entities) {
    const oldZ = entity.z;
    entity.z -= state.speed;
    // Swept crossing catches a fast entity even when neither frame touches z=0.
    if (oldZ > 0 && entity.z <= 0) crossing.push(entity);
  }
  state.entities = state.entities.filter(entity => entity.z > -MAX_SPEED);
  state.distance += state.speed;
  return crossing;
}

/** Pure fixed-tick transition. z and distance are integer road units, never pixels. */
export function step(previous: GameState, action?: Action): GameState {
  if (previous.status !== 'running') return previous;
  if (action !== undefined && action !== 'left' && action !== 'right' && action !== 'jump') {
    throw new Error('Invalid action');
  }
  const state: GameState = { ...previous, entities: previous.entities.map(entity => ({ ...entity })) };
  if (action === 'left') state.lane = Math.max(0, state.lane - 1) as 0 | 1 | 2;
  if (action === 'right') state.lane = Math.min(2, state.lane + 1) as 0 | 1 | 2;
  if (action === 'jump' && state.jumpTicks === 0) state.jumpTicks = JUMP_TICKS;
  // Render and collision observe the same final jump height for this tick.
  if (state.jumpTicks > 0) state.jumpTicks -= 1;
  const airborne = jumpHeight(state) >= 0.45;
  for (const entity of advanceWorld(state)) {
    if (entity.lane !== state.lane) continue;
    if (entity.type === 'coin') state.coins += 1;
    else if (entity.type === 'high' || !airborne) state.status = 'dead';
  }
  state.tick += 1;
  state.score = Math.floor(state.tick / 6) + 25 * state.coins;
  return state;
}

/** Valida y aplica un bloque de acciones [fromTick, toTick) sobre un estado guardado. Sin límite total de duración. */
export function validateChunk(actions: RecordedAction[], fromTick: number, toTick: number): void {
  if (!Number.isInteger(fromTick) || !Number.isInteger(toTick) || fromTick < 0 || toTick <= fromTick || toTick - fromTick > MAX_CHUNK_TICKS) {
    throw new Error('Invalid chunk range');
  }
  if (!Array.isArray(actions) || actions.length > toTick - fromTick) throw new Error('Action log too large');
  let lastTick = fromTick - 1;
  for (const action of actions) {
    if (!action || !Number.isInteger(action.tick) || action.tick <= lastTick || action.tick >= toTick) {
      throw new Error('Actions must have unique, ordered ticks inside the chunk');
    }
    if (action.type !== 'left' && action.type !== 'right' && action.type !== 'jump') throw new Error('Invalid action');
    lastTick = action.tick;
  }
}
export function applyChunk(start: GameState, actions: RecordedAction[], toTick: number): GameState {
  validateChunk(actions, start.tick, toTick);
  let state = start;
  let index = 0;
  while (state.tick < toTick) {
    if (state.status !== 'running') throw new Error('Simulation continued after a terminal state');
    const input = actions[index]?.tick === state.tick ? actions[index++]?.type : undefined;
    state = step(state, input);
  }
  return state;
}

/** Reproducción completa (pruebas y auditoría). El servidor usa applyChunk con estados guardados. */
export function replay(seed: number, actions: RecordedAction[], endTick: number): GameState {
  if (!Number.isInteger(endTick) || endTick < 1) throw new Error('Invalid end tick');
  let state = createGame(seed);
  let from = 0;
  while (from < endTick) {
    const to = Math.min(endTick, from + MAX_CHUNK_TICKS);
    state = applyChunk(state, actions.filter(a => a && a.tick >= from && a.tick < to), to);
    from = to;
  }
  return state;
}

/** Frames schedule ticks only. Long interruption pauses instead of awarding catch-up points. */
export class FixedStepClock {
  private carry = 0;
  advance(milliseconds: number): { steps: number; interrupted: boolean } {
    if (!Number.isFinite(milliseconds) || milliseconds < 0) throw new Error('Invalid elapsed time');
    if (milliseconds > MAX_FRAME_MS) {
      this.reset();
      return { steps: 0, interrupted: true };
    }
    this.carry += milliseconds * TICK_RATE / 1000;
    const steps = Math.floor(this.carry + 1e-9);
    this.carry -= steps;
    return { steps, interrupted: false };
  }
  reset(): void { this.carry = 0; }
}
