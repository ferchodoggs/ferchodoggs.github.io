import { api, ApiFailure } from './api-client.ts';
import { CONFIG } from './config.ts';
import { initConsent, track, personalBest } from './integration.ts';
import { mountGame } from './game/ui.ts';

const game=mountGame();
const record=document.querySelector('#personal-best');if(record)record.textContent=String(personalBest());
window.addEventListener('ferchodoggs:close',()=>{if(record)record.textContent=String(personalBest());});
const mascot=document.querySelector<HTMLElement>('#mascot-section');
if(mascot) {
  mascot.hidden=false;mascot.setAttribute('aria-label',CONFIG.mascotUrl?'Mascota original de FerchoDoggs':'Interacción FerchoDoggs — ficha temporal');
  const button=document.createElement('button');button.type='button';button.className='mascot-touch';button.setAttribute('aria-label','Tocar a FerchoDoggs y descubrir una frase');
  if(CONFIG.mascotUrl){const image=document.createElement('img');image.src=CONFIG.mascotUrl;image.alt='Mascota original de FerchoDoggs';image.width=140;image.height=160;image.style.objectFit='contain';button.append(image);}
  else {const token=document.createElement('span');token.className='mascot-token';token.textContent='F';token.setAttribute('aria-hidden','true');button.append(token);const label=document.createElement('span');label.className='placeholder-label';label.textContent='FICHA TEMPORAL';button.append(label);}
  const prompt=document.createElement('strong');prompt.textContent='👆 TÓCAME, MOR 💚';button.append(prompt);mascot.append(button);
  const speech=document.createElement('p');speech.className='mascot-speech';speech.textContent='Tengo una sorpresa para ti 🎮';speech.setAttribute('role','status');mascot.append(speech);
  const play=document.createElement('button');play.type='button';play.className='button button-dark';play.textContent='🎮 JUGAR';play.addEventListener('click',()=>game.open());mascot.append(play);
  const phrases=['¡Dale calle a ese récord, mor! 💚','Tres carriles. Una ruta. ¡Vamos!','Esquiva el alto, salta el bajito.','La próxima ficha lleva tu nombre.','En la ruta de FerchoDoggs mandas tú.'];let previous=-1;
  button.addEventListener('click',()=>{let next=crypto.getRandomValues(new Uint32Array(1))[0]%(phrases.length-1);if(next>=previous&&previous>=0)next++;previous=next;speech.textContent=phrases[next];if(!matchMedia('(prefers-reduced-motion: reduce)').matches)button.animate([{transform:'translateY(0)'},{transform:'translateY(-7px)'},{transform:'translateY(0)'}],{duration:260});track('mascot_interaction',{reason:CONFIG.mascotUrl?'original':'temporary'});});
}
const privacy=document.createElement('dialog');privacy.className='privacy-dialog';privacy.setAttribute('aria-labelledby','privacy-title');
privacy.innerHTML='<h2 id="privacy-title">Tú decides.</h2><p>La analítica opcional mide el uso del juego. No necesitamos tu correo, teléfono ni datos del carrito. Rechazarla no impide jugar.</p><label><input id="analytics-consent" type="checkbox"> Permitir analítica opcional</label><button type="button" class="button button-dark" id="privacy-close">LISTO</button>';
document.body.append(privacy);
// Install the consent control after creating its accessible dialog.
initConsent();
document.querySelector('#privacy-settings')?.addEventListener('click',()=>privacy.showModal());
privacy.querySelector('#privacy-close')?.addEventListener('click',()=>privacy.close());
type Board={week:{end:number;timezone:string;status:string};rules:{prize:string;rules:string;eligibility:string;delivery:string;claim:string};rows:Array<{rank:number;alias:string;score:number;status:string}>;previousWinners:Array<{alias:string;ends_at:number}>};
const ranking=document.querySelector<HTMLElement>('#leaderboard-root');
if(ranking) {
  const label=document.createElement('p');label.className='ranking-message';label.textContent='Competición desactivada. Practica sin registro; tu récord se guarda únicamente en este dispositivo.';ranking.append(label);
  const best=document.createElement('p');best.className='local-best';best.textContent=`Tu récord de práctica: ${personalBest()} puntos`;ranking.append(best);
  window.addEventListener('ferchodoggs:close',()=>{best.textContent=`Tu récord de práctica: ${personalBest()} puntos`;});
  const verified=document.createElement('div');verified.className='verified-board';ranking.append(verified);
  async function loadBoard(){
    try {
      const board=await api<Board>('/leaderboard');verified.replaceChildren();
      const closure=document.createElement('p');closure.className='integration-note';closure.textContent=`Cierre: ${new Intl.DateTimeFormat('es',{dateStyle:'full',timeStyle:'short',timeZone:board.week.timezone}).format(board.week.end)} (${board.week.timezone}). Premio confirmado: ${board.rules.prize}. ${board.rules.rules}`;verified.append(closure);
      const terms=document.createElement('p');terms.className='integration-note';terms.textContent=`Participación: ${board.rules.eligibility}. Entrega: ${board.rules.delivery}. Reclamación: ${board.rules.claim}. Una fila por identidad. Empate: primer resultado válido recibido por el servidor.`;verified.append(terms);
      if(board.rows.length){const table=document.createElement('table');table.className='ranking-table';const caption=document.createElement('caption');caption.textContent='Mejores resultados validados de la semana';table.append(caption);const head=table.createTHead().insertRow();for(const title of ['Puesto','Alias','Puntos','Estado']){const th=document.createElement('th');th.scope='col';th.textContent=title;head.append(th);}const body=table.createTBody();for(const row of board.rows){const tr=body.insertRow();for(const text of [row.rank,row.alias,row.score,row.status])tr.insertCell().textContent=String(text);}verified.append(table);}else {const empty=document.createElement('p');empty.textContent='Aún no hay resultados válidos esta semana.';verified.append(empty);}
      if(board.previousWinners.length){const winners=document.createElement('p');winners.textContent='Ganadores anteriores revisados: '+board.previousWinners.map(w=>w.alias).join(', ');verified.append(winners);}
    }catch{label.textContent='No se pudo cargar la clasificación. No se presentan resultados como verificados.';}
  }
  void api<{competition:{enabled:boolean}}>('/status').then(async status=>{
    if(!status.competition.enabled)return;
    ranking.querySelectorAll(':scope > .ranking-symbol,:scope > div:not(.verified-board)').forEach(node=>node.remove());
    label.textContent='Competición habilitada por el organizador. Cada resultado se reproduce y valida en el servidor; los ganadores requieren revisión.';
    const pill=document.querySelector('.label-pill');if(pill)pill.textContent='COMPETICIÓN HABILITADA';
    await loadBoard();
    try {
      const me=await api<{alias:string|null}>('/me');const form=document.createElement('form');form.className='competition-form';const input=document.createElement('input');input.maxLength=24;input.minLength=2;input.required=true;input.value=me.alias??'';input.placeholder='Tu alias público';input.setAttribute('aria-label','Alias público para la clasificación');const submit=document.createElement('button');submit.className='button button-dark';submit.type='submit';submit.textContent='COMPETIR →';form.append(input,submit);ranking.append(form);
      form.addEventListener('submit',event=>{event.preventDefault();submit.disabled=true;void api('/profile',{alias:input.value}).then(()=>game.openCompetition()).catch(error=>{label.textContent=error instanceof Error?error.message:'No se pudo guardar el alias.';}).finally(()=>{submit.disabled=false;});});
      if(['127.0.0.1','localhost'].includes(location.hostname)){const notice=document.createElement('p');notice.className='integration-note';notice.textContent='Entorno local: identidad simulada de desarrollo. Estos resultados no son una clasificación pública verificada.';ranking.append(notice);}
    }catch(error){if(error instanceof ApiFailure&&error.status===401){const signIn=document.createElement('a');signIn.href='/signin-with-chatgpt?return_to=%2F%23ranking';signIn.target='_top';signIn.className='button button-dark';signIn.textContent='IDENTIFICARME PARA COMPETIR';ranking.append(signIn);}else label.textContent='No se pudo verificar la sesión. El modo práctica sigue disponible.';}
    window.addEventListener('ferchodoggs:result',()=>{void loadBoard();});
  }).catch(()=>{label.textContent='No se pudo consultar el servidor. El modo práctica sigue disponible. No hay resultados verificados cargados.';});
  const observed=new IntersectionObserver(entries=>{if(entries.some(entry=>entry.isIntersecting)){track('leaderboard_view');observed.disconnect();}});observed.observe(ranking);
  window.addEventListener('pagehide',()=>observed.disconnect(),{once:true});
}
Object.assign(window,{FerchoDoggsDash:game});
