/** Local development/test adapter only. Production uses the Sites D1 binding. */
import { DatabaseSync, type SQLInputValue } from 'node:sqlite';
import { readFileSync,readdirSync } from 'node:fs';
import type { Database, Statement } from './api.ts';
class LocalStatement implements Statement {
  private values: SQLInputValue[] = [];
  readonly database: DatabaseSync; readonly sql: string;
  constructor(database: DatabaseSync, sql: string) {this.database=database;this.sql=sql;}
  bind(...values: unknown[]) {this.values=values as SQLInputValue[];return this;}
  async first<T>() {return (this.database.prepare(this.sql).get(...this.values) as T)??null;}
  async all<T>() {return {results:this.database.prepare(this.sql).all(...this.values) as T[]};}
  execute() {return this.database.prepare(this.sql).run(...this.values);}
  async run() {return this.execute();}
}
export function createLocalDatabase(path=':memory:'): {db:Database;close:()=>void} {
  const sqlite=new DatabaseSync(path);sqlite.exec('PRAGMA foreign_keys=ON; PRAGMA journal_mode=WAL;');
  const version=sqlite.prepare('PRAGMA user_version').get() as {user_version:number};
  const migrationDir=new URL('../../drizzle/',import.meta.url);
  const migrations=readdirSync(migrationDir).filter(name=>/^\d+_.+\.sql$/.test(name)).sort();
  if(version.user_version>migrations.length)throw new Error('Local database schema is newer than this source; restore a compatible checkout.');
  for(let index=version.user_version;index<migrations.length;index++) {
    sqlite.exec('BEGIN IMMEDIATE');
    try {sqlite.exec(readFileSync(new URL(migrations[index],migrationDir),'utf8'));sqlite.exec(`PRAGMA user_version=${index+1}; COMMIT`);}catch(error){sqlite.exec('ROLLBACK');throw error;}
  }
  return {db:{
    prepare:sql=>new LocalStatement(sqlite,sql),
    async batch(statements) {
      sqlite.exec('BEGIN IMMEDIATE');
      try {const result=statements.map(statement=>(statement as LocalStatement).execute());sqlite.exec('COMMIT');return result;}catch(error){sqlite.exec('ROLLBACK');throw error;}
    }
  },close:()=>sqlite.close()};
}
