import { ENGINE_VERSION, MAX_CHUNK_TICKS, TICK_RATE, applyChunk, createGame } from '../game/engine.ts';
import type { GameState, RecordedAction } from '../game/engine.ts';
/** Inactividad máxima entre bloques: controla sesiones abandonadas sin limitar la duración de juego. */
export const INACTIVITY_MS = 300000;
import { ApiError, assert, competitionConfig, DEFAULT_CONFIG, identity, issueSession, onlyKeys, publicAlias, readJson, requestKey, requireAdmin, sameOrigin, stringField, validateEvent } from './validation.ts';
import type { CompetitionConfig } from './validation.ts';
import { naturalReportPeriod, periodAt } from './weekly.ts';

export interface Statement {
  bind(...values: unknown[]): Statement;
  first<T = Record<string, unknown>>(): Promise<T | null>;
  all<T = Record<string, unknown>>(): Promise<{results: T[]}>;
  run(): Promise<unknown>;
}
export interface Database { prepare(sql: string): Statement; batch(statements: Statement[]): Promise<unknown[]> }
export interface Env { DB?: Database; ADMIN_USER_IDS?: string; SESSION_SECRET?: string; TRUST_IDENTITY_HEADER?: string; ALLOWED_ORIGINS?: string; clock?: () => number }
type Run = {id:string;participant_id:string;request_id:string;seed:number;engine_version:string;week_id:string;created_at:number;expires_at:number;status:string;finished_at:number|null;finish_hash:string|null;score:number|null;end_tick:number|null;checkpoint_json:string|null;next_seq:number;last_seen_at:number|null};
type Chunk = {run_id:string;seq:number;hash:string;to_tick:number;status_after:string;score_after:number};
type Week = {id:string;starts_at:number;ends_at:number;timezone:string;config_json:string;engine_version:string;status:string;candidate_id:string|null;winner_id:string|null;delivered_at:number|null;revision:number;mutation_id:string|null};
const json = (value: unknown, status = 200) => new Response(JSON.stringify(value), {status,headers:{'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'}});
const currentTime = (env: Env) => env.clock?.() ?? Date.now();
/** Clave de firma de sesiones: SESSION_SECRET si existe; si no, una clave aleatoria creada una vez y guardada en la base (nunca sale del servidor). */
let cachedSecret: string | null = null;
async function withSecret(env: Env): Promise<Env> {
  if (env.SESSION_SECRET || !env.DB) return env;
  if (!cachedSecret) {
    const bytes = crypto.getRandomValues(new Uint8Array(32)); const fresh = Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
    await env.DB.prepare('INSERT OR IGNORE INTO app_secrets(id,value) VALUES(?,?)').bind('session', fresh).run();
    const row = await env.DB.prepare('SELECT value FROM app_secrets WHERE id=?').bind('session').first<{value:string}>();
    cachedSecret = row?.value ?? null;
  }
  return cachedSecret ? { ...env, SESSION_SECRET: cachedSecret } : env;
}
const dbOf = (env: Env): Database => { assert(env.DB,503,'database_unavailable','La competición no está disponible. El modo práctica sigue funcionando.'); return env.DB; };
async function configOf(db: Database): Promise<CompetitionConfig> {
  const row = await db.prepare('SELECT config_json FROM settings WHERE id=1').first<{config_json:string}>();
  return row ? competitionConfig(JSON.parse(row.config_json)) : {...DEFAULT_CONFIG};
}
function issue(run: Run, weekEndsAt?: number) { return {id:run.id,seed:run.seed,version:run.engine_version,weekId:run.week_id,createdAt:run.created_at,expiresAt:run.expires_at,weekEndsAt:weekEndsAt??null,nextSeq:run.next_seq??0,maxChunkTicks:MAX_CHUNK_TICKS,inactivitySeconds:INACTIVITY_MS/1000,unlimited:true,status:run.status}; }
function audit(db: Database, actor: string, action: string, target: string|null, reason: string|null, now: number, id: string = crypto.randomUUID()) {
  return db.prepare('INSERT OR IGNORE INTO audit(id,actor_id,action,target_id,reason,created_at) VALUES(?,?,?,?,?,?)').bind(id,actor,action,target,reason,now);
}
function guardedAudit(db:Database,actor:string,action:string,target:string,reason:string,now:number,weekId:string,mutation:string) {
  return db.prepare('INSERT INTO audit(id,actor_id,action,target_id,reason,created_at) SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM weeks WHERE id=? AND mutation_id=?)').bind(crypto.randomUUID(),actor,action,target,reason,now,weekId,mutation);
}
async function assertMutation(db:Database,weekId:string,mutation:string) {
  const stored=await db.prepare('SELECT mutation_id FROM weeks WHERE id=?').bind(weekId).first<{mutation_id:string}>();
  assert(stored?.mutation_id===mutation,409,'concurrent_admin_change','Otra revisión o entrega cambió la semana. Recarga antes de reintentar.');
}
function publicConfig(config: CompetitionConfig) {
  return {enabled:config.enabled,confirmed:config.confirmed,timezone:config.timezone,closeDay:config.closeDay,closeHour:config.closeHour,prize:config.prize||null,eligibility:config.eligibility||null,delivery:config.delivery||null,claim:config.claim||null,rules:config.rules||null};
}

/** Safe to invoke from a persistent scheduler. Also catches up closed periods on API reads. */
export async function maintenance(env: Env): Promise<{frozen:number}> {
  const db = dbOf(env); const now = currentTime(env);
  const due = await db.prepare("SELECT id FROM weeks WHERE status='open' AND ends_at<=?").bind(now).all<{id:string}>();
  for (const week of due.results) await db.batch([
    db.prepare("UPDATE weeks SET status='frozen',frozen_at=?,revision=revision+1,candidate_id=(SELECT participant_id FROM leaderboard WHERE week_id=? ORDER BY score DESC,received_at ASC,receipt_sequence ASC,participant_id ASC LIMIT 1) WHERE id=? AND status='open' AND ends_at<=?").bind(now,week.id,week.id,now),
    audit(db,'system','freeze_week',week.id,'Cierre de periodo; candidato pendiente de revisión humana.',now,`freeze:${week.id}`),
    db.prepare("UPDATE runs SET status='expired' WHERE week_id=? AND status='active'").bind(week.id)
  ]);
  return {frozen:due.results.length};
}

async function start(request: Request, env: Env, body: Record<string,unknown>): Promise<Response> {
  const participant = await identity(request,env); const db = dbOf(env); const now = currentTime(env);
  onlyKeys(body,['requestId']); const key = requestKey(body.requestId);
  const prior = await db.prepare('SELECT * FROM runs WHERE participant_id=? AND request_id=?').bind(participant,key).first<Run>();
  if (prior) return json({run:issue(prior),reused:true});
  const config = await configOf(db);
  assert(config.enabled,409,'competition_disabled','La competición está desactivada; puedes jugar en práctica.');
  const period = periodAt(now,config);
  await maintenance(env);
  await db.batch([
    db.prepare('INSERT OR IGNORE INTO participants(id,alias,created_at) VALUES(?,?,?)').bind(participant,'Jugador',now),
    db.prepare("UPDATE runs SET status='expired' WHERE participant_id=? AND status='active' AND expires_at<?").bind(participant,now),
    db.prepare('INSERT OR IGNORE INTO weeks(id,starts_at,ends_at,timezone,config_json,engine_version) SELECT ?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM settings WHERE id=1 AND config_json=?)').bind(period.id,period.start,period.end,period.timezone,JSON.stringify(config),ENGINE_VERSION,JSON.stringify(config))
  ]);
  const week = await db.prepare('SELECT * FROM weeks WHERE id=?').bind(period.id).first<Week>();
  assert(week?.status === 'open' && week.engine_version === ENGINE_VERSION,409,'week_unavailable','La semana no admite nuevas partidas.');
  const existing = await db.prepare("SELECT * FROM runs WHERE participant_id=? AND status='active'").bind(participant).first<Run>();
  if(existing?.request_id===key)return json({run:issue(existing),reused:true});
  assert(!existing,409,'active_run_exists','Ya tienes una partida clasificatoria activa.');
  const recent = await db.prepare('SELECT COUNT(*) AS total FROM runs WHERE participant_id=? AND created_at>?').bind(participant,now-60000).first<{total:number}>();
  assert(Number(recent?.total??0)<5,429,'start_rate_limit','Espera antes de iniciar otra partida.');
  const seed = crypto.getRandomValues(new Uint32Array(1))[0]; const id = crypto.randomUUID();
  try {
    await db.prepare("INSERT INTO runs(id,participant_id,request_id,seed,engine_version,week_id,created_at,expires_at) SELECT ?,?,?,?,?,?,?,? WHERE EXISTS(SELECT 1 FROM settings WHERE id=1 AND config_json=?) AND EXISTS(SELECT 1 FROM weeks WHERE id=? AND status='open' AND ends_at>? AND engine_version=?)").bind(id,participant,key,seed,ENGINE_VERSION,period.id,now,now+INACTIVITY_MS,JSON.stringify(config),period.id,now,ENGINE_VERSION).run();
  } catch {
    const raced = await db.prepare('SELECT * FROM runs WHERE participant_id=? AND request_id=?').bind(participant,key).first<Run>();
    if (raced) return json({run:issue(raced),reused:true});
    throw new ApiError(409,'active_run_exists','Ya tienes una partida clasificatoria activa.');
  }
  const run = await db.prepare('SELECT * FROM runs WHERE id=?').bind(id).first<Run>();
  assert(run,409,'competition_changed','La configuración o el periodo cambiaron durante el inicio. Vuelve a cargar antes de reintentar.');
  const closesSoon = period.end - now < 10*60000;
  return json({run:issue(run,period.end),reused:false,warning:closesSoon?'La semana cierra en menos de 10 minutos: para clasificar, la carrera debe terminar y recibirse antes del cierre. Si sigue después, continúa como práctica.':null},201);
}

function validChunkActions(value: unknown, fromTick: number, toTick: number): RecordedAction[] {
  assert(Array.isArray(value) && value.length <= toTick - fromTick, 400, 'action_limit', 'Registro de acciones no válido.');
  let previous = fromTick - 1;
  return value.map(action => {
    assert(action && typeof action === 'object' && !Array.isArray(action), 400, 'invalid_action', 'Acción no válida.');
    onlyKeys(action as Record<string,unknown>, ['tick','type']);
    const {tick,type} = action as {tick:unknown;type:unknown};
    assert(Number.isInteger(tick) && Number(tick) > previous && Number(tick) < toTick, 400, 'action_order', 'Las acciones deben ser únicas, ordenadas y estar dentro del bloque.');
    assert(type==='left'||type==='right'||type==='jump', 400, 'invalid_action', 'Acción no válida.');
    previous = Number(tick);
    return {tick:Number(tick),type};
  });
}

/** Bloque ordenado de acciones. Idempotente por (partida, secuencia); el servidor reproduce y calcula la puntuación. */
async function chunk(request: Request, env: Env, body: Record<string,unknown>): Promise<Response> {
  const participant = await identity(request,env); const db = dbOf(env); const now = currentTime(env);
  onlyKeys(body,['id','version','seq','fromTick','toTick','actions','final']);
  const id = stringField(body.id,'Partida',8,80);
  const run = await db.prepare('SELECT * FROM runs WHERE id=?').bind(id).first<Run>();
  assert(run && run.participant_id === participant,404,'run_not_found','Partida no encontrada.');
  assert(body.version===run.engine_version && body.version===ENGINE_VERSION,409,'engine_version_mismatch','Versión del motor no compatible.');
  assert(Number.isInteger(body.seq) && Number(body.seq)>=0,400,'invalid_sequence','Número de bloque no válido.');
  assert(typeof body.final==='boolean',400,'invalid_final','Indica si es el bloque final.');
  const seq = Number(body.seq), fromTick = Number(body.fromTick), toTick = Number(body.toTick), final = body.final as boolean;
  assert(Number.isInteger(fromTick) && Number.isInteger(toTick) && fromTick>=0 && toTick>fromTick && toTick-fromTick<=MAX_CHUNK_TICKS,400,'invalid_chunk','Rango de bloque no válido.');
  const actions = validChunkActions(body.actions,fromTick,toTick);
  const digest = await crypto.subtle.digest('SHA-256',new TextEncoder().encode(JSON.stringify({id,seq,fromTick,toTick,actions,final})));
  const hash = [...new Uint8Array(digest)].map(x=>x.toString(16).padStart(2,'0')).join('');
  const prior = await db.prepare('SELECT * FROM run_chunks WHERE run_id=? AND seq=?').bind(id,seq).first<Chunk>();
  if (prior) {
    assert(prior.hash===hash,409,'chunk_conflict','Ese bloque ya se recibió con otro contenido.');
    const current = await db.prepare('SELECT status,next_seq,score FROM runs WHERE id=?').bind(id).first<{status:string;next_seq:number;score:number|null}>();
    return json({accepted:true,duplicate:true,seq,tick:prior.to_tick,status:prior.status_after,score:prior.score_after,nextSeq:current?.next_seq??seq+1,runStatus:current?.status});
  }
  assert(run.status==='active',409,'run_closed','La partida ya no está activa. Puedes seguir en práctica.');
  assert(seq===run.next_seq,409,'chunk_out_of_order',`Falta el bloque ${run.next_seq}. Reenvía los bloques en orden.`);
  const week = await db.prepare('SELECT * FROM weeks WHERE id=?').bind(run.week_id).first<Week>();
  assert(week && week.status==='open' && now < week.ends_at,409,'week_closed','La semana cerró: esta carrera sigue como práctica y no suma a la nueva semana.');
  if (now > run.expires_at) {
    await db.prepare("UPDATE runs SET status='expired',finished_at=? WHERE id=? AND status='active'").bind(now,id).run();
    throw new ApiError(410,'run_expired','La partida venció por inactividad.');
  }
  const state: GameState = seq===0 ? createGame(run.seed) : JSON.parse(run.checkpoint_json ?? 'null');
  assert(state && state.tick===fromTick,409,'chunk_gap','El bloque no continúa desde el último tick recibido.');
  assert(toTick/TICK_RATE*1000 <= now-run.created_at+2000,422,'impossible_time','La duración simulada supera el tiempo real.');
  let result: GameState;
  try { result = applyChunk(state,actions,toTick); } catch { throw new ApiError(422,'invalid_replay','El bloque no produce una partida válida.'); }
  assert(result.status==='running' || final,422,'death_requires_final','La colisión debe enviarse como bloque final.');
  const statusAfter = final ? 'finished' : 'running';
  try {
    await db.batch([
      db.prepare('INSERT INTO run_chunks(run_id,seq,hash,to_tick,status_after,score_after,created_at) VALUES(?,?,?,?,?,?,?)').bind(id,seq,hash,toTick,statusAfter,result.score,now),
      db.prepare("UPDATE runs SET checkpoint_json=?,next_seq=next_seq+1,last_seen_at=?,expires_at=?,end_tick=? WHERE id=? AND next_seq=? AND status='active'").bind(JSON.stringify(result),now,now+INACTIVITY_MS,toTick,id,seq)
    ]);
  } catch {
    const raced = await db.prepare('SELECT * FROM run_chunks WHERE run_id=? AND seq=?').bind(id,seq).first<Chunk>();
    assert(raced && raced.hash===hash,409,'chunk_conflict','Ese bloque ya se recibió con otro contenido.');
    return json({accepted:true,duplicate:true,seq,tick:raced.to_tick,status:raced.status_after,score:raced.score_after,nextSeq:seq+1});
  }
  if (!final) return json({accepted:true,duplicate:false,seq,tick:toTick,status:'running',score:result.score,nextSeq:seq+1,provisional:true});
  // Bloque final: cerrar la partida y clasificar en una única transacción.
  await db.batch([
    db.prepare("UPDATE runs SET status='valid',finished_at=?,finish_hash=?,score=?,end_tick=? WHERE id=? AND participant_id=? AND status='active' AND EXISTS(SELECT 1 FROM weeks WHERE id=? AND status='open' AND ends_at>?)").bind(now,hash,result.score,toTick,id,participant,run.week_id,now),
    db.prepare("INSERT OR IGNORE INTO results(run_id,participant_id,week_id,score,received_at) SELECT id,participant_id,week_id,score,finished_at FROM runs WHERE id=? AND status='valid' AND finish_hash=?").bind(id,hash),
    db.prepare("INSERT OR IGNORE INTO receipts(run_id) SELECT run_id FROM results WHERE run_id=? AND status='valid' AND EXISTS(SELECT 1 FROM runs WHERE id=? AND finish_hash=?)").bind(id,id,hash),
    db.prepare("INSERT INTO leaderboard(week_id,participant_id,score,received_at,run_id,receipt_sequence) SELECT r.week_id,r.participant_id,r.score,r.received_at,r.run_id,q.sequence FROM results r JOIN receipts q ON q.run_id=r.run_id WHERE r.run_id=? AND r.status='valid' AND EXISTS(SELECT 1 FROM runs WHERE id=? AND finish_hash=?) ON CONFLICT(week_id,participant_id) DO UPDATE SET score=excluded.score,received_at=excluded.received_at,run_id=excluded.run_id,receipt_sequence=excluded.receipt_sequence WHERE excluded.score>leaderboard.score OR (excluded.score=leaderboard.score AND (excluded.received_at<leaderboard.received_at OR (excluded.received_at=leaderboard.received_at AND excluded.receipt_sequence<leaderboard.receipt_sequence)))").bind(id,id,hash),
    db.prepare("INSERT INTO personal_bests(participant_id,score,run_id,updated_at) SELECT participant_id,score,id,finished_at FROM runs WHERE id=? AND status='valid' AND finish_hash=? ON CONFLICT(participant_id) DO UPDATE SET score=excluded.score,run_id=excluded.run_id,updated_at=excluded.updated_at WHERE excluded.score>personal_bests.score").bind(id,hash)
  ]);
  const stored = await db.prepare('SELECT * FROM runs WHERE id=?').bind(id).first<Run>();
  assert(stored?.status==='valid' && stored.finish_hash===hash,409,'finish_conflict','La partida se cerró durante el envío. Consulta su estado antes de reintentar.');
  const outcome = await db.prepare('SELECT status FROM results WHERE run_id=?').bind(id).first<{status:string}>();
  const best = await db.prepare('SELECT score FROM personal_bests WHERE participant_id=?').bind(participant).first<{score:number}>();
  return json({accepted:true,duplicate:false,seq,tick:toTick,status:outcome?.status??'review',score:stored.score,personalBest:best?.score??stored.score,review:'Los ganadores requieren revisión humana; la reproducción no demuestra que jugó una persona.'});
}

async function leaderboard(env: Env): Promise<Response> {
  const db = dbOf(env); await maintenance(env); const config = await configOf(db);
  const period = periodAt(currentTime(env),config);
  const week = await db.prepare('SELECT * FROM weeks WHERE id=?').bind(period.id).first<Week>();
  const rows = await db.prepare('SELECT p.alias,l.score,l.received_at FROM leaderboard l JOIN participants p ON p.id=l.participant_id WHERE l.week_id=? ORDER BY l.score DESC,l.received_at ASC,l.receipt_sequence ASC,l.participant_id ASC LIMIT 100').bind(period.id).all<{alias:string;score:number;received_at:number}>();
  const winners = await db.prepare("SELECT w.id,w.ends_at,p.alias FROM weeks w JOIN participants p ON p.id=w.winner_id WHERE w.status='frozen' AND w.winner_id IS NOT NULL ORDER BY w.ends_at DESC LIMIT 8").all();
  const snapshot = week ? competitionConfig(JSON.parse(week.config_json)) : config;
  return json({enabled:config.enabled,week:{id:period.id,start:period.start,end:period.end,timezone:period.timezone,status:week?.status??'not_started'},rules:publicConfig(snapshot),scoring:{version:ENGINE_VERSION,pointsPerSecond:10,pointsPerCoin:25,unlimited:true,chunkTicks:MAX_CHUNK_TICKS},rows:rows.results.map((r,index)=>({rank:index+1,alias:r.alias,score:r.score,status:'valid'})),previousWinners:winners.results,notice:'El alias público no acredita la propiedad de una cuenta social. Ganadores sujetos a revisión.'});
}

async function generateReport(db: Database, now: number): Promise<unknown> {
  const period = naturalReportPeriod(now);
  const counts = async (start:number,end:number) => {
    const metrics = await db.prepare('SELECT name,COUNT(*) AS count,COUNT(DISTINCT session_id) AS sessions FROM events WHERE received_at>=? AND received_at<? GROUP BY name').bind(start,end).all();
    const results = await db.prepare("SELECT COUNT(*) AS validResults,COUNT(DISTINCT participant_id) AS players FROM results WHERE received_at>=? AND received_at<? AND status='valid'").bind(start,end).first();
    return {events:metrics.results,competition:results,confirmedPurchases:null,visitors:'Sesiones estimadas con consentimiento; no son personas verificadas.'};
  };
  const payload = {period,current:await counts(period.start,period.end),previous:await counts(period.previous.start,period.previous.end),contest:(await db.prepare('SELECT id,status,ends_at,winner_id IS NOT NULL AS winnerReviewed,delivered_at IS NOT NULL AS delivered FROM weeks ORDER BY ends_at DESC LIMIT 1').first()),incidents:'Revisar logs del proveedor; no hay monitor externo conectado.',suggestionsBasis:'Propuestas de revisión; requieren analizar los datos antes de aprobar cambios.',suggestions:['Comparar apertura e inicio del juego para ajustar el tutorial.','Revisar errores de envío antes de interpretar resultados ausentes.','Comparar vistas de productos y clics con pedidos confirmados cuando exista integración.'],delivery:'Pendiente de canal y programación persistente verificada.'};
  await db.prepare('INSERT OR IGNORE INTO reports(id,starts_at,ends_at,timezone,payload_json) VALUES(?,?,?,?,?)').bind(`report:${period.end}`,period.start,period.end,period.timezone,JSON.stringify(payload)).run();
  const stored=await db.prepare('SELECT payload_json FROM reports WHERE id=?').bind(`report:${period.end}`).first<{payload_json:string}>();
  return stored ? JSON.parse(stored.payload_json) : payload;
}

async function admin(request: Request, env: Env, body?: Record<string,unknown>): Promise<Response> {
  const actor = await requireAdmin(request,env); const db = dbOf(env); const now = currentTime(env);
  await maintenance(env);
  if (!body) {
    const [weeks,runs,audits,reports] = await Promise.all([
      db.prepare('SELECT * FROM weeks ORDER BY ends_at DESC LIMIT 20').all(),
      db.prepare("SELECT r.run_id AS id,r.week_id,r.score,r.received_at,r.status,r.reason,p.alias FROM results r JOIN participants p ON p.id=r.participant_id WHERE r.status!='valid' ORDER BY r.received_at DESC LIMIT 100").all(),
      db.prepare('SELECT action,target_id,reason,created_at FROM audit ORDER BY created_at DESC LIMIT 50').all(),
      db.prepare('SELECT id,starts_at,ends_at,status,attempts,delivered_at FROM reports ORDER BY ends_at DESC LIMIT 10').all()
    ]);
    return json({config:await configOf(db),weeks:weeks.results,review:runs.results,audit:audits.results,reports:reports.results,scheduler:{active:false,timezone:'Europe/Madrid',desired:'Lunes 09:00',reason:'Falta desplegar y verificar un programador persistente y definir canal.'}});
  }
  onlyKeys(body,['action','config','weekId','runId','reason','candidateId','winnerId','revision']);
  const action = stringField(body.action,'Acción',1,24);
  if (action==='config') {
    const config = competitionConfig(body.config);
    const active = await db.prepare("SELECT config_json FROM weeks WHERE status='open' AND starts_at<=? AND ends_at>? LIMIT 1").bind(now,now).first<{config_json:string}>();
    if (active) {
      const frozenRules = competitionConfig(JSON.parse(active.config_json));
      const comparable = (value:CompetitionConfig) => JSON.stringify(Object.fromEntries(Object.entries(value).filter(([key])=>key!=='enabled').sort(([a],[b])=>a.localeCompare(b))));
      assert(comparable(config)===comparable(frozenRules),409,'active_week_immutable','No cambies reglas durante una semana activa. Solo puedes pausar o reanudar con las mismas reglas.');
    }
    const serialized=JSON.stringify(config);
    const auditId=crypto.randomUUID();
    const allowed="NOT EXISTS(SELECT 1 FROM weeks WHERE status='open' AND starts_at<=? AND ends_at>? AND json_remove(config_json,'$.enabled')!=json_remove(?,'$.enabled'))";
    await db.batch([
      db.prepare(`INSERT INTO settings(id,config_json) SELECT 1,? WHERE ${allowed} ON CONFLICT(id) DO UPDATE SET config_json=excluded.config_json WHERE ${allowed}`).bind(serialized,now,now,serialized,now,now,serialized),
      db.prepare('INSERT INTO audit(id,actor_id,action,target_id,reason,created_at) SELECT ?,?,?,NULL,?,? WHERE EXISTS(SELECT 1 FROM settings WHERE id=1 AND config_json=?)').bind(auditId,actor,'configure','Configuración guardada sin cambiar reglas de una semana activa.',now,serialized)
    ]);
    const stored=await configOf(db);
    assert(JSON.stringify(stored)===serialized,409,'active_week_immutable','La semana comenzó o cambió durante la configuración. Recarga el estado.');
    return json({status:'configured',config:publicConfig(stored)});
  }
  if (action==='disable') {
    const fallback = {...DEFAULT_CONFIG,enabled:false};
    await db.batch([db.prepare("INSERT INTO settings(id,config_json) VALUES(1,?) ON CONFLICT(id) DO UPDATE SET config_json=json_set(settings.config_json,'$.enabled',json('false'))").bind(JSON.stringify(fallback)),audit(db,actor,'disable',null,stringField(body.reason,'Motivo',3,500),now)]);
    return json({status:'disabled'});
  }
  if (action==='report') return json({report:await generateReport(db,now)});
  if (action==='invalidate'||action==='review') {
    const runId = stringField(body.runId,'Partida',8,80); const reason = stringField(body.reason,'Motivo',3,500);
    const result = await db.prepare('SELECT * FROM results WHERE run_id=?').bind(runId).first<{week_id:string;participant_id:string}>();
    assert(result,404,'result_not_found','Resultado no encontrado.');
    const week = await db.prepare('SELECT * FROM weeks WHERE id=?').bind(result.week_id).first<Week>();
    assert(!week?.delivered_at,409,'prize_already_delivered','La entrega registrada requiere una revisión manual aparte.');
    assert(week,404,'week_not_found','Semana no encontrada.');
    const status = action==='invalidate'?'invalid':'review';
    const mutation=crypto.randomUUID();
    await db.batch([
      db.prepare('UPDATE weeks SET revision=revision+1,mutation_id=? WHERE id=? AND revision=? AND delivered_at IS NULL').bind(mutation,week.id,week.revision),
      db.prepare('UPDATE results SET status=?,reason=? WHERE run_id=? AND EXISTS(SELECT 1 FROM weeks WHERE id=? AND mutation_id=?)').bind(status,reason,runId,week.id,mutation),
      db.prepare('DELETE FROM leaderboard WHERE week_id=? AND participant_id=? AND EXISTS(SELECT 1 FROM weeks WHERE id=? AND mutation_id=?)').bind(result.week_id,result.participant_id,week.id,mutation),
      db.prepare("INSERT INTO leaderboard(week_id,participant_id,score,received_at,run_id,receipt_sequence) SELECT r.week_id,r.participant_id,r.score,r.received_at,r.run_id,COALESCE(q.sequence,0) FROM results r LEFT JOIN receipts q ON q.run_id=r.run_id WHERE r.week_id=? AND r.participant_id=? AND r.status='valid' AND EXISTS(SELECT 1 FROM weeks WHERE id=? AND mutation_id=?) ORDER BY r.score DESC,r.received_at ASC,COALESCE(q.sequence,0) ASC,r.run_id ASC LIMIT 1").bind(result.week_id,result.participant_id,week.id,mutation),
      db.prepare("UPDATE weeks SET candidate_id=(SELECT participant_id FROM leaderboard WHERE week_id=? ORDER BY score DESC,received_at ASC,receipt_sequence ASC,participant_id ASC LIMIT 1),winner_id=NULL WHERE id=? AND status='frozen' AND mutation_id=?").bind(result.week_id,result.week_id,mutation),
      guardedAudit(db,actor,action,runId,reason,now,week.id,mutation)
    ]);
    await assertMutation(db,week.id,mutation);
    return json({status});
  }
  const weekId = stringField(body.weekId,'Semana',8,200);
  const week = await db.prepare('SELECT * FROM weeks WHERE id=?').bind(weekId).first<Week>();
  assert(week,404,'week_not_found','Semana no encontrada.');
  if (action==='freeze') {
    assert(now>=week.ends_at,409,'week_still_open','No cierres un periodo antes de su fecha de cierre.');
    await maintenance(env); return json({status:'frozen'});
  }
  assert(week.status==='frozen',409,'week_still_open','La semana debe estar cerrada.');
  if (action==='approve') {
    assert(week.candidate_id,409,'no_candidate','No hay un resultado válido para revisar.');
    assert(body.candidateId===week.candidate_id && body.revision===week.revision,409,'stale_review','El candidato cambió desde la revisión. Recarga la semana antes de aprobar.');
    assert(!week.delivered_at,409,'prize_already_delivered','La entrega ya está registrada.');
    const reason = stringField(body.reason,'Revisión del ganador',3,500); const mutation=crypto.randomUUID();
    await db.batch([
      db.prepare("UPDATE weeks SET winner_id=candidate_id,revision=revision+1,mutation_id=? WHERE id=? AND status='frozen' AND revision=? AND candidate_id=? AND delivered_at IS NULL").bind(mutation,weekId,week.revision,week.candidate_id),
      guardedAudit(db,actor,'approve_winner',weekId,reason,now,weekId,mutation)
    ]);
    await assertMutation(db,weekId,mutation);
    return json({status:'approved'});
  }
  if (action==='delivered') {
    assert(week.winner_id,409,'winner_not_approved','Aprueba al ganador antes de registrar la entrega.');
    assert(body.winnerId===week.winner_id,409,'stale_review','El ganador cambió. Recarga el estado antes de registrar una entrega.');
    const reason = stringField(body.reason,'Entrega',3,500);
    if (week.delivered_at) return json({status:'delivered',duplicate:true});
    assert(body.revision===week.revision,409,'stale_review','La revisión cambió. Recarga el estado antes de registrar una entrega.');
    const mutation=crypto.randomUUID();
    await db.batch([
      db.prepare("UPDATE weeks SET delivered_at=?,revision=revision+1,mutation_id=? WHERE id=? AND status='frozen' AND revision=? AND winner_id=? AND delivered_at IS NULL").bind(now,mutation,weekId,week.revision,week.winner_id),
      guardedAudit(db,actor,'prize_delivered',weekId,reason,now,weekId,mutation)
    ]);
    await assertMutation(db,weekId,mutation);
    return json({status:'delivered',duplicate:false});
  }
  throw new ApiError(400,'unknown_action','Acción no reconocida.');
}

export async function handleApi(request: Request, rawEnv: Env): Promise<Response> {
  try {
    const env = rawEnv.TRUST_IDENTITY_HEADER === '1' ? rawEnv : await withSecret(rawEnv);
    const path = new URL(request.url).pathname;
    if (request.method==='GET' && path==='/api/health') return json({ok:true,engine:ENGINE_VERSION,practice:true});
    if (request.method==='GET' && path==='/api/status') {
      if (!env.DB) return json({practice:true,competition:{enabled:false,reason:'Backend pendiente de configurar.'},analytics:{available:false},engine:ENGINE_VERSION});
      await maintenance(env); const config = await configOf(env.DB); const period = periodAt(currentTime(env),config);
      return json({practice:true,competition:{...publicConfig(config),period:{start:period.start,end:period.end,timezone:period.timezone},proposed:!config.confirmed},analytics:{available:true},engine:ENGINE_VERSION});
    }
    if (request.method==='GET' && path==='/api/leaderboard') return await leaderboard(env);
    if (request.method==='GET' && path==='/api/admin') return await admin(request,env);
    if (request.method==='GET' && path==='/api/me') {
      const id = await identity(request,env); const db = dbOf(env);
      const person = await db.prepare('SELECT alias FROM participants WHERE id=?').bind(id).first();
      return json({authenticated:true,alias:person?.alias??null,admin:(env.ADMIN_USER_IDS??'').split(',').map(s=>s.trim()).includes(id)});
    }
    if (request.method==='GET' && path.startsWith('/api/runs/')) {
      const id = await identity(request,env); const run = await dbOf(env).prepare('SELECT * FROM runs WHERE id=? AND participant_id=?').bind(path.slice('/api/runs/'.length),id).first<Run>();
      assert(run,404,'run_not_found','Partida no encontrada.');
      return json({run:issue(run),score:run.score});
    }
    if (request.method!=='POST') throw new ApiError(404,'not_found','Ruta no encontrada.');
    sameOrigin(request,env); const body = await readJson(request);
    if (path==='/api/session') { onlyKeys(body,[]); return json(await issueSession(env)); }
    if (path==='/api/runs/start') return await start(request,env,body);
    if (path==='/api/runs/chunk') return await chunk(request,env,body);
    if (path==='/api/runs/finish') throw new ApiError(410,'use_chunks','El motor v2 valida la partida por bloques: usa /api/runs/chunk.');
    if (path==='/api/runs/abandon') {
      const participant = await identity(request,env); onlyKeys(body,['id']); const id=stringField(body.id,'Partida',8,80); const db=dbOf(env);
      const run=await db.prepare('SELECT * FROM runs WHERE id=? AND participant_id=?').bind(id,participant).first<Run>();
      assert(run,404,'run_not_found','Partida no encontrada.');
      await db.prepare("UPDATE runs SET status='expired',finished_at=? WHERE id=? AND participant_id=? AND status='active'").bind(currentTime(env),id,participant).run();
      const stored=await db.prepare('SELECT status FROM runs WHERE id=? AND participant_id=?').bind(id,participant).first<{status:string}>();
      return json({status:stored?.status,duplicate:run.status!=='active'});
    }
    if (path==='/api/admin') return await admin(request,env,body);
    if (path==='/api/profile') {
      const id = await identity(request,env); onlyKeys(body,['alias']); const alias = publicAlias(body.alias); const db = dbOf(env);
      await db.prepare('INSERT INTO participants(id,alias,created_at) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET alias=excluded.alias').bind(id,alias,currentTime(env)).run();
      return json({alias,notice:'Tu alias es público; cambiarlo conserva la misma identidad semanal.'});
    }
    if (path==='/api/events') {
      const event = validateEvent(body); const db = dbOf(env);
      await db.prepare('INSERT OR IGNORE INTO events(id,session_id,name,properties_json,received_at) VALUES(?,?,?,?,?)').bind(event.id,event.sessionId,event.name,JSON.stringify(event.properties),currentTime(env)).run();
      return json({status:'recorded'},202);
    }
    throw new ApiError(404,'not_found','Ruta no encontrada.');
  } catch (error) {
    if (error instanceof ApiError) return json({error:{code:error.code,message:error.message}},error.status);
    console.error('FERCHODOGGS API unavailable',error instanceof Error?error.name:'Error');
    return json({error:{code:'service_unavailable',message:'No se pudo completar la solicitud. Conserva el registro y reintenta; no se ha confirmado éxito.'}},503);
  }
}
