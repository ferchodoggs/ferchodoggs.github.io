export class ApiError extends Error {
  status: number; code: string;
  constructor(status: number, code: string, message: string) { super(message); this.status=status; this.code=code; }
}

export function assert(condition: unknown, status: number, code: string, message: string): asserts condition {
  if (!condition) throw new ApiError(status, code, message);
}

export type IdentityEnv = { SESSION_SECRET?: string; TRUST_IDENTITY_HEADER?: string; ALLOWED_ORIGINS?: string };
const encoder = new TextEncoder();
const SESSION_ID = /^p_[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
async function sign(secret: string, data: string): Promise<string> {
  const key = await crypto.subtle.importKey('raw', encoder.encode(secret), { name: 'HMAC', hash: 'SHA-256' }, false, ['sign']);
  const bytes = new Uint8Array(await crypto.subtle.sign('HMAC', key, encoder.encode(data)));
  let text = ''; for (const b of bytes) text += String.fromCharCode(b);
  return btoa(text).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}
function sameText(a: string, b: string): boolean { if (a.length !== b.length) return false; let diff = 0; for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i); return diff === 0; }

/** Identidad propia de FERCHODOGGS: un token por dispositivo firmado en el servidor (HMAC). No prueba quién es la persona;
 * los premios se entregan tras verificar al ganador por WhatsApp con su recibo. */
export async function issueSession(env: IdentityEnv): Promise<{ id: string; token: string }> {
  assert(env.SESSION_SECRET && env.SESSION_SECRET.length >= 32, 503, 'identity_unavailable', 'La competición no está disponible ahora. El modo práctica sigue funcionando.');
  const id = 'p_' + crypto.randomUUID();
  return { id, token: `${id}.${await sign(env.SESSION_SECRET, id)}` };
}

export async function identity(request: Request, env: IdentityEnv = {}): Promise<string> {
  const auth = request.headers.get('authorization');
  if (auth?.startsWith('Bearer ') && env.SESSION_SECRET) {
    const token = auth.slice(7).trim(); const dot = token.lastIndexOf('.');
    const id = dot > 0 ? token.slice(0, dot) : '';
    if (SESSION_ID.test(id) && sameText(await sign(env.SESSION_SECRET, id), token.slice(dot + 1))) return id;
    throw new ApiError(401, 'invalid_session', 'Tu sesión de juego no es válida. Recarga la página.');
  }
  if (env.TRUST_IDENTITY_HEADER === '1') { // solo pruebas y desarrollo local: nunca activar en producción
    const id = request.headers.get('oai-authenticated-user-id');
    assert(id && id.length <= 200, 401, 'authentication_required', 'Inicia sesión para competir.');
    return id;
  }
  throw new ApiError(401, 'authentication_required', 'Entra a la competición para guardar tu puntuación.');
}

export async function requireAdmin(request: Request, env: IdentityEnv & { ADMIN_USER_IDS?: string }): Promise<string> {
  const id = await identity(request, env);
  assert((env.ADMIN_USER_IDS ?? '').split(',').map(x => x.trim()).filter(Boolean).includes(id), 403, 'admin_required', 'Acceso privado.');
  return id;
}

export const DEFAULT_ORIGINS = 'https://ferchodoggs.github.io';
export function allowedOrigins(env: IdentityEnv): string[] { return (env.ALLOWED_ORIGINS ?? DEFAULT_ORIGINS).split(',').map(x => x.trim()).filter(Boolean); }

export function sameOrigin(request: Request, env: IdentityEnv = {}): void {
  const origin = request.headers.get('origin');
  assert(origin === new URL(request.url).origin || (origin !== null && allowedOrigins(env).includes(origin)), 403, 'origin_rejected', 'Origen no autorizado.');
}

export async function readJson(request: Request, maxBytes = 262144): Promise<Record<string, unknown>> {
  assert(request.headers.get('content-type')?.split(';')[0] === 'application/json', 415, 'json_required', 'Se requiere JSON.');
  assert(Number(request.headers.get('content-length') ?? 0) <= maxBytes, 413, 'body_too_large', 'Registro demasiado grande.');
  assert(request.body, 400, 'body_required', 'Faltan datos.');
  const reader = request.body.getReader();
  let total = 0;
  const chunks: Uint8Array[] = [];
  for (;;) {
    const part = await reader.read();
    if (part.done) break;
    total += part.value.length;
    if (total > maxBytes) { await reader.cancel(); throw new ApiError(413, 'body_too_large', 'Registro demasiado grande.'); }
    chunks.push(part.value);
  }
  const bytes = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
  try {
    const value: unknown = JSON.parse(new TextDecoder().decode(bytes));
    assert(value && typeof value === 'object' && !Array.isArray(value), 400, 'invalid_body', 'Objeto JSON no válido.');
    return value as Record<string, unknown>;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError(400, 'invalid_json', 'JSON no válido.');
  }
}

export function onlyKeys(value: Record<string, unknown>, allowed: string[]): void {
  assert(Object.keys(value).every(key => allowed.includes(key)), 400, 'unknown_property', 'Propiedad no permitida. La puntuación se calcula en el servidor.');
}

export function stringField(value: unknown, name: string, min = 1, max = 200): string {
  assert(typeof value === 'string' && value.trim().length >= min && value.length <= max, 400, 'invalid_field', `${name} no válido.`);
  return value.trim();
}

export function requestKey(value: unknown): string {
  const key = stringField(value, 'requestId', 8, 80);
  assert(/^[a-zA-Z0-9_-]+$/.test(key), 400, 'invalid_request_id', 'requestId no válido.');
  return key;
}

export function publicAlias(value: unknown): string {
  const alias = stringField(value, 'Alias', 2, 24);
  assert(/^@?[\p{L}\p{N}_.-]+$/u.test(alias), 400, 'invalid_alias', 'Usa letras, números, punto, guion o guion bajo.');
  return alias;
}

export interface LoggedAction { tick: number; type: 'left' | 'right' | 'jump' }
export function validateActions(actions: unknown, endTick: unknown, maxTicks: number): {actions: LoggedAction[]; endTick: number} {
  assert(Number.isInteger(endTick) && Number(endTick) >= 1 && Number(endTick) <= maxTicks, 400, 'invalid_duration', 'Duración simulada no válida.');
  assert(Array.isArray(actions) && actions.length <= 5000, 400, 'action_limit', 'Registro de acciones no válido.');
  let previous = -1;
  for (const action of actions) {
    assert(action && typeof action === 'object' && !Array.isArray(action), 400, 'invalid_action', 'Acción no válida.');
    onlyKeys(action, ['tick', 'type']);
    assert(Number.isInteger(action.tick) && action.tick > previous && action.tick < Number(endTick) && action.tick >= 0, 400, 'action_order', 'Las acciones deben ser únicas y ordenadas por tick.');
    assert(['left', 'right', 'jump'].includes(action.type), 400, 'invalid_action', 'Acción no válida.');
    previous = action.tick;
  }
  return { actions:actions.map(action=>({tick:action.tick,type:action.type})), endTick: Number(endTick) };
}

export function validateTiming(now: number, created: number, expires: number, weekEnd: number, ticks: number, rate: number): void {
  assert(now < weekEnd, 409, 'week_closed', 'La semana ha cerrado; el resultado no entra retroactivamente.');
  assert(now <= expires, 410, 'run_expired', 'La partida ha vencido.');
  const elapsed = now - created;
  const simulated = ticks / rate * 1000;
  assert(elapsed >= simulated - 2000, 422, 'impossible_time', 'La duración simulada supera el tiempo real.');
  assert(elapsed - simulated <= 300000 && elapsed <= 900000, 422, 'pause_limit', 'Se superó el límite de cinco minutos de pausas o quince minutos reales.');
}

export interface CompetitionConfig {
  enabled: boolean; confirmed: boolean; timezone: string; closeDay: number; closeHour: number;
  prize: string; eligibility: string; delivery: string; claim: string; rules: string;
}
export const DEFAULT_CONFIG: CompetitionConfig = {
  enabled: false, confirmed: false, timezone: 'America/Caracas', closeDay: 0, closeHour: 20,
  prize: '', eligibility: '', delivery: '', claim: '', rules: ''
};

export function competitionConfig(raw: unknown): CompetitionConfig {
  assert(raw && typeof raw === 'object' && !Array.isArray(raw), 400, 'invalid_config', 'Configuración no válida.');
  const value = raw as Record<string, unknown>;
  onlyKeys(value, Object.keys(DEFAULT_CONFIG));
  const result = {...DEFAULT_CONFIG, ...value} as CompetitionConfig;
  assert(typeof result.enabled === 'boolean' && typeof result.confirmed === 'boolean', 400, 'invalid_config', 'Estado no válido.');
  try { new Intl.DateTimeFormat('en', {timeZone: result.timezone}).format(); } catch { throw new ApiError(400, 'invalid_timezone', 'Zona horaria no válida.'); }
  assert(Number.isInteger(result.closeDay) && result.closeDay >= 0 && result.closeDay <= 6 && Number.isInteger(result.closeHour) && result.closeHour >= 0 && result.closeHour <= 23, 400, 'invalid_config', 'Cierre no válido.');
  for (const key of ['prize', 'eligibility', 'delivery', 'claim', 'rules'] as const) assert(typeof result[key] === 'string' && result[key].length <= 4000, 400, 'invalid_config', 'Reglas no válidas.');
  // Con premio: exige premio, elegibilidad, entrega, reclamación y reglas confirmadas. Sin premio: solo clasificación, con reglas publicadas.
  if (result.enabled && result.prize.trim()) assert(result.confirmed && ['prize', 'eligibility', 'delivery', 'claim', 'rules'].every(key => String(result[key as keyof CompetitionConfig]).trim().length >= 3), 409, 'promotion_incomplete', 'Define y confirma premio, elegibilidad, entrega, reclamación y reglas antes de activar.');
  if (result.enabled && !result.prize.trim()) assert(result.rules.trim().length >= 3, 409, 'rules_required', 'Publica las reglas de la clasificación antes de activarla.');
  return result;
}

export const EVENT_NAMES = ['page_view','mascot_interaction','game_open','game_start','game_end','game_abandon','leaderboard_view','product_view','buy_click','checkout_start'] as const;
export function validateEvent(body: Record<string, unknown>) {
  onlyKeys(body, ['id','sessionId','name','consent','properties']);
  assert(body.consent === true, 400, 'consent_required', 'La analítica opcional necesita consentimiento.');
  const id = requestKey(body.id); const sessionId = requestKey(body.sessionId);
  assert(typeof body.name === 'string' && (EVENT_NAMES as readonly string[]).includes(body.name), 400, 'event_rejected', 'Evento no permitido. purchase requiere confirmación fiable del servidor.');
  const properties = body.properties ?? {};
  assert(properties && typeof properties === 'object' && !Array.isArray(properties), 400, 'invalid_properties', 'Propiedades no válidas.');
  const props = properties as Record<string, unknown>;
  onlyKeys(props, ['mode','productId','orderId','path','source','medium','campaign','score','version','engineVersion','ticks','reason']);
  if (props.mode !== undefined) assert(['practice','competition'].includes(String(props.mode)), 400, 'invalid_properties', 'Modo no válido.');
  if (props.path !== undefined) assert(typeof props.path === 'string' && /^\/[a-zA-Z0-9/_-]{0,80}$/.test(props.path), 400, 'invalid_properties', 'Ruta sin parámetros requerida.');
  if (props.source !== undefined) assert(['instagram','direct','other','unknown'].includes(String(props.source)), 400, 'invalid_properties', 'Origen no válido.');
  for (const key of ['productId','orderId','version','engineVersion']) if (props[key] !== undefined) assert(typeof props[key] === 'string' && /^[a-zA-Z0-9_./-]{1,80}$/.test(String(props[key])), 400, 'invalid_properties', 'Identificador no válido.');
  for (const key of ['medium','campaign','reason']) if (props[key] !== undefined) assert(typeof props[key] === 'string' && /^[a-zA-Z0-9_ .-]{1,80}$/.test(String(props[key])), 400, 'invalid_properties', 'Etiqueta sin datos personales requerida.');
  if (props.ticks !== undefined) assert(Number.isInteger(props.ticks) && Number(props.ticks)>=0 && Number(props.ticks)<=36000, 400, 'invalid_properties', 'Ticks no válidos.');
  if (props.score !== undefined) assert(Number.isInteger(props.score) && Number(props.score) >= 0 && Number(props.score) <= 1000000, 400, 'invalid_properties', 'Puntuación no válida.');
  return {id,sessionId,name:body.name,properties:props};
}
