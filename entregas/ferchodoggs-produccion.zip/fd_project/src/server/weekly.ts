/** UTC epochs are milliseconds. Periods use civil dates in the configured zone. */
export type WeekConfig = { timezone: string; closeDay: number; closeHour: number };
export type Period = { id: string; start: number; end: number; timezone: string };
type Civil = { year: number; month: number; day: number; hour: number; minute: number; second: number };

/** Proposed defaults; enabling a promotion still requires explicit administration. */
export const DEFAULT_WEEK_CONFIG: Readonly<WeekConfig> = Object.freeze({
  timezone: 'America/Caracas', closeDay: 0, closeHour: 20,
});

const formatters = new Map<string, Intl.DateTimeFormat>();
function formatter(timezone: string): Intl.DateTimeFormat {
  let result = formatters.get(timezone);
  if (!result) {
    result = new Intl.DateTimeFormat('en-GB', {
      timeZone: timezone, year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23',
    });
    // Do not allow arbitrary submitted zones to grow a process-global cache.
    if (formatters.size < 16) formatters.set(timezone, result);
  }
  return result;
}
function civilAt(epoch: number, timezone: string): Civil {
  const parts = Object.fromEntries(formatter(timezone).formatToParts(epoch).map(p => [p.type, p.value]));
  return {year: Number(parts.year), month: Number(parts.month), day: Number(parts.day),
    hour: Number(parts.hour), minute: Number(parts.minute), second: Number(parts.second)};
}
function civilUTC(civil: Civil): number {
  return Date.UTC(civil.year, civil.month - 1, civil.day, civil.hour, civil.minute, civil.second);
}
function moveDays(civil: Civil, days: number): Civil {
  const moved = new Date(civilUTC(civil));
  moved.setUTCDate(moved.getUTCDate() + days);
  return {year: moved.getUTCFullYear(), month: moved.getUTCMonth() + 1, day: moved.getUTCDate(),
    hour: moved.getUTCHours(), minute: moved.getUTCMinutes(), second: moved.getUTCSeconds()};
}
/** Earlier occurrence for overlaps; shift forward by the gap for nonexistent local hours. */
function civilToEpoch(civil: Civil, timezone: string): number {
  const desired = civilUTC(civil);
  const offsets = new Set<number>();
  for (let hours = -48; hours <= 48; hours += 6) {
    const sample = desired + hours * 3_600_000;
    offsets.add(civilUTC(civilAt(sample, timezone)) - sample);
  }
  const candidates = [...offsets].map(offset => desired - offset);
  const exact = candidates.filter(epoch => civilUTC(civilAt(epoch, timezone)) === desired);
  if (exact.length) return Math.min(...exact);
  const after = candidates.map(epoch => ({epoch, delta: civilUTC(civilAt(epoch, timezone)) - desired}))
    .filter(candidate => candidate.delta > 0).sort((a,b) => a.delta - b.delta || a.epoch - b.epoch);
  if (!after.length) throw new RangeError('Cannot resolve timezone boundary');
  return after[0].epoch;
}

export function validateWeekConfig(config: WeekConfig): void {
  if (!config || typeof config.timezone !== 'string' || config.timezone.length > 80 ||
      !Number.isInteger(config.closeDay) || config.closeDay < 0 || config.closeDay > 6 ||
      !Number.isInteger(config.closeHour) || config.closeHour < 0 || config.closeHour > 23) {
    throw new RangeError('Invalid weekly configuration');
  }
  formatter(config.timezone); // Throws for an unknown IANA zone.
}

/** Start included, end excluded. At the closing instant the next period has begun. */
export function periodAt(now: number, config: WeekConfig = DEFAULT_WEEK_CONFIG): Period {
  if (!Number.isFinite(now)) throw new RangeError('Invalid timestamp');
  validateWeekConfig(config);
  const local = civilAt(now, config.timezone);
  const weekday = new Date(Date.UTC(local.year, local.month - 1, local.day)).getUTCDay();
  let startCivil = moveDays({...local, hour: config.closeHour, minute: 0, second: 0},
    -((weekday - config.closeDay + 7) % 7));
  let start = civilToEpoch(startCivil, config.timezone);
  if (start > now) {
    startCivil = moveDays(startCivil, -7);
    start = civilToEpoch(startCivil, config.timezone);
  }
  const end = civilToEpoch(moveDays(startCivil, 7), config.timezone);
  return {id: `${config.timezone}:${new Date(start).toISOString()}`, start, end, timezone: config.timezone};
}

/** receivedAt is the immutable server receipt time of this best score. */
export function compareResults(a: {score: number; receivedAt: number}, b: {score: number; receivedAt: number}): number {
  return b.score - a.score || a.receivedAt - b.receivedAt;
}

/** Report windows are natural calendar weeks, independent of contest configuration. */
export function naturalReportPeriod(now: number, timezone = 'Europe/Madrid'): {
  timezone: string; start: number; end: number; previous: {start: number; end: number};
} {
  const current = periodAt(now, {timezone, closeDay: 1, closeHour: 0});
  const prior = periodAt(current.start - 1, {timezone, closeDay: 1, closeHour: 0});
  const previous = periodAt(prior.start - 1, {timezone, closeDay: 1, closeHour: 0});
  return {timezone, start: prior.start, end: current.start,
    previous: {start: previous.start, end: prior.start}};
}
