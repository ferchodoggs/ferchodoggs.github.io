import { handleApi, type Env } from './server/api.ts';
import { allowedOrigins } from './server/validation.ts';
declare const __ASSETS__:Record<string,string>;
const mime:Record<string,string>={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json; charset=utf-8','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp'};
export function assetResponse(path:string,assets:Record<string,string>):Response {
  const key=path==='/'?'/index.html':path;
  if(!Object.hasOwn(assets,key))return new Response('No encontrado',{status:404});
  const data=Uint8Array.from(atob(assets[key]),char=>char.charCodeAt(0));
  return new Response(data,{headers:{'content-type':mime[key.slice(key.lastIndexOf('.'))]??'application/octet-stream','cache-control':'no-cache','x-content-type-options':'nosniff','referrer-policy':'strict-origin-when-cross-origin','permissions-policy':'camera=(), microphone=(), geolocation=()','content-security-policy':"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'self'"}});
}
/** CORS solo para los orígenes de la tienda listados en ALLOWED_ORIGINS (p. ej. https://ferchodoggs.github.io). */
export function withCors(request:Request,env:Env,response:Response):Response{
  const origin=request.headers.get('origin'); if(!origin||!allowedOrigins(env).includes(origin))return response;
  const headers=new Headers(response.headers); headers.set('access-control-allow-origin',origin); headers.append('vary','Origin');
  headers.set('access-control-allow-headers','content-type, authorization'); headers.set('access-control-allow-methods','GET, POST, OPTIONS'); headers.set('access-control-max-age','86400');
  return new Response(response.body,{status:response.status,headers});
}
export default {async fetch(request:Request,env:Env){const path=new URL(request.url).pathname;
  if(path.startsWith('/api/')){if(request.method==='OPTIONS')return withCors(request,env,new Response(null,{status:204}));return withCors(request,env,await handleApi(request,env));}
  if(!['GET','HEAD'].includes(request.method))return new Response('Método no permitido',{status:405});const response=assetResponse(path,__ASSETS__);return request.method==='HEAD'?new Response(null,response):response;}};
