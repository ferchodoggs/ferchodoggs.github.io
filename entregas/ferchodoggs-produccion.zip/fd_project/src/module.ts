/** Importa esta entrada para integrar el juego sin arrancar ni sustituir la página anfitriona. */
export { mountGame as createFerchoDoggsDash, top3Markup, loadBoard } from './game/ui.ts';
export { CONFIG } from './config.ts';
export { setConsent, track, personalBest } from './integration.ts';
export { ENGINE_VERSION } from './game/engine.ts';
