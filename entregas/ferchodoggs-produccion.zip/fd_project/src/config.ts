/** Punto único de integración. Nunca sustituir la mascota original por un dibujo generado. */
const host = globalThis as { FERCHO_MASCOT_URL?: string; FERCHO_RUN_FRAMES?: string[]; FERCHO_COMPETITION?: boolean; FERCHO_API_BASE?: string };
export const CONFIG = Object.freeze({
  mascotUrl: host.FERCHO_MASCOT_URL ?? '',                    // mascota ORIGINAL de cuerpo completo, sin modificar
  runFrames: Object.freeze([...(host.FERCHO_RUN_FRAMES ?? [])]), // 5 poses originales de carrera, en orden
  competitionEnabled: host.FERCHO_COMPETITION === true,        // clasificación semanal validada en servidor (sin premio hasta que el dueño lo anuncie)
  apiBase: host.FERCHO_API_BASE ?? '/api',                    // servidor del juego (Cloudflare Worker); la tienda vive en otro origen
  storagePrefix: 'ferchodoggs-dash:v2:',                       // motor v2: no mezclar récords con el motor anterior
  analyticsDefault: false,
  week: Object.freeze({ timezone: 'America/Caracas', closeLabel: 'domingo 20:00, hora de Venezuela', proposed: true }),
  prize: null as string | null,                                 // no se inventa: se configura cuando exista
  integration: Object.freeze({ preserveCart: true, closeEvent: 'ferchodoggs:close', leaderboardEvent: 'ferchodoggs:leaderboard' }),
});
