# Pruebas ejecutadas

## Resultado al entregar

**71 pruebas aprobadas,0 fallidas,0 omitidas**. Node24.22.1, npm11.9.0, entorno Linux. `npm run check` completó ESLint, TypeScript, Node tests y build. No hay código de la tienda original en estas pruebas.

| Área | Casos | Evidencia |
| --- | ---: | --- |
| Motor/puntuación | 7 | Motor real compartido, determinismo, fichas, barrido, salto, muestras de escape, límite |
| Controles/reloj | 7 | 30/60/90/120/144Hz, gestos, teclado, entradas acotadas, pausa/interrupciones/reintento |
| Identidad/API/persistencia | 7 | SQLite real aislado, emisión y final idempotentes, alias estable, propiedad |
| Semana/zona horaria | 7 | Límites exactos, consecutivos, DST Madrid, empate, ventana de informe |
| Seguridad/validación | 7 | Propietario, score alterado, logs, versión, tiempo, origen/tamaño y eventos |
| Shell responsive/accesibilidad | 7 | **Inspección de código**, no layout ni auditoría de navegador |
| Integración/storage/cliente | 7 | Almacenamiento bloqueado, namespace carrito, privacidad, rollback SQLite, assets, errores de red |
| Concurrencia administrativa | 8 | Freeze, revisiones obsoletas, entrega/invalidación/aprobación/config/start, cierre exacto, informe persistente y empate simultáneo |
| DOM/ciclo de vida | 7 | Emulación JSDOM: foco, scroll, controles, ocultar, destruir/remontar, carrito sintético |
| UI competitiva asíncrona | 7 | Emulación JSDOM: doble inicio, respuestas tardías, claves de reintento, versión, pestaña oculta, recuperación del envío y click/teclado |

Total71. Se ejecutaron además revisiones independientes del motor, interfaz y backend. Las siete pasadas están descritas en IMPLEMENTATION_REPORT.md; no significan71 ejecuciones repetidas de la misma suite.

## Comandos y resultados

```text
npm run lint       → exit0
npm run typecheck  → exit0
npm test           → 71/71 PASS; fail0, skipped0
npm run build      → exit0; bundle demo, módulo ESM y Worker
npm run check      → exit0, secuencia completa anterior
```

Las pruebas usan SQLite en memoria con esquema real y lotes transaccionales, no una tabla simulada como fuente competitiva. Se prueban intercalados de concurrencia controlados; no es una prueba de carga distribuida ni certificación del comportamiento del hosting. El reloj se probó a30/60/90/120/144Hz; no hay ventaja de puntuación por refresco para igual simulación.

Las pruebas DOM sustituyen explícitamente dialog.showModal/close, requestAnimationFrame, ResizeObserver y contextoCanvas. Sirven para eventos, reintentos y limpieza. **No verifican pintura, tamaño real, foco atrapado nativo ni interacción física.** Las primeras fallas del harness por document.hidden predeterminado en JSDOM se corrigieron declarando un documento visible; no se ocultaron fallas del producto.

## No ejecutado / no verificado

- Chrome/Safari reales: el entorno no expone la herramienta de navegador requerida por el flujo gestionado (`cua_repl.js`). No se improvisó otro preview ni se afirma haber visto la web.
- Dispositivos reales,320/390/768/1440px, horizontal, texto200%, contraste medido y lector de pantalla. Hay CSS/instrucciones y comprobaciones de fuente, no resultados visuales aprobados.
- Archivo original de la mascota: no recibido; no se verificó su carga real/proporción final.
- Carrito/pedidos reales de la tienda: repositorio no conectado. Se probó no tocar un carrito sintético y restaurar foco/scroll del host en DOM emulado.
- Identidad de producción, D1 alojado, HTTPS/acceso anónimo del hosting, CDN, carga, programación y entrega real de informes, proveedor analítico externo y monitor externo.
- No se hicieron pedidos/pagos reales ni se activaron premios.

Ver `docs/INTEGRATION_CHECKLIST.md` antes de integrar/publicar. El código no se declara infalible.

## Distribución y ZIP

La plataforma confirmó publicación de una demo privada con assets estáticos. Se verificó integridad ZIP y ausencia de rutas ascendentes, node_modules, .git o .env con secretos. No equivale a acceso anónimo ni a prueba de navegador/hosting competitivo.
