# Continuar con Claude: FERCHODOGGS DASH

## 1. Qué se entrega

Módulo nuevo e independiente, no una copia de la tienda. Se implementaron motor, renderer, controles/UI, cliente API, servidor de clasificación y validación, SQLite local, migraciones, analítica opt-in y generación de informes. No hubo acceso al repositorio de la tienda existente. **Continúa desde este módulo; no rehagas la tienda.**

## 2. Orden de lectura

1. `PROJECT_STATE.md`, `README.md`, `TEST_REPORT.md`.
2. `src/config.ts`, `src/module.ts`, `src/game/ui.ts`, `public/dash.css`.
3. `src/game/engine.ts` y `src/game/render.ts`.
4. `src/api-client.ts`, `src/server/api.ts`, `validation.ts`, `weekly.ts`, `drizzle/*.sql`.
5. `docs/API.md`, `DEPLOYMENT.md`, `docs/INTEGRATION_CHECKLIST.md`, `docs/ANALYTICS_AND_OPERATIONS.md`.

## 3. Qué funciona y qué se probó

Práctica completa, puntuación determinista, controles, persistencia local y ciclo de vida. API y clasificación ejecutadas contra SQLite real en pruebas: no score de cliente, una partida activa, un mejor resultado semanal por identidad, desempate durable e idempotencia. Pruebas DOM usan emulación y shims explícitos: no validan pintura de Canvas, layout ni dispositivos reales. Consultar cantidad final/comandos en TEST_REPORT.md.

## 4. Publicación

No se modificó ni publicó la tienda. El backend de competición no está alojado ni activado. Existe una demo privada de distribución en https://ferchodoggs.olivemerit2.chatgpt.site, solo para práctica/descarga. Sites confirmó el primer despliegue. No prueba identidad competitiva, base alojada, ventas ni premios. El usuario debe descargar el ZIP y adjuntártelo: el enlace privado no te concede acceso.

## 5. Integración sin perder el carrito

Trabaja en una rama del repositorio real, lee AGENTS.md y conserva cambios locales.

- Copia `src/game/`, `src/config.ts`, `src/api-client.ts`, `src/integration.ts` y `src/module.ts` a un subdirectorio del host manteniendo sus imports relativos.
- Importa **solo** `public/dash.css`; `styles.css`, `index.html` y `main.ts` son portada demo y no deben sustituir la tienda.
- En un componente cliente, dentro del efecto de montaje llama `createFerchoDoggsDash()`. Guarda la instancia en una referencia, llama `instance.open()` desde el botón **🎮 JUGAR** y devuelve `instance.destroy()` al desmontar. No llames mount durante cada render.
- Alternativa sin framework: importar el bundle `dist/client/assets/ferchodoggs-dash.js` y crear una sola instancia. El juego crea su propio dialog y no monta una segunda app en el root del host.
- Mantén montados el proveedor, estado y almacenamiento del carrito. El módulo solo escribe `ferchodoggs-dash:v1:*`. No usar `localStorage.clear()` ni cambiar rutas que reseteen el host.
- El cierre cancela el RAF y restaura scroll/foco. El evento `ferchodoggs:close` permite actualizar el host. `destroy()` libera listeners y observer. Verifica con el carrito REAL: producto, variante, extras y cantidad antes/después de abrir/cerrar/reintentar.
- La API debe estar en el mismo origen; configurar su prefijo en `src/config.ts`. Evitar CORS abierto para eludir validación de origen.

## 6. Mascota original

Archivo no recibido. Copia el original sin alterarlo a assets del host y configura **únicamente** `CONFIG.mascotUrl` en `src/config.ts`. Debe ser del mismo origen. Conservar proporción, dibujo, mano, hotdog y tres rayas; no generar reemplazo ni agregar detalles. El renderer carga el mismo archivo para el juego. La ficha F es temporal y está etiquetada.

En la tienda conecta el elemento original como botón accesible con un único handler click, aviso **👆 TÓCAME, MOR 💚**, frase **Tengo una sorpresa para ti 🎮** y botón de juego adyacente. Ver `main.ts` solo como ejemplo de este comportamiento. No superponerlo al carrito/productos ni emitir sonido automático. Respetar reduced-motion y evitar repetición inmediata de frases.

## 7. Contratos y decisiones a conservar

- Motor: **`ferchodoggs-dash/1.0.0`**,60ticks/s,36.000ticks máximo. `createGame(seed)`, `step(state,action?)`, `replay(seed,actions,endTick)`.
- Una acción en tick t se aplica **ANTES de step en t**. Log ordenado/único; tipos left/right/jump; máximo5.000acciones para competición.
- Score `floor(tick/6)+25*coins`. No cambiar fórmula/versiones durante semana activa.
- `/api/runs/start` emite ID/semilla/versión/semana/vencimiento. `/finish` recibe solo id,version,actions,endTick. El servidor reproduce y calcula. Ver docs/API.md para todos los esquemas/errores.
- Identidad privada estable; alias no verifica un @ ni crea otro participante.
- Propuesta de cierre America/Caracas/domingo20:00 configurable y pendiente de confirmar; inicio incluido/final excluido. Informe Europe/Madrid,semana natural,lunes09:00 con DST.
- Premios/competición desactivados hasta términos y premio confirmados. No presentar datos locales como públicos verificados.
- Semanas/candidatos tienen revisión; aprobar/entregar exige candidato/ganador y revisión que se inspeccionaron. No retirar esas condiciones atómicas.

## 8. Validación

```sh
npm ci
npm run check
npm run dev
node scripts/healthcheck.mjs http://127.0.0.1:4173
```

Repetir las pruebas tras adaptar imports/auth. Abrir navegador a320,390,768,1440px, horizontal, zoom/texto200%, teclado y reduced-motion. Probar en teléfonos reales y distinguirlos de emulación. Ver checklist. No llamar aprobadas esas pruebas por pasar TypeScript/Node.

## 9. Bloqueos externos

Repositorio de la tienda para integración definitiva; archivo original; hosting/API/DB de producción; identidad verificada; lista privada de administradores; reglas/premio/entrega/reclamación; proveedor de analítica y política de retención; canal/programador de informes; monitorización. No usar `LOCAL_DEV_ADMIN` ni identidad del demo en producción.

Instagram no se modificó. La frase sobre retirar la foto «mi leño» no identifica un archivo inequívoco: solicitar referencia exacta al integrar el agente social, retirar de cola/bloquear reutilización sin destruir original; no interpretarlo como logo.

## 10. Próxima tarea concreta

Abrir la tienda real, detectar framework y montaje del carrito, integrar **solo práctica** en una rama, conectar la mascota original y ejecutar prueba de carrito+foco+scroll en navegador antes de publicar. Después adaptar el backend a la autenticación/base del host manteniendo pruebas y contratos; no activar premios para probar conexión.

## Mensaje breve para pegar

> Adjunto FERCHODOGGS DASH. Lee PROJECT_STATE.md, README.md, TEST_REPORT.md y CLAUDE_HANDOFF.md. Integra este módulo en la tienda existente sin rehacerla: conserva catálogo/carrito, usa solo src/module.ts y dash.css, conecta el original de la mascota en src/config.ts y verifica abrir/cerrar sin perder el pedido. Mantén competición/premios desactivados hasta conectar identidad, backend y reglas reales. Continúa desde el código y ejecuta npm run check y las pruebas de navegador pendientes.
