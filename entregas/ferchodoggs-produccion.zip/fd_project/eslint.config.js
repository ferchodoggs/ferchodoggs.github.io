import tseslint from 'typescript-eslint';
export default tseslint.config(...tseslint.configs.recommended, {
  files: ['**/*.ts'], rules: {
    '@typescript-eslint/no-explicit-any':'off',
    '@typescript-eslint/no-unused-vars':['error',{argsIgnorePattern:'^_',varsIgnorePattern:'^_'}],
    'no-constant-condition':['error',{checkLoops:false}]
  }
});
